import { 
  EquipmentItem, 
  RentalBooking, 
  BookingStatus, 
  PricingRulesConfig, 
  MaintenanceRecord, 
  NotificationItem, 
  UserProfile 
} from '../types';
import { EQUIPMENT_ITEMS } from '../data/equipmentData';

const STORAGE_KEYS = {
  BOOKINGS: 'entcverse_bookings_v2',
  EQUIPMENT: 'entcverse_equipment_v2',
  SAVED_ITEMS: 'entcverse_saved_items_v2',
  PRICING_RULES: 'entcverse_pricing_rules_v2',
  MAINTENANCE: 'entcverse_maintenance_v2',
  NOTIFICATIONS: 'entcverse_notifications_v2',
  USER_PROFILE: 'entcverse_user_profile_v2'
};

export const DEFAULT_PRICING_RULES: PricingRulesConfig = {
  studentDiscountPercent: 15,
  multiDayThreshold: 3,
  multiDayDiscountPercent: 10,
  weeklyDiscountPercent: 20,
  monthlyDiscountPercent: 35,
  expressCourierFee: 99,
  lateFeeDailyMultiplier: 1.5,
  platformCommissionPercent: 35
};

const SEED_BOOKINGS: RentalBooking[] = [
  {
    id: 'ENTC-2026-9814',
    equipmentId: 'eq-dso-1054',
    equipmentName: 'Rigol DS1054Z Plus 100MHz 4CH DSO',
    quantity: 1,
    startDate: '2026-11-01',
    endDate: '2026-11-04',
    days: 3,
    rentalType: 'daily',
    dailyRate: 290,
    rawRent: 870,
    durationDiscount: 87,
    studentDiscount: 117,
    deliveryFee: 0,
    refundableDeposit: 3500,
    totalRent: 666,
    totalPaid: 4166,
    deliveryType: 'showroom_pickup',
    pickupLocation: 'Pune Central Electronics Showroom (Rack A-04)',
    studentName: 'Arjun Mehta',
    studentEmail: 'arjun.mehta@coep.ac.in',
    studentPhone: '+91 98230 45112',
    collegeName: 'COEP Technological University',
    idNumber: 'COEP-2023-ENTC-042',
    status: 'Ready for Pickup',
    createdAt: '2026-10-28T14:30:00.000Z',
    isDemo: true
  },
  {
    id: 'ENTC-2026-8421',
    equipmentId: 'eq-esp32-devkit',
    equipmentName: 'ESP32 IoT Development & Sensor Suite',
    quantity: 1,
    startDate: '2026-10-25',
    endDate: '2026-10-29',
    days: 4,
    rentalType: 'daily',
    dailyRate: 65,
    rawRent: 260,
    durationDiscount: 26,
    studentDiscount: 35,
    deliveryFee: 0,
    refundableDeposit: 500,
    totalRent: 199,
    totalPaid: 699,
    deliveryType: 'showroom_pickup',
    pickupLocation: 'Pune Central Electronics Showroom (Drawer C-12)',
    studentName: 'Arjun Mehta',
    studentEmail: 'arjun.mehta@coep.ac.in',
    studentPhone: '+91 98230 45112',
    collegeName: 'COEP Technological University',
    idNumber: 'COEP-2023-ENTC-042',
    status: 'Rented Out',
    createdAt: '2026-10-24T09:15:00.000Z',
    checkedOutAt: '2026-10-25T10:00:00.000Z',
    isDemo: true
  },
  {
    id: 'ENTC-2026-7210',
    equipmentId: 'eq-solder-station',
    equipmentName: 'Digital Dual Hot Air & Soldering Station',
    quantity: 1,
    startDate: '2026-10-15',
    endDate: '2026-10-17',
    days: 2,
    rentalType: 'daily',
    dailyRate: 140,
    rawRent: 280,
    durationDiscount: 0,
    studentDiscount: 42,
    deliveryFee: 0,
    refundableDeposit: 1800,
    totalRent: 238,
    totalPaid: 2038,
    deliveryType: 'showroom_pickup',
    pickupLocation: 'Pune Central Electronics Showroom (Bench S-02)',
    studentName: 'Arjun Mehta',
    studentEmail: 'arjun.mehta@coep.ac.in',
    studentPhone: '+91 98230 45112',
    collegeName: 'COEP Technological University',
    idNumber: 'COEP-2023-ENTC-042',
    status: 'Returned',
    createdAt: '2026-10-14T11:20:00.000Z',
    checkedOutAt: '2026-10-15T09:30:00.000Z',
    returnedAt: '2026-10-17T17:45:00.000Z',
    returnConditionRating: 98,
    damageNotes: 'Clean return, iron tip in excellent condition.',
    isDemo: true
  }
];

const SEED_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Reservation Ready for Pickup',
    message: 'Your Rigol DS1054Z Plus (ENTC-2026-9814) has passed bench calibration and is ready at the Pune showroom counter.',
    timestamp: '2 hours ago',
    type: 'success',
    read: false,
    bookingId: 'ENTC-2026-9814'
  },
  {
    id: 'notif-2',
    title: 'Return Due Notice: ESP32 Kit',
    message: 'Your ESP32 IoT Suite (ENTC-2026-8421) is scheduled for return today by 18:00. Extend rental if you need more time.',
    timestamp: '5 hours ago',
    type: 'warning',
    read: false,
    bookingId: 'ENTC-2026-8421'
  },
  {
    id: 'notif-3',
    title: 'Security Deposit Released',
    message: '₹1,800 deposit for Soldering Station (ENTC-2026-7210) has been 100% refunded to your original payment method.',
    timestamp: 'Oct 17, 2026',
    type: 'info',
    read: true,
    bookingId: 'ENTC-2026-7210'
  }
];

const SEED_MAINTENANCE: MaintenanceRecord[] = [
  {
    id: 'maint-1',
    equipmentId: 'eq-dso-1054',
    equipmentName: 'Rigol DS1054Z Plus 100MHz DSO',
    type: 'Calibration',
    cost: 450,
    date: '2026-10-20',
    technician: 'K. Deshpande (Sr. Cal Tech)',
    notes: 'Channel 1-4 vertical sensitivity verified with Fluke calibrator. Passbands verified within ±1.5%.',
    status: 'Completed'
  },
  {
    id: 'maint-2',
    equipmentId: 'eq-solder-station',
    equipmentName: 'Digital Dual Soldering Station',
    type: 'Probe Replacement',
    cost: 220,
    date: '2026-10-18',
    technician: 'M. Shinde',
    notes: 'Replaced 900M conical tip with fresh copper core; thermal calibration at 350°C checked.',
    status: 'Completed'
  }
];

class StorageService {
  private getItem<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      if (!data) return defaultValue;
      return JSON.parse(data) as T;
    } catch {
      return defaultValue;
    }
  }

  private setItem<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn('Storage write failed', e);
    }
  }

  // Bookings
  getBookings(): RentalBooking[] {
    const bookings = this.getItem<RentalBooking[]>(STORAGE_KEYS.BOOKINGS, []);
    if (bookings.length === 0) {
      this.setItem(STORAGE_KEYS.BOOKINGS, SEED_BOOKINGS);
      return SEED_BOOKINGS;
    }
    return bookings;
  }

  saveBooking(booking: RentalBooking): void {
    const bookings = this.getBookings();
    const existingIndex = bookings.findIndex((b) => b.id === booking.id);
    if (existingIndex >= 0) {
      bookings[existingIndex] = booking;
    } else {
      bookings.unshift(booking);
    }
    this.setItem(STORAGE_KEYS.BOOKINGS, bookings);
  }

  updateBookingStatus(bookingId: string, status: BookingStatus, updates?: Partial<RentalBooking>): boolean {
    const bookings = this.getBookings();
    const b = bookings.find((item) => item.id === bookingId);
    if (!b) return false;
    b.status = status;
    if (updates) {
      Object.assign(b, updates);
    }
    this.setItem(STORAGE_KEYS.BOOKINGS, bookings);
    return true;
  }

  cancelBooking(bookingId: string): { success: boolean; message: string } {
    const bookings = this.getBookings();
    const b = bookings.find((item) => item.id === bookingId);
    if (!b) return { success: false, message: 'Booking not found.' };
    if (b.status === 'Rented Out') {
      return { success: false, message: 'Active rentals currently in possession cannot be cancelled. Please return to showroom.' };
    }
    if (b.status === 'Returned' || b.status === 'Cancelled') {
      return { success: false, message: `Booking is already ${b.status.toLowerCase()}.` };
    }
    b.status = 'Cancelled';
    this.setItem(STORAGE_KEYS.BOOKINGS, bookings);
    return { success: true, message: `Reservation ${bookingId} cancelled. 100% deposit and rental fees refunded.` };
  }

  // Equipment inventory
  getEquipment(): EquipmentItem[] {
    const items = this.getItem<EquipmentItem[]>(STORAGE_KEYS.EQUIPMENT, []);
    if (items.length === 0) {
      this.setItem(STORAGE_KEYS.EQUIPMENT, EQUIPMENT_ITEMS);
      return EQUIPMENT_ITEMS;
    }
    return items;
  }

  saveEquipment(item: EquipmentItem): void {
    const items = this.getEquipment();
    const idx = items.findIndex((i) => i.id === item.id);
    if (idx >= 0) {
      items[idx] = item;
    } else {
      items.unshift(item);
    }
    this.setItem(STORAGE_KEYS.EQUIPMENT, items);
  }

  archiveEquipment(itemId: string): void {
    const items = this.getEquipment();
    const item = items.find((i) => i.id === itemId);
    if (item) {
      item.approvalStatus = 'Archived';
      this.setItem(STORAGE_KEYS.EQUIPMENT, items);
    }
  }

  // Availability validation
  checkAvailability(
    equipmentId: string,
    startDate: string,
    endDate: string,
    requestedQty: number = 1,
    excludeBookingId?: string
  ): { available: boolean; conflictCount: number; maxAvailable: number; message: string } {
    const items = this.getEquipment();
    const equipment = items.find((i) => i.id === equipmentId);
    if (!equipment) {
      return { available: false, conflictCount: 0, maxAvailable: 0, message: 'Equipment not found in catalogue.' };
    }

    if (equipment.approvalStatus === 'Archived' || equipment.approvalStatus === 'Pending') {
      return { available: false, conflictCount: 0, maxAvailable: 0, message: 'This item is not approved for rental.' };
    }

    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();

    if (isNaN(start) || isNaN(end)) {
      return { available: false, conflictCount: 0, maxAvailable: 0, message: 'Invalid rental date format.' };
    }

    if (end < start) {
      return { available: false, conflictCount: 0, maxAvailable: 0, message: 'End date cannot be earlier than start date.' };
    }

    const todayStr = new Date().toISOString().split('T')[0];
    if (startDate < todayStr) {
      return { available: false, conflictCount: 0, maxAvailable: 0, message: 'Start date cannot be in the past.' };
    }

    // Check overlaps against active bookings
    const bookings = this.getBookings();
    let overlappingUnits = 0;

    for (const b of bookings) {
      if (b.equipmentId !== equipmentId) continue;
      if (excludeBookingId && b.id === excludeBookingId) continue;
      if (b.status === 'Cancelled' || b.status === 'Returned') continue;

      const bStart = new Date(b.startDate).getTime();
      const bEnd = new Date(b.endDate).getTime();

      // Check if [start, end] overlaps with [bStart, bEnd]
      const overlaps = start <= bEnd && end >= bStart;
      if (overlaps) {
        overlappingUnits += (b.quantity || 1);
      }
    }

    const availableUnits = Math.max(0, equipment.stockCount - overlappingUnits);
    const hasEnough = availableUnits >= requestedQty;

    if (!hasEnough) {
      return {
        available: false,
        conflictCount: overlappingUnits,
        maxAvailable: availableUnits,
        message: availableUnits > 0
          ? `Only ${availableUnits} unit(s) available for these dates (${overlappingUnits} currently reserved).`
          : `All ${equipment.stockCount} unit(s) are booked during this period. Please select different dates.`
      };
    }

    return {
      available: true,
      conflictCount: overlappingUnits,
      maxAvailable: availableUnits,
      message: `Verified: ${availableUnits} unit(s) available in showroom inventory.`
    };
  }

  // Pricing calculations
  calculatePricingQuote(
    dailyRate: number,
    deposit: number,
    days: number,
    quantity: number = 1,
    hasStudentCard: boolean = true,
    deliveryType: 'showroom_pickup' | 'express_courier' = 'showroom_pickup',
    rentalType: 'hourly' | 'daily' | 'weekly' = 'daily',
    hourlyRate?: number
  ) {
    const rules = this.getPricingRules();
    let rawRent = 0;

    if (rentalType === 'hourly' && hourlyRate) {
      rawRent = hourlyRate * days * quantity; // here days represents hours
    } else {
      rawRent = dailyRate * days * quantity;
    }

    // Duration discounts
    let durationDiscount = 0;
    if (days >= 30) {
      durationDiscount = Math.round(rawRent * (rules.monthlyDiscountPercent / 100));
    } else if (days >= 7) {
      durationDiscount = Math.round(rawRent * (rules.weeklyDiscountPercent / 100));
    } else if (days >= rules.multiDayThreshold) {
      durationDiscount = Math.round(rawRent * (rules.multiDayDiscountPercent / 100));
    }

    const subtotalAfterDuration = rawRent - durationDiscount;

    // Student subsidy
    let studentDiscount = 0;
    if (hasStudentCard) {
      studentDiscount = Math.round(subtotalAfterDuration * (rules.studentDiscountPercent / 100));
    }

    const deliveryFee = deliveryType === 'express_courier' ? rules.expressCourierFee : 0;
    const finalRent = subtotalAfterDuration - studentDiscount + deliveryFee;
    const totalDeposit = deposit * quantity;
    const totalInitialDue = finalRent + totalDeposit;

    return {
      rawRent,
      durationDiscount,
      studentDiscount,
      deliveryFee,
      finalRent,
      totalDeposit,
      totalInitialDue
    };
  }

  // Saved equipment
  getSavedItemIds(): string[] {
    return this.getItem<string[]>(STORAGE_KEYS.SAVED_ITEMS, ['eq-dso-1054', 'eq-esp32-devkit']);
  }

  toggleSaveItem(itemId: string): boolean {
    const saved = this.getSavedItemIds();
    let isSavedNow = false;
    let updated: string[];
    if (saved.includes(itemId)) {
      updated = saved.filter((id) => id !== itemId);
      isSavedNow = false;
    } else {
      updated = [...saved, itemId];
      isSavedNow = true;
    }
    this.setItem(STORAGE_KEYS.SAVED_ITEMS, updated);
    return isSavedNow;
  }

  // Pricing rules
  getPricingRules(): PricingRulesConfig {
    return this.getItem<PricingRulesConfig>(STORAGE_KEYS.PRICING_RULES, DEFAULT_PRICING_RULES);
  }

  updatePricingRules(rules: PricingRulesConfig): void {
    this.setItem(STORAGE_KEYS.PRICING_RULES, rules);
  }

  // Maintenance records
  getMaintenanceRecords(): MaintenanceRecord[] {
    const records = this.getItem<MaintenanceRecord[]>(STORAGE_KEYS.MAINTENANCE, []);
    if (records.length === 0) {
      this.setItem(STORAGE_KEYS.MAINTENANCE, SEED_MAINTENANCE);
      return SEED_MAINTENANCE;
    }
    return records;
  }

  addMaintenanceRecord(rec: MaintenanceRecord): void {
    const list = this.getMaintenanceRecords();
    list.unshift(rec);
    this.setItem(STORAGE_KEYS.MAINTENANCE, list);
  }

  // Notifications
  getNotifications(): NotificationItem[] {
    const list = this.getItem<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, []);
    if (list.length === 0) {
      this.setItem(STORAGE_KEYS.NOTIFICATIONS, SEED_NOTIFICATIONS);
      return SEED_NOTIFICATIONS;
    }
    return list;
  }

  markNotificationAsRead(id: string): void {
    const list = this.getNotifications();
    const n = list.find((item) => item.id === id);
    if (n) {
      n.read = true;
      this.setItem(STORAGE_KEYS.NOTIFICATIONS, list);
    }
  }

  // User profile
  getUserProfile(): UserProfile {
    return this.getItem<UserProfile>(STORAGE_KEYS.USER_PROFILE, {
      id: 'usr-student-01',
      name: 'Arjun Mehta',
      email: 'arjun.mehta@coep.ac.in',
      phone: '+91 98230 45112',
      role: 'student',
      college: 'COEP Technological University',
      studentId: 'COEP-2023-ENTC-042',
      isVerified: true,
      savedEquipmentIds: ['eq-dso-1054', 'eq-esp32-devkit']
    });
  }

  saveUserProfile(profile: UserProfile): void {
    this.setItem(STORAGE_KEYS.USER_PROFILE, profile);
  }
}

export const storageService = new StorageService();
