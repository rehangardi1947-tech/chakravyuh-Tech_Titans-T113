import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Bookmark, 
  BookmarkCheck, 
  Scale, 
  ShoppingCart, 
  ShieldCheck, 
  MapPin, 
  AlertTriangle, 
  Check, 
  HelpCircle, 
  Calendar, 
  Sparkles, 
  Layers, 
  Info,
  DollarSign,
  Cpu,
  Clock,
  ChevronRight
} from 'lucide-react';
import { EquipmentItem } from '../types';
import { storageService } from '../services/storageService';

interface EquipmentDetailViewProps {
  item: EquipmentItem;
  onBack: () => void;
  onRentNow: (item: EquipmentItem) => void;
  onAddToCompare: (item: EquipmentItem) => void;
  isCompared: boolean;
  onSelectComplementary: (item: EquipmentItem) => void;
}

export const EquipmentDetailView: React.FC<EquipmentDetailViewProps> = ({
  item,
  onBack,
  onRentNow,
  onAddToCompare,
  isCompared,
  onSelectComplementary
}) => {
  const [isSaved, setIsSaved] = useState(() => storageService.getSavedItemIds().includes(item.id));
  const [selectedDurationOption, setSelectedDurationOption] = useState<'daily' | 'weekly' | 'hourly'>('daily');
  
  // Quick date selector to test live availability directly on the page
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const inThreeDays = new Date();
  inThreeDays.setDate(inThreeDays.getDate() + 4);
  const inThreeDaysStr = inThreeDays.toISOString().split('T')[0];

  const [testStartDate, setTestStartDate] = useState(tomorrowStr);
  const [testEndDate, setTestEndDate] = useState(inThreeDaysStr);

  const availabilityResult = storageService.checkAvailability(item.id, testStartDate, testEndDate, 1);

  const handleToggleSave = () => {
    const savedNow = storageService.toggleSaveItem(item.id);
    setIsSaved(savedNow);
  };

  const allEquipment = storageService.getEquipment();
  const complementaryItems = (item.complementaryIds || [])
    .map((id) => allEquipment.find((eq) => eq.id === id))
    .filter((eq): eq is EquipmentItem => Boolean(eq));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-left">
      {/* Top Breadcrumb & Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-cyan-400 transition-colors cursor-pointer group"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Equipment Catalogue</span>
        </button>

        <div className="flex items-center gap-3">
          <button
            onClick={handleToggleSave}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
              isSaved
                ? 'bg-cyan-950/80 border-cyan-600 text-cyan-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {isSaved ? <BookmarkCheck className="w-3.5 h-3.5 text-cyan-400" /> : <Bookmark className="w-3.5 h-3.5" />}
            <span>{isSaved ? 'Saved to Profile' : 'Save Item'}</span>
          </button>

          <button
            onClick={() => onAddToCompare(item)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
              isCompared
                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Scale className="w-3.5 h-3.5" />
            <span>{isCompared ? 'Comparing' : 'Add to Compare'}</span>
          </button>

          <button
            onClick={() => onRentNow(item)}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 transition-all shadow-sm shadow-cyan-400/20 cursor-pointer"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>Rent Now</span>
          </button>
        </div>
      </div>

      {/* Main 2-Column Product Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Imagery & Visual Inspection */}
        <div className="lg:col-span-7 space-y-6">
          <div className="relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 aspect-[16/10] shadow-2xl">
            <img
              src={item.image}
              alt={item.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 left-4 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded px-2.5 py-1 text-xs font-mono text-cyan-300">
              {item.brand} · {item.model}
            </div>

            <div className="absolute top-4 right-4 flex items-center gap-2">
              <span className={`px-2.5 py-1 rounded text-xs font-medium ${
                item.availability === 'In Showroom'
                  ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-800'
                  : 'bg-blue-950/90 text-blue-300 border border-blue-800'
              }`}>
                {item.availability} ({item.availableCount} in stock)
              </span>
            </div>

            <div className="absolute bottom-4 left-4 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-lg px-3 py-1.5 text-xs text-slate-300 flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>{item.showroomLocation}</span>
            </div>
          </div>

          {/* Beginner-Friendly Explanation Section */}
          <div className="p-6 rounded-2xl bg-cyan-950/20 border border-cyan-800/40 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider">
              <HelpCircle className="w-4 h-4" />
              <span>In Plain English: What Does This Hardware Do?</span>
            </div>
            <p className="text-sm text-slate-200 leading-relaxed font-sans">
              {item.beginnerExplanation}
            </p>
          </div>

          {/* Common ENTC Experiments Syllabus */}
          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>Common ENTC University Practicals</span>
              </h3>
              <span className="text-xs text-slate-400 font-mono">Curriculum Aligned</span>
            </div>

            <ul className="space-y-2.5 text-xs text-slate-300">
              {item.experiments.map((exp, idx) => (
                <li key={idx} className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-950/60 border border-slate-800/80">
                  <span className="w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 font-mono font-bold flex items-center justify-center shrink-0 text-[10px]">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed">{exp}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Detailed Technical Specs Table */}
          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-white border-b border-slate-800 pb-3">
              Laboratory Technical Specifications
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {item.specs.map((spec, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 flex justify-between">
                  <span className="text-slate-400">{spec.label}</span>
                  <span className="font-mono text-cyan-300 font-bold">{spec.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Pricing Engine, Live Calendar Availability, Deposit & Actions */}
        <div className="lg:col-span-5 space-y-6">
          {/* Main Purchase & Rental Box */}
          <div className="p-6 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-6 shadow-xl sticky top-24">
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-mono text-cyan-400">{item.category}</span>
                <span>Skill Level: <strong className="text-white">{item.skillLevel}</strong></span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {item.name}
              </h1>
              <p className="text-xs text-slate-300 leading-relaxed pt-1">
                {item.shortDescription}
              </p>
            </div>

            {/* Configurable Duration Pricing Tabs */}
            <div className="space-y-3">
              <span className="text-xs font-semibold text-slate-300">Rental Rate Structure:</span>
              <div className="grid grid-cols-3 gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setSelectedDurationOption('daily')}
                  className={`py-2 px-1 text-center rounded-lg transition-colors cursor-pointer ${
                    selectedDurationOption === 'daily'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="text-[10px] uppercase font-mono">Daily Rate</div>
                  <div className="text-sm font-bold font-mono text-white">₹{item.dailyRate}</div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedDurationOption('weekly')}
                  className={`py-2 px-1 text-center rounded-lg transition-colors cursor-pointer ${
                    selectedDurationOption === 'weekly'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="text-[10px] uppercase font-mono">Weekly Pass</div>
                  <div className="text-sm font-bold font-mono text-white">₹{item.weeklyRate}</div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedDurationOption('hourly')}
                  className={`py-2 px-1 text-center rounded-lg transition-colors cursor-pointer ${
                    selectedDurationOption === 'hourly'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="text-[10px] uppercase font-mono">Bench Hour</div>
                  <div className="text-sm font-bold font-mono text-white">₹{item.hourlyRate || 35}</div>
                </button>
              </div>
            </div>

            {/* Availability Checker & Date Selector */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Check Reservation Availability:</span>
                </span>
                <span className={availabilityResult.available ? 'text-emerald-400 font-mono text-[11px]' : 'text-rose-400 font-mono text-[11px]'}>
                  {availabilityResult.available ? '● INVENTORY READY' : '▲ CONFLICT DETECTED'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div>
                  <label className="text-[10px] text-slate-500 block mb-1">START DATE</label>
                  <input
                    type="date"
                    value={testStartDate}
                    onChange={(e) => setTestStartDate(e.target.value)}
                    className="w-full p-2 bg-slate-900 border border-slate-800 rounded text-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 block mb-1">END DATE</label>
                  <input
                    type="date"
                    value={testEndDate}
                    onChange={(e) => setTestEndDate(e.target.value)}
                    className="w-full p-2 bg-slate-900 border border-slate-800 rounded text-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className={`p-2 rounded text-[11px] leading-relaxed ${
                availabilityResult.available
                  ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/60'
                  : 'bg-rose-950/40 text-rose-300 border border-rose-800/60'
              }`}>
                {availabilityResult.message}
              </div>
            </div>

            {/* Deposit & Damage Policy Callout */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-baseline">
                <span className="text-slate-400">Refundable Security Deposit:</span>
                <span className="text-lg font-bold font-mono text-cyan-400">₹{item.deposit}</span>
              </div>
              <div className="flex justify-between items-baseline text-[11px] text-slate-500">
                <span>Estimated Replacement Cost:</span>
                <span className="font-mono text-slate-400">₹{item.replacementCost.toLocaleString()}</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-300 space-y-1">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Fair Damage & Consumables Policy</span>
                </div>
                <p className="leading-relaxed text-slate-400">
                  {item.damagePolicy}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => onRentNow(item)}
                className="w-full py-3.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-xl transition-all shadow-md shadow-cyan-400/25 flex items-center justify-center gap-2 cursor-pointer font-sans"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>Reserve Hardware Now (Demo Checkout)</span>
              </button>

              <p className="text-[10px] text-slate-500 text-center">
                *Demo Mode: Bookings validate dates and persist in your browser session.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Complementary & Similar Equipment Carousel / Grid */}
      {complementaryItems.length > 0 && (
        <div className="pt-8 border-t border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-mono text-cyan-400">RECOMMENDED COMPANIONS</span>
              <h3 className="text-lg font-bold text-white">Frequently Rented Together</h3>
            </div>
            <span className="text-xs text-slate-400">Complete your workbench bundle</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {complementaryItems.map((comp) => (
              <div
                key={comp.id}
                onClick={() => onSelectComplementary(comp)}
                className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer flex items-center gap-4 group"
              >
                <div className="w-16 h-16 rounded-lg bg-slate-950 overflow-hidden shrink-0">
                  <img src={comp.image} alt={comp.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                </div>
                <div className="space-y-0.5 text-xs">
                  <div className="text-[10px] text-cyan-400 font-mono">{comp.brand} · {comp.category}</div>
                  <h4 className="font-bold text-white line-clamp-1 group-hover:text-cyan-300 transition-colors">{comp.name}</h4>
                  <div className="text-slate-400 font-mono">
                    ₹{comp.dailyRate}/day · Deposit: ₹{comp.deposit}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
