import React, { useState } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  Layers, 
  Cpu, 
  GraduationCap, 
  Building2, 
  Zap, 
  ShieldCheck, 
  HelpCircle, 
  Sliders, 
  PieChart, 
  Calculator,
  ArrowRight,
  Info
} from 'lucide-react';

interface BusinessModelViewProps {
  onExploreRentals: () => void;
  onOpenOwnerPortal: () => void;
}

export const BusinessModelView: React.FC<BusinessModelViewProps> = ({
  onExploreRentals,
  onOpenOwnerPortal
}) => {
  // Interactive Business Calculator Parameters
  const [totalUnits, setTotalUnits] = useState<number>(60);
  const [avgDailyRate, setAvgDailyRate] = useState<number>(180);
  const [utilizationDaysPerMonth, setUtilizationDaysPerMonth] = useState<number>(14);
  const [platformCommissionPercent, setPlatformCommissionPercent] = useState<number>(35);
  const [maintenanceExpensePercent, setMaintenanceExpensePercent] = useState<number>(8);
  const [activeWorkshopMembers, setActiveWorkshopMembers] = useState<number>(120);

  // Projections calculations
  const grossMonthlyRentalRevenue = totalUnits * avgDailyRate * utilizationDaysPerMonth;
  const workshopMonthlyRevenue = activeWorkshopMembers * 499; // ₹499/mo workshop subscription
  const consumableSalesMonthly = totalUnits * 320; // spare probes, solder wire, flux
  const totalMonthlyGross = grossMonthlyRentalRevenue + workshopMonthlyRevenue + consumableSalesMonthly;
  const annualGrossRunRate = totalMonthlyGross * 12;

  // Breakdown
  const ownerPayoutsMonthly = Math.round(grossMonthlyRentalRevenue * ((100 - platformCommissionPercent) / 100));
  const platformRentalShareMonthly = grossMonthlyRentalRevenue - ownerPayoutsMonthly;
  const maintenanceReservesMonthly = Math.round(totalMonthlyGross * (maintenanceExpensePercent / 100));
  const estimatedPlatformNetMonthly = (platformRentalShareMonthly + workshopMonthlyRevenue + consumableSalesMonthly) - maintenanceReservesMonthly;

  const revenueStreams = [
    {
      id: 'rentals',
      title: '01. Short-Term Equipment Rentals',
      description: 'Daily, weekend, and weekly rentals of high-precision bench oscilloscopes, arbitrary signal generators, and DC power supplies for undergraduate lab coursework and prototyping.',
      margin: '65% to Owner / 35% Platform',
      icon: Cpu,
      color: 'text-cyan-400'
    },
    {
      id: 'kits',
      title: '02. Complete Practical Experiment Kits',
      description: 'Pre-packaged, curriculum-aligned lab kits (600+ components, 74xx TTL ICs, 555 timers, op-amps) rented for semester-long laboratory courses with zero individual component purchasing.',
      margin: 'High-Volume Recurring',
      icon: Layers,
      color: 'text-blue-400'
    },
    {
      id: 'sales',
      title: '03. Consumable Accessories & Parts Sales',
      description: 'Direct showroom purchase of consumables: lead-free solder reels, 40-pin Dupont jumper ribbons, replacement oscilloscope BNC probes, and microcontroller sensor breakout modules.',
      margin: '35% - 50% Gross Margin',
      icon: Zap,
      color: 'text-amber-400'
    },
    {
      id: 'workshops',
      title: '04. Paid Practical Skills Bootcamps',
      description: 'Hands-on weekend masterclasses on SMD soldering, high-speed PCB layout with KiCad, RF antenna impedance matching, and microcontroller debugging held at our physical showroom benches.',
      margin: 'High Margin / Community Driver',
      icon: GraduationCap,
      color: 'text-purple-400'
    },
    {
      id: 'institutional',
      title: '05. College & Institutional Lab Packages',
      description: 'Turnkey hardware leasing agreements for engineering departments and university incubation centers during end-semester exams and hackathons, eliminating capital budget delays.',
      margin: 'Annual Enterprise Contracts',
      icon: Building2,
      color: 'text-emerald-400'
    },
    {
      id: 'membership',
      title: '06. Student Lab Pass Memberships',
      description: 'Monthly student subscription (₹499/month) granting unlimited access to breadboard/sensor modules, 4 hours of digital storage oscilloscope bench time, and discount vouchers.',
      margin: 'Predictable Monthly MRR',
      icon: TrendingUp,
      color: 'text-cyan-300'
    },
    {
      id: 'maintenance',
      title: '07. Bench Calibration & Repair Services',
      description: 'NIST-traceable vertical amplifier calibration, multimeter fuse replacements, and oscilloscope probe compensation services performed by certified lab technicians.',
      margin: 'High-Value Technical Service',
      icon: ShieldCheck,
      color: 'text-rose-400'
    },
    {
      id: 'consignment',
      title: '08. Equipment-Owner Consignment Commission',
      description: 'Monetization platform for senior engineers and research labs to deposit idle bench instrumentation into our custody, earning passive income while we handle logistics and insurance.',
      margin: 'Asset-Light Marketplace',
      icon: DollarSign,
      color: 'text-teal-400'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12 text-left">
      {/* Title Header */}
      <div className="border-b border-slate-800 pb-6 space-y-2">
        <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
          <DollarSign className="w-4 h-4" />
          <span>SUSTAINABILITY & FINANCIAL ARCHITECTURE</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
          ENTCverse Hub Business & Revenue Model
        </h1>
        <p className="text-sm text-slate-300 max-w-3xl leading-relaxed">
          How our hybrid electronics showroom and platform generates sustainable revenue across student rentals, institutional leasing, skill workshops, and owner consignments while lowering practical education costs.
        </p>
      </div>

      {/* 8 Core Revenue Streams Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-white">8 Diversified Revenue Streams</h2>
          <span className="text-xs text-slate-400 font-mono">Marketplace & Physical Hub Model</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {revenueStreams.map((stream) => {
            const IconComponent = stream.icon;
            return (
              <div
                key={stream.id}
                className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between space-y-3"
              >
                <div className="space-y-2.5">
                  <div className="w-9 h-9 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center">
                    <IconComponent className={`w-4 h-4 ${stream.color}`} />
                  </div>
                  <h3 className="text-sm font-bold text-white">{stream.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {stream.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 text-[11px] font-mono text-cyan-300">
                  {stream.margin}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Business Model Calculator Section */}
      <div className="rounded-3xl border border-slate-800 bg-gradient-to-br from-[#0c1424] to-[#070b14] p-6 lg:p-10 space-y-8 shadow-2xl">
        <div className="space-y-1">
          <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
            INTERACTIVE FINANCIAL PROJECTION ENGINE
          </span>
          <h2 className="text-2xl font-bold text-white">
            Platform Unit Economics & Projection Simulator
          </h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Adjust equipment inventory, utilization days, and commission parameters below to project gross rental receipts, equipment-owner consignor payouts, and net platform margins.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Sliders Deck */}
          <div className="lg:col-span-6 space-y-5 p-6 rounded-2xl bg-slate-950/70 border border-slate-800/80">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Operating Assumptions</span>
            </h3>

            {/* Slider 1: Total Equipment Units */}
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <label className="text-slate-300">Active Listed Equipment Units:</label>
                <span className="font-mono text-cyan-400 font-bold">{totalUnits} Units</span>
              </div>
              <input
                type="range"
                min="10"
                max="300"
                step="5"
                value={totalUnits}
                onChange={(e) => setTotalUnits(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>10 (Pilot Showroom)</span>
                <span>300 (Multi-City Hub)</span>
              </div>
            </div>

            {/* Slider 2: Average Daily Rental Rate */}
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <label className="text-slate-300">Blended Average Daily Rental:</label>
                <span className="font-mono text-cyan-400 font-bold">₹{avgDailyRate} / day</span>
              </div>
              <input
                type="range"
                min="50"
                max="500"
                step="10"
                value={avgDailyRate}
                onChange={(e) => setAvgDailyRate(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>₹50 (Sensors/Boards)</span>
                <span>₹500 (High-End DSOs)</span>
              </div>
            </div>

            {/* Slider 3: Utilization Days Per Month */}
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <label className="text-slate-300">Average Utilization Days per Month:</label>
                <span className="font-mono text-amber-400 font-bold">{utilizationDaysPerMonth} Days ({Math.round((utilizationDaysPerMonth / 30) * 100)}%)</span>
              </div>
              <input
                type="range"
                min="5"
                max="26"
                step="1"
                value={utilizationDaysPerMonth}
                onChange={(e) => setUtilizationDaysPerMonth(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>5 Days (Off-peak)</span>
                <span>26 Days (Exam peak)</span>
              </div>
            </div>

            {/* Slider 4: Platform Commission Split */}
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <label className="text-slate-300">Platform Commission Split:</label>
                <span className="font-mono text-emerald-400 font-bold">{platformCommissionPercent}% Platform ({100 - platformCommissionPercent}% Owner)</span>
              </div>
              <input
                type="range"
                min="20"
                max="50"
                step="5"
                value={platformCommissionPercent}
                onChange={(e) => setPlatformCommissionPercent(Number(e.target.value))}
                className="w-full accent-emerald-400 cursor-pointer"
              />
            </div>

            {/* Slider 5: Student Pass Members */}
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between">
                <label className="text-slate-300">Active Student Pass Members (₹499/mo):</label>
                <span className="font-mono text-purple-400 font-bold">{activeWorkshopMembers} Students</span>
              </div>
              <input
                type="range"
                min="0"
                max="500"
                step="10"
                value={activeWorkshopMembers}
                onChange={(e) => setActiveWorkshopMembers(Number(e.target.value))}
                className="w-full accent-purple-400 cursor-pointer"
              />
            </div>
          </div>

          {/* Real-Time Financial Ledger Projections */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
              <span className="text-xs font-mono text-slate-400">PROJECTED MONTHLY STATEMENT</span>

              <div className="space-y-2.5 text-xs border-b border-slate-800 pb-4">
                <div className="flex justify-between text-slate-300">
                  <span>Gross Equipment Rental Revenue:</span>
                  <span className="font-mono font-bold text-white">₹{grossMonthlyRentalRevenue.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Student Lab Memberships MRR:</span>
                  <span className="font-mono font-bold text-white">₹{workshopMonthlyRevenue.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Consumables & Probes Retail:</span>
                  <span className="font-mono font-bold text-white">₹{consumableSalesMonthly.toLocaleString()}</span>
                </div>

                <div className="pt-2 flex justify-between text-sm font-bold text-cyan-400">
                  <span>Total Gross Monthly Revenue:</span>
                  <span className="font-mono text-base">₹{totalMonthlyGross.toLocaleString()}</span>
                </div>
              </div>

              {/* Expense & Consignor Dispersals */}
              <div className="space-y-2 text-xs border-b border-slate-800 pb-4 text-slate-400">
                <div className="flex justify-between text-amber-300">
                  <span>Equipment Owners Payout ({100 - platformCommissionPercent}% share):</span>
                  <span className="font-mono font-bold">-₹{ownerPayoutsMonthly.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Calibration & Lab Maintenance Reserve (8%):</span>
                  <span className="font-mono">-₹{maintenanceReservesMonthly.toLocaleString()}</span>
                </div>
              </div>

              {/* Net Platform Operating Profit */}
              <div className="pt-1 space-y-2">
                <div className="flex justify-between items-baseline">
                  <span className="text-sm font-bold text-white">Platform Net Operating Income:</span>
                  <span className="text-2xl font-bold font-mono text-emerald-400">
                    ₹{estimatedPlatformNetMonthly.toLocaleString()} <span className="text-xs text-slate-400 font-normal">/ mo</span>
                  </span>
                </div>

                <div className="flex justify-between text-xs text-slate-400 font-mono">
                  <span>Annualized Run-Rate Gross:</span>
                  <span className="text-white">₹{(annualGrossRunRate / 100000).toFixed(2)} Lakhs / year</span>
                </div>
              </div>
            </div>

            {/* Disclaimer & Transparency Note */}
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] text-slate-400 space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-slate-300">
                <Info className="w-3.5 h-3.5 text-cyan-400" />
                <span>Financial Modeling Disclosure</span>
              </div>
              <p className="leading-relaxed">
                The figures presented in this interactive calculator are simulated mathematical projections based on user-defined inputs, not guaranteed earnings. Real performance is governed by student semester exam cycles, equipment maintenance condition, and physical showroom footfall.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
