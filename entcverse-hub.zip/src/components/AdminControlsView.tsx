import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Settings, 
  Sliders, 
  CheckCircle2, 
  AlertTriangle, 
  Layers, 
  DollarSign, 
  UserCheck, 
  Wrench, 
  Clock, 
  Filter,
  Check,
  X
} from 'lucide-react';
import { EquipmentItem, RentalBooking, PricingRulesConfig, MaintenanceRecord } from '../types';
import { storageService } from '../services/storageService';

export const AdminControlsView: React.FC = () => {
  const [activeSection, setActiveSection] = useState<'bookings' | 'listings' | 'pricing' | 'maintenance'>('bookings');

  const [bookings, setBookings] = useState<RentalBooking[]>(() => storageService.getBookings());
  const [equipmentList, setEquipmentList] = useState<EquipmentItem[]>(() => storageService.getEquipment());
  const [pricingRules, setPricingRules] = useState<PricingRulesConfig>(() => storageService.getPricingRules());
  const [maintenanceRecords, setMaintenanceRecords] = useState<MaintenanceRecord[]>(() => storageService.getMaintenanceRecords());

  const [pricingSavedMessage, setPricingSavedMessage] = useState('');
  const [newMaintItem, setNewMaintItem] = useState('');
  const [newMaintType, setNewMaintType] = useState<any>('Calibration');
  const [newMaintCost, setNewMaintCost] = useState(350);
  const [newMaintNotes, setNewMaintNotes] = useState('');

  // Booking status override
  const handleOverrideStatus = (bookingId: string, status: RentalBooking['status']) => {
    storageService.updateBookingStatus(bookingId, status);
    setBookings(storageService.getBookings());
  };

  // Pricing rules update
  const handleSavePricing = (e: React.FormEvent) => {
    e.preventDefault();
    storageService.updatePricingRules(pricingRules);
    setPricingSavedMessage('Pricing rules updated across entire platform.');
    setTimeout(() => setPricingSavedMessage(''), 3000);
  };

  // Add maintenance record
  const handleAddMaintenance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMaintItem) return;

    const record: MaintenanceRecord = {
      id: `maint-${Date.now()}`,
      equipmentId: 'eq-custom',
      equipmentName: newMaintItem,
      type: newMaintType,
      cost: Number(newMaintCost),
      date: new Date().toISOString().split('T')[0],
      technician: 'Senior Metrology Officer',
      notes: newMaintNotes || 'Verified bench tolerance.',
      status: 'Completed'
    };

    storageService.addMaintenanceRecord(record);
    setMaintenanceRecords(storageService.getMaintenanceRecords());
    setNewMaintItem('');
    setNewMaintNotes('');
  };

  // Toggle listing status
  const handleToggleApproval = (item: EquipmentItem) => {
    const updatedStatus = item.approvalStatus === 'Approved' ? 'Pending' : 'Approved';
    const updated: EquipmentItem = { ...item, approvalStatus: updatedStatus };
    storageService.saveEquipment(updated);
    setEquipmentList(storageService.getEquipment());
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-left">
      {/* Title Header */}
      <div className="border-b border-slate-800 pb-6 space-y-2">
        <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
          <ShieldAlert className="w-4 h-4 text-cyan-400" />
          <span>ADMINISTRATIVE OPERATIONS & PLATFORM GOVERNANCE</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          ENTCverse Hub Central Administration
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
          Role-governed controls for dispute resolution, booking lifecycle overrides, pricing rule adjustments, and equipment calibration auditing.
        </p>
      </div>

      {/* Admin Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveSection('bookings')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeSection === 'bookings'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Manage All Bookings ({bookings.length})
        </button>

        <button
          onClick={() => setActiveSection('listings')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeSection === 'listings'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Catalogue & Consignment Approvals ({equipmentList.length})
        </button>

        <button
          onClick={() => setActiveSection('pricing')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeSection === 'pricing'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Pricing Rules & Discounts
        </button>

        <button
          onClick={() => setActiveSection('maintenance')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeSection === 'maintenance'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Calibration & Damage Logs ({maintenanceRecords.length})
        </button>
      </div>

      {/* SECTION 1: MANAGE ALL BOOKINGS */}
      {activeSection === 'bookings' && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white">Platform-Wide Rental Reservations</h3>
            <span className="text-xs font-mono text-cyan-400">{bookings.length} Total Logged</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Ref</th>
                  <th className="py-3 px-4 font-semibold">Equipment Name</th>
                  <th className="py-3 px-4 font-semibold">Customer</th>
                  <th className="py-3 px-4 font-semibold">Dates</th>
                  <th className="py-3 px-4 font-semibold">Total / Deposit</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Admin Status Override</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-cyan-400">{b.id}</td>
                    <td className="py-3.5 px-4 font-sans font-semibold text-white">{b.equipmentName}</td>
                    <td className="py-3.5 px-4 font-sans text-slate-300">
                      <div>{b.studentName}</div>
                      <div className="text-[10px] text-slate-500">{b.collegeName}</div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                      {b.startDate} to {b.endDate}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300">
                      ₹{b.totalRent} <span className="text-slate-500">/ +₹{b.refundableDeposit}</span>
                    </td>
                    <td className="py-3.5 px-4 font-sans">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-950 text-cyan-300 border border-slate-800">
                        {b.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-sans">
                      <select
                        value={b.status}
                        onChange={(e) => handleOverrideStatus(b.id, e.target.value as any)}
                        className="py-1 px-2 text-[11px] bg-slate-950 border border-slate-800 rounded text-slate-200 cursor-pointer"
                      >
                        <option value="Pending">Pending</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Ready for Pickup">Ready for Pickup</option>
                        <option value="Rented Out">Rented Out</option>
                        <option value="Returned">Returned</option>
                        <option value="Overdue">Overdue</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 2: CATALOGUE APPROVALS */}
      {activeSection === 'listings' && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white">Equipment Listings Approval & Stock Verification</h3>
            <span className="text-xs font-mono text-slate-400">{equipmentList.length} Items</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Equipment Name</th>
                  <th className="py-3 px-4 font-semibold">Brand / Model</th>
                  <th className="py-3 px-4 font-semibold">Daily Rate</th>
                  <th className="py-3 px-4 font-semibold">Deposit</th>
                  <th className="py-3 px-4 font-semibold">Stock</th>
                  <th className="py-3 px-4 font-semibold">Approval</th>
                  <th className="py-3 px-4 font-semibold text-right">Moderation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {equipmentList.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-sans font-bold text-white">{item.name}</td>
                    <td className="py-3 px-4 text-slate-400 font-sans">{item.brand} · {item.model}</td>
                    <td className="py-3 px-4 text-cyan-300">₹{item.dailyRate}/d</td>
                    <td className="py-3 px-4 text-white">₹{item.deposit}</td>
                    <td className="py-3 px-4 text-slate-300">{item.stockCount} units</td>
                    <td className="py-3 px-4 font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        item.approvalStatus === 'Approved'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        {item.approvalStatus || 'Approved'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-sans">
                      <button
                        onClick={() => handleToggleApproval(item)}
                        className="px-2.5 py-1 text-[11px] font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded"
                      >
                        {item.approvalStatus === 'Approved' ? 'Suspend' : 'Approve'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 3: PRICING RULES */}
      {activeSection === 'pricing' && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-6 max-w-2xl">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Platform Rental Pricing Engine Rules</span>
            </h3>
            <p className="text-xs text-slate-400">Configure global discount matrices, late fees, and courier rates.</p>
          </div>

          {pricingSavedMessage && (
            <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800 text-xs text-emerald-300">
              {pricingSavedMessage}
            </div>
          )}

          <form onSubmit={handleSavePricing} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Student Subsidy Discount (%)</label>
                <input
                  type="number"
                  min="0"
                  max="50"
                  value={pricingRules.studentDiscountPercent}
                  onChange={(e) => setPricingRules({ ...pricingRules, studentDiscountPercent: Number(e.target.value) })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Weekly Multi-Day Discount (%)</label>
                <input
                  type="number"
                  min="0"
                  max="50"
                  value={pricingRules.weeklyDiscountPercent}
                  onChange={(e) => setPricingRules({ ...pricingRules, weeklyDiscountPercent: Number(e.target.value) })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Campus Courier Dispatch Fee (₹)</label>
                <input
                  type="number"
                  min="0"
                  max="500"
                  value={pricingRules.expressCourierFee}
                  onChange={(e) => setPricingRules({ ...pricingRules, expressCourierFee: Number(e.target.value) })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Late Return Daily Multiplier</label>
                <input
                  type="number"
                  step="0.1"
                  min="1"
                  max="3"
                  value={pricingRules.lateFeeDailyMultiplier}
                  onChange={(e) => setPricingRules({ ...pricingRules, lateFeeDailyMultiplier: Number(e.target.value) })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Platform Consignment Commission Share (%)</label>
              <input
                type="number"
                min="10"
                max="60"
                value={pricingRules.platformCommissionPercent}
                onChange={(e) => setPricingRules({ ...pricingRules, platformCommissionPercent: Number(e.target.value) })}
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg cursor-pointer shadow-md shadow-cyan-400/20"
            >
              Update Global Pricing Rules
            </button>
          </form>
        </div>
      )}

      {/* SECTION 4: MAINTENANCE & DAMAGE */}
      {activeSection === 'maintenance' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 max-w-xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Wrench className="w-4 h-4 text-cyan-400" />
              <span>Record New Bench Calibration or Damage Event</span>
            </h3>

            <form onSubmit={handleAddMaintenance} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400">Equipment Item</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rigol DS1054Z (Unit #2)"
                  value={newMaintItem}
                  onChange={(e) => setNewMaintItem(e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400">Service Category</label>
                  <select
                    value={newMaintType}
                    onChange={(e) => setNewMaintType(e.target.value)}
                    className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                  >
                    <option value="Calibration">Calibration</option>
                    <option value="Probe Replacement">Probe Replacement</option>
                    <option value="Firmware Update">Firmware Update</option>
                    <option value="Fuse Repair">Fuse Repair</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400">Servicing Cost (₹)</label>
                  <input
                    type="number"
                    value={newMaintCost}
                    onChange={(e) => setNewMaintCost(Number(e.target.value))}
                    className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400">Technician Log Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Recalibrated timebase offset, installed firmware v00.04.04"
                  value={newMaintNotes}
                  onChange={(e) => setNewMaintNotes(e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                />
              </div>

              <button
                type="submit"
                className="px-5 py-2 text-slate-900 bg-cyan-400 hover:bg-cyan-300 font-semibold rounded cursor-pointer"
              >
                Log Service Entry
              </button>
            </form>
          </div>

          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-3">
            <h4 className="text-sm font-semibold text-white">Active Service Records</h4>
            <div className="space-y-2">
              {maintenanceRecords.map((m) => (
                <div key={m.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white">{m.equipmentName}</span>
                    <span className="text-cyan-400 font-mono ml-2">({m.type})</span>
                    <p className="text-slate-400 text-[11px] mt-0.5">{m.notes}</p>
                  </div>
                  <div className="text-right font-mono">
                    <div className="text-rose-400 font-bold">₹{m.cost}</div>
                    <span className="text-[10px] text-slate-500">{m.date}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
