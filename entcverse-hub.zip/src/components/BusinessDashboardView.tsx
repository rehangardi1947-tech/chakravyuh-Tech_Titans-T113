import React, { useState } from 'react';
import { 
  Building2, 
  TrendingUp, 
  Plus, 
  ShieldCheck, 
  Clock, 
  DollarSign, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Layers,
  MapPin,
  Download,
  FileText,
  Sliders,
  Archive,
  Edit,
  ClipboardCheck,
  Wrench,
  Search
} from 'lucide-react';
import { EquipmentItem, RentalBooking, MaintenanceRecord } from '../types';
import { storageService } from '../services/storageService';

export const BusinessDashboardView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'inventory' | 'rentals' | 'inspections' | 'ledger' | 'onboarding'>('inventory');

  // Load live data from storageService
  const [equipmentList, setEquipmentList] = useState<EquipmentItem[]>(() => storageService.getEquipment());
  const [bookings, setBookings] = useState<RentalBooking[]>(() => storageService.getBookings());
  const [maintenanceList, setMaintenanceList] = useState<MaintenanceRecord[]>(() => storageService.getMaintenanceRecords());

  // Add / Edit Equipment Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<EquipmentItem | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [category, setCategory] = useState<any>('Oscilloscopes');
  const [dailyRate, setDailyRate] = useState(250);
  const [weeklyRate, setWeeklyRate] = useState(1200);
  const [deposit, setDeposit] = useState(3000);
  const [stockCount, setStockCount] = useState(3);
  const [showroomLocation, setShowroomLocation] = useState('Pune Central Electronics Showroom (Rack B-02)');

  // Inspection Modal
  const [inspectingBooking, setInspectingBooking] = useState<RentalBooking | null>(null);
  const [conditionScore, setConditionScore] = useState(98);
  const [inspectionNotes, setInspectionNotes] = useState('All 4 channels responsive, probe compensation trimmers intact.');
  const [hasDamageFee, setHasDamageFee] = useState(false);
  const [damageFeeAmount, setDamageFeeAmount] = useState(0);

  // Owner Onboarding Form
  const [ownerName, setOwnerName] = useState('Prof. Suresh Kulkarni');
  const [institution, setInstitution] = useState('Independent Lab Operator / Ex-Prof COEP');
  const [bankAccount, setBankAccount] = useState('HDFC Bank · A/C Ending in 8841');
  const [ownershipAgreed, setOwnershipAgreed] = useState(true);
  const [onboardingSuccess, setOnboardingSuccess] = useState(false);

  // Active rented gear
  const activeRentals = bookings.filter((b) => b.status === 'Rented Out' || b.status === 'Ready for Pickup');
  const completedRentals = bookings.filter((b) => b.status === 'Returned');

  // Financial calculations
  const totalCompletedRevenue = completedRentals.reduce((sum, b) => sum + b.totalRent, 0);
  const activePendingRevenue = activeRentals.reduce((sum, b) => sum + b.totalRent, 0);
  const maintenanceExpenses = maintenanceList.reduce((sum, m) => sum + m.cost, 0);
  const netOwnerShare = Math.round(totalCompletedRevenue * 0.65);

  const handleOpenAddModal = (item?: EquipmentItem) => {
    if (item) {
      setEditingItem(item);
      setName(item.name);
      setBrand(item.brand);
      setModel(item.model);
      setCategory(item.category);
      setDailyRate(item.dailyRate);
      setWeeklyRate(item.weeklyRate);
      setDeposit(item.deposit);
      setStockCount(item.stockCount);
      setShowroomLocation(item.showroomLocation);
    } else {
      setEditingItem(null);
      setName('');
      setBrand('');
      setModel('');
      setCategory('Oscilloscopes');
      setDailyRate(200);
      setWeeklyRate(1000);
      setDeposit(2500);
      setStockCount(2);
      setShowroomLocation('Pune Central Electronics Showroom (Rack B-02)');
    }
    setShowAddModal(true);
  };

  const handleSaveEquipment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !brand) return;

    if (editingItem) {
      const updated: EquipmentItem = {
        ...editingItem,
        name,
        brand,
        model,
        category,
        dailyRate: Number(dailyRate),
        weeklyRate: Number(weeklyRate),
        deposit: Number(deposit),
        stockCount: Number(stockCount),
        availableCount: Number(stockCount),
        showroomLocation
      };
      storageService.saveEquipment(updated);
    } else {
      const newItem: EquipmentItem = {
        id: `eq-owner-${Date.now()}`,
        name,
        brand,
        model,
        category,
        shortDescription: `${brand} ${model} professional bench equipment deposited for student rental.`,
        fullDescription: `Verified lab equipment deposited at ${showroomLocation}. Calibrated and inspected for student experiments.`,
        beginnerExplanation: 'Professional laboratory test instrument for electronics experimentation.',
        experiments: ['General electronics prototyping and signal characterization'],
        hourlyRate: Math.round(dailyRate / 6),
        dailyRate: Number(dailyRate),
        weeklyRate: Number(weeklyRate),
        deposit: Number(deposit),
        replacementCost: dailyRate * 100,
        stockCount: Number(stockCount),
        availableCount: Number(stockCount),
        availability: 'In Showroom',
        image: '/src/assets/images/oscilloscope_hardware_1793257588044.jpg',
        rating: 5.0,
        reviewsCount: 1,
        skillLevel: 'Intermediate',
        specs: [
          { label: 'Condition', value: 'Calibrated A+' },
          { label: 'Location', value: showroomLocation }
        ],
        accessories: ['Original Test Leads', 'Power Cable', 'Protective Case'],
        safetyNotes: 'Observe proper grounding practices.',
        damagePolicy: 'Inspected upon each return; 100% deposit protection.',
        showroomLocation,
        complementaryIds: [],
        ownerId: 'owner-prof-kulkarni',
        ownerName: 'Prof. Suresh Kulkarni',
        approvalStatus: 'Approved'
      };
      storageService.saveEquipment(newItem);
    }

    setEquipmentList(storageService.getEquipment());
    setShowAddModal(false);
  };

  const handleArchive = (id: string) => {
    if (confirm('Archive this listing? It will no longer be visible for new rentals.')) {
      storageService.archiveEquipment(id);
      setEquipmentList(storageService.getEquipment());
    }
  };

  const handleStatusTransition = (bookingId: string, newStatus: RentalBooking['status']) => {
    storageService.updateBookingStatus(bookingId, newStatus);
    setBookings(storageService.getBookings());
  };

  const handleCompleteReturnInspection = () => {
    if (!inspectingBooking) return;
    storageService.updateBookingStatus(inspectingBooking.id, 'Returned', {
      returnConditionRating: conditionScore,
      damageNotes: inspectionNotes,
      damageFee: hasDamageFee ? damageFeeAmount : 0,
      returnedAt: new Date().toISOString()
    });
    setBookings(storageService.getBookings());
    setInspectingBooking(null);
  };

  const handleExportCSV = () => {
    const headers = 'BookingID,Equipment,Student,College,Days,TotalRent,Deposit,Status\n';
    const rows = bookings.map((b) => 
      `"${b.id}","${b.equipmentName}","${b.studentName}","${b.collegeName}",${b.days},${b.totalRent},${b.refundableDeposit},"${b.status}"`
    ).join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ENTCverse_Equipment_Report_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-left">
      {/* Title & Hub Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono mb-1">
            <Building2 className="w-4 h-4" />
            <span>SHOWROOM OPERATOR & EQUIPMENT CONSIGNOR CONSOLE</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Equipment Owner & Operations Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
            Manage your consigned lab hardware, record bench condition inspections, monitor active student rentals, and track monthly bank payouts.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV Report</span>
          </button>

          <button
            onClick={() => handleOpenAddModal()}
            className="px-4 py-2 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm shadow-cyan-400/20"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Equipment Listing</span>
          </button>
        </div>
      </div>

      {/* Financial & Operational KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400 font-medium">Completed Rental Volume</span>
          <div className="text-2xl font-bold font-mono text-cyan-400">
            ₹{totalCompletedRevenue.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">From {completedRentals.length} completed returns</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400 font-medium">Net Owner Earnings (65%)</span>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            ₹{netOwnerShare.toLocaleString()}
          </div>
          <p className="text-[11px] text-emerald-400 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>Settled directly via monthly NEFT</span>
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400 font-medium">Currently Rented Out</span>
          <div className="text-2xl font-bold font-mono text-white">
            {activeRentals.length} <span className="text-xs text-slate-400 font-normal">deployments</span>
          </div>
          <p className="text-[11px] text-cyan-400 font-mono">₹{activePendingRevenue.toLocaleString()} active value</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400 font-medium">Maintenance & Calibration Exp</span>
          <div className="text-2xl font-bold font-mono text-rose-400">
            ₹{maintenanceExpenses.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-500">{maintenanceList.length} service records logged</p>
        </div>
      </div>

      {/* View Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('inventory')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeTab === 'inventory'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          My Listed Equipment ({equipmentList.length})
        </button>

        <button
          onClick={() => setActiveTab('rentals')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeTab === 'rentals'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Active Deployments & Pickups ({activeRentals.length})
        </button>

        <button
          onClick={() => setActiveTab('inspections')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeTab === 'inspections'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Bench Condition & Return Inspection
        </button>

        <button
          onClick={() => setActiveTab('ledger')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeTab === 'ledger'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Maintenance & Calibration Log ({maintenanceList.length})
        </button>

        <button
          onClick={() => setActiveTab('onboarding')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeTab === 'onboarding'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Owner Onboarding & Bank Details
        </button>
      </div>

      {/* TAB 1: EQUIPMENT INVENTORY */}
      {activeTab === 'inventory' && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white">Registered Lab Equipment Inventory</h3>
            <span className="text-xs text-slate-400 font-mono">{equipmentList.length} Listed Devices</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Equipment / Model</th>
                  <th className="py-3 px-4 font-semibold">Category</th>
                  <th className="py-3 px-4 font-semibold">Rates (Daily / Weekly)</th>
                  <th className="py-3 px-4 font-semibold">Deposit</th>
                  <th className="py-3 px-4 font-semibold">Units (Stock)</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {equipmentList.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4 font-sans">
                      <div className="font-bold text-white">{item.name}</div>
                      <div className="text-[11px] text-slate-400">{item.brand} · {item.model}</div>
                    </td>
                    <td className="py-3.5 px-4 font-sans text-slate-300">
                      {item.category}
                    </td>
                    <td className="py-3.5 px-4 text-cyan-300">
                      ₹{item.dailyRate}/d · ₹{item.weeklyRate}/w
                    </td>
                    <td className="py-3.5 px-4 text-white">
                      ₹{item.deposit}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300">
                      {item.availableCount} / {item.stockCount} Avail
                    </td>
                    <td className="py-3.5 px-4 font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        item.approvalStatus === 'Archived'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      }`}>
                        {item.approvalStatus || 'Approved'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-sans space-x-2">
                      <button
                        onClick={() => handleOpenAddModal(item)}
                        className="px-2.5 py-1 text-[11px] font-medium text-cyan-300 bg-cyan-950 border border-cyan-800 hover:bg-cyan-900 rounded"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleArchive(item.id)}
                        className="px-2.5 py-1 text-[11px] font-medium text-slate-400 hover:text-rose-400 border border-slate-800 rounded"
                      >
                        Archive
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: ACTIVE DEPLOYMENTS & PICKUPS */}
      {activeTab === 'rentals' && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white">Active Student Deployments & Handover Counter</h3>
            <span className="text-xs font-mono text-cyan-400">{activeRentals.length} In Progress</span>
          </div>

          {activeRentals.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              No equipment is currently rented out.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4 font-semibold">Booking Ref</th>
                    <th className="py-3 px-4 font-semibold">Equipment Name</th>
                    <th className="py-3 px-4 font-semibold">Student Renter</th>
                    <th className="py-3 px-4 font-semibold">Contact / College</th>
                    <th className="py-3 px-4 font-semibold">Return Due Date</th>
                    <th className="py-3 px-4 font-semibold">Status</th>
                    <th className="py-3 px-4 font-semibold text-right">Counter Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {activeRentals.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-cyan-400">{b.id}</td>
                      <td className="py-3.5 px-4 font-sans font-semibold text-white">{b.equipmentName}</td>
                      <td className="py-3.5 px-4 font-sans text-slate-200">{b.studentName}</td>
                      <td className="py-3.5 px-4 font-sans text-slate-400 text-[11px]">
                        <div>{b.studentPhone}</div>
                        <div>{b.collegeName}</div>
                      </td>
                      <td className="py-3.5 px-4 text-amber-300 font-bold">{b.endDate}</td>
                      <td className="py-3.5 px-4 font-sans">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-950 text-cyan-300 border border-blue-800">
                          {b.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-sans space-x-2">
                        {b.status === 'Confirmed' && (
                          <button
                            onClick={() => handleStatusTransition(b.id, 'Ready for Pickup')}
                            className="px-2.5 py-1 text-[11px] font-medium text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded"
                          >
                            Mark Ready
                          </button>
                        )}
                        {b.status === 'Ready for Pickup' && (
                          <button
                            onClick={() => handleStatusTransition(b.id, 'Rented Out')}
                            className="px-2.5 py-1 text-[11px] font-medium text-white bg-emerald-700 hover:bg-emerald-600 rounded"
                          >
                            Mark Handed Out
                          </button>
                        )}
                        {b.status === 'Rented Out' && (
                          <button
                            onClick={() => setInspectingBooking(b)}
                            className="px-2.5 py-1 text-[11px] font-medium text-cyan-300 bg-cyan-950 border border-cyan-800 hover:bg-cyan-900 rounded"
                          >
                            Process Return & Inspect
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: BENCH CONDITION & RETURN INSPECTION */}
      {activeTab === 'inspections' && (
        <div className="space-y-4">
          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Bench Condition & Deposit Settlement Protocol</h3>
            <p className="text-xs text-slate-400">
              When equipment returns to the showroom, technicians verify waveform acquisition, probe attenuation continuity, and physical chassis condition.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-cyan-400 font-mono font-bold">1. Channel Sensitivity Check</span>
                <p className="text-slate-400">Probe calibrated 1kHz square signal pin to confirm vertical deflection accuracy.</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-cyan-400 font-mono font-bold">2. Cable & Ground Clip Test</span>
                <p className="text-slate-400">Verify ground alligator lead continuity and flex resistance to rule out internal wire breaks.</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-cyan-400 font-mono font-bold">3. Instant Deposit Release</span>
                <p className="text-slate-400">If condition score is ≥ 90%, 100% of the deposit is automatically refunded within 15 minutes.</p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800">
              <h4 className="text-sm font-semibold text-white mb-2">Recent Returned Gear Inspections</h4>
              <div className="space-y-2">
                {completedRentals.map((b) => (
                  <div key={b.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-white">{b.equipmentName} ({b.id})</div>
                      <div className="text-[11px] text-slate-400">Renter: {b.studentName} · Returned on {b.returnedAt ? b.returnedAt.split('T')[0] : 'Oct 2026'}</div>
                      <div className="text-[11px] text-slate-300 mt-0.5">Notes: {b.damageNotes || 'Clean return without issues'}</div>
                    </div>
                    <div className="text-right">
                      <span className="text-emerald-400 font-mono font-bold text-sm">{b.returnConditionRating || 98}% Score</span>
                      <span className="text-[10px] text-slate-500 block font-mono">100% Deposit Released</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: MAINTENANCE & CALIBRATION LEDGER */}
      {activeTab === 'ledger' && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-bold text-white">Maintenance, Calibration & Repair Ledger</h3>
              <p className="text-xs text-slate-400">Historical bench servicing and NIST traceability records.</p>
            </div>
          </div>

          <div className="space-y-3">
            {maintenanceList.map((m) => (
              <div key={m.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-start justify-between gap-4 text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-cyan-400" />
                    <span className="font-bold text-white">{m.equipmentName}</span>
                    <span className="text-cyan-400 font-mono">({m.type})</span>
                  </div>
                  <p className="text-slate-400">{m.notes}</p>
                  <div className="text-[11px] text-slate-500 font-mono">
                    Technician: {m.technician} · Date: {m.date}
                  </div>
                </div>

                <div className="text-right font-mono">
                  <div className="text-rose-400 font-bold">₹{m.cost}</div>
                  <span className="text-[10px] text-emerald-400">{m.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: OWNER ONBOARDING & BANK INFO */}
      {activeTab === 'onboarding' && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-6 max-w-2xl">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white">Owner Onboarding & Bank Account Verification</h3>
            <p className="text-xs text-slate-400">Register your laboratory hardware consignment details for weekly NEFT settlement.</p>
          </div>

          {onboardingSuccess && (
            <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800 text-xs text-emerald-300">
              Consignor profile verified! You can now add and manage listings.
            </div>
          )}

          <form
            onSubmit={(e) => {
              e.preventDefault();
              setOnboardingSuccess(true);
              setTimeout(() => setOnboardingSuccess(false), 3000);
            }}
            className="space-y-4 text-xs"
          >
            <div className="space-y-1">
              <label className="text-slate-400">Owner / Consignor Name</label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400">Institutional Affiliation / Organization</label>
              <input
                type="text"
                value={institution}
                onChange={(e) => setInstitution(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400">Settlement Bank Account & IFSC</label>
              <input
                type="text"
                value={bankAccount}
                onChange={(e) => setBankAccount(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
              />
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="font-bold text-white">Hardware Ownership Attestation</div>
                <div className="text-[11px] text-slate-400">I confirm that all listed equipment is legally owned and free of liens.</div>
              </div>
              <input
                type="checkbox"
                checked={ownershipAgreed}
                onChange={(e) => setOwnershipAgreed(e.target.checked)}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg cursor-pointer"
            >
              Update Owner Onboarding Profile
            </button>
          </form>
        </div>
      )}

      {/* MODAL: ADD / EDIT EQUIPMENT LISTING */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-[#0e1627] border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl text-left">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">
                {editingItem ? 'Edit Equipment Listing' : 'List Equipment for Consignment'}
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEquipment} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-medium">Equipment Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rohde & Schwarz Spectrum Analyzer"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-medium">Brand</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Keysight / Rigol"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-medium">Model</label>
                  <input
                    type="text"
                    placeholder="e.g. DSO-X 2004A"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-300 font-medium">Daily Rate (₹)</label>
                  <input
                    type="number"
                    min="20"
                    value={dailyRate}
                    onChange={(e) => setDailyRate(Number(e.target.value))}
                    className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-medium">Weekly Rate (₹)</label>
                  <input
                    type="number"
                    min="50"
                    value={weeklyRate}
                    onChange={(e) => setWeeklyRate(Number(e.target.value))}
                    className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-medium">Deposit (₹)</label>
                  <input
                    type="number"
                    min="100"
                    value={deposit}
                    onChange={(e) => setDeposit(Number(e.target.value))}
                    className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-medium">Units Available in Consignment</label>
                <input
                  type="number"
                  min="1"
                  max="20"
                  value={stockCount}
                  onChange={(e) => setStockCount(Number(e.target.value))}
                  className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-medium">Showroom Location</label>
                <input
                  type="text"
                  value={showroomLocation}
                  onChange={(e) => setShowroomLocation(e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-slate-900 bg-cyan-400 hover:bg-cyan-300 font-semibold rounded"
                >
                  {editingItem ? 'Save Changes' : 'Publish Listing'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: PROCESS RETURN & INSPECT */}
      {inspectingBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-[#0e1627] border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl text-left">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Record Bench Return Inspection</h3>
              <button onClick={() => setInspectingBooking(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs space-y-3">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                <div className="font-bold text-white">{inspectingBooking.equipmentName}</div>
                <div className="text-slate-400 font-mono text-[11px]">Renter: {inspectingBooking.studentName} · Ref: {inspectingBooking.id}</div>
                <div className="text-cyan-400 font-mono text-[11px]">Deposit Held: ₹{inspectingBooking.refundableDeposit}</div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <label className="text-slate-300 font-medium">Condition Health Score:</label>
                  <span className="font-mono text-cyan-400 font-bold">{conditionScore}%</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={conditionScore}
                  onChange={(e) => setConditionScore(Number(e.target.value))}
                  className="w-full accent-cyan-400"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Inspection Notes</label>
                <textarea
                  rows={2}
                  value={inspectionNotes}
                  onChange={(e) => setInspectionNotes(e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-800 rounded text-white"
                />
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-slate-300">Missing Accessory / Damage Deduction:</span>
                  <input
                    type="checkbox"
                    checked={hasDamageFee}
                    onChange={(e) => setHasDamageFee(e.target.checked)}
                    className="w-4 h-4 accent-cyan-400"
                  />
                </div>
                {hasDamageFee && (
                  <div>
                    <label className="text-[10px] text-slate-400">Deduction from Deposit (₹)</label>
                    <input
                      type="number"
                      min="0"
                      max={inspectingBooking.refundableDeposit}
                      value={damageFeeAmount}
                      onChange={(e) => setDamageFeeAmount(Number(e.target.value))}
                      className="w-full p-1.5 bg-slate-900 border border-slate-800 rounded text-white font-mono"
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setInspectingBooking(null)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleCompleteReturnInspection}
                  className="px-5 py-2 text-slate-900 bg-cyan-400 hover:bg-cyan-300 font-semibold rounded"
                >
                  Confirm Return & Release Deposit
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
