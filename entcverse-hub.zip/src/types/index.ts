export type Category = 
  | 'All'
  | 'Microcontrollers'
  | 'Single Board Computers'
  | 'Prototyping & Cables'
  | 'Sensors & Modules'
  | 'Multimeters'
  | 'Oscilloscopes'
  | 'Signal Generators'
  | 'Power Supplies'
  | 'RF & Communication'
  | 'Robotics & IoT'
  | 'Soldering & Tools'
  | 'Complete Lab Kits';

export type Availability = 'In Showroom' | 'Express Dispatch' | 'Reserved';

export type SkillLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export interface EquipmentItem {
  id: string;
  name: string;
  category: Category;
  model: string;
  brand: string;
  shortDescription: string;
  fullDescription: string;
  beginnerExplanation: string;
  experiments: string[];
  hourlyRate: number;
  dailyRate: number;
  weeklyRate: number;
  deposit: number;
  replacementCost: number;
  stockCount: number;
  availableCount: number;
  availability: Availability;
  image: string;
  rating: number;
  reviewsCount: number;
  specs: { label: string; value: string }[];
  accessories: string[];
  safetyNotes: string;
  damagePolicy: string;
  skillLevel: SkillLevel;
  showroomLocation: string;
  complementaryIds: string[];
  popular?: boolean;
  ownerId?: string;
  ownerName?: string;
  approvalStatus?: 'Approved' | 'Pending' | 'Archived';
}

export type BookingStatus = 
  | 'Pending'
  | 'Confirmed'
  | 'Ready for Pickup'
  | 'Rented Out'
  | 'Returned'
  | 'Cancelled'
  | 'Overdue';

export interface RentalBooking {
  id: string;
  equipmentId: string;
  equipmentName: string;
  quantity: number;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  days: number;
  rentalType: 'hourly' | 'daily' | 'weekly';
  dailyRate: number;
  rawRent: number;
  durationDiscount: number;
  studentDiscount: number;
  deliveryFee: number;
  refundableDeposit: number;
  totalRent: number;
  totalPaid: number;
  deliveryType: 'showroom_pickup' | 'express_courier';
  pickupLocation: string;
  studentName: string;
  studentEmail: string;
  studentPhone: string;
  collegeName: string;
  idNumber: string;
  status: BookingStatus;
  createdAt: string;
  checkedOutAt?: string;
  returnedAt?: string;
  returnConditionRating?: number;
  damageNotes?: string;
  damageFee?: number;
  isDemo: boolean;
}

export interface PricingRulesConfig {
  studentDiscountPercent: number;
  multiDayThreshold: number;
  multiDayDiscountPercent: number;
  weeklyDiscountPercent: number;
  monthlyDiscountPercent: number;
  expressCourierFee: number;
  lateFeeDailyMultiplier: number;
  platformCommissionPercent: number;
}

export interface MaintenanceRecord {
  id: string;
  equipmentId: string;
  equipmentName: string;
  type: 'Calibration' | 'Probe Replacement' | 'Firmware Update' | 'Fuse Repair' | 'Cosmetic Cleaning';
  cost: number;
  date: string;
  technician: string;
  notes: string;
  status: 'Completed' | 'In Progress';
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'info' | 'warning' | 'success';
  read: boolean;
  bookingId?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'owner' | 'admin';
  college?: string;
  studentId?: string;
  phone?: string;
  isVerified: boolean;
  savedEquipmentIds: string[];
}

export interface LearningGuide {
  id: string;
  title: string;
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  readTime: string;
  summary: string;
  diagramTitle?: string;
  keyPoints: string[];
  experimentSteps: string[];
  codeSample?: string;
  formula?: {
    name: string;
    expression: string;
    description: string;
  };
}

export interface StudentProject {
  id: string;
  title: string;
  author: string;
  college: string;
  category: 'IoT' | 'Telecommunication' | 'Embedded Systems' | 'DSP' | 'Robotics';
  summary: string;
  description: string;
  componentsUsed: string[];
  schematicSummary: string;
  githubUrl: string;
  likes: number;
}
