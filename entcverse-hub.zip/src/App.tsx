import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { LandingPage } from './components/LandingPage';
import { CatalogueView } from './components/CatalogueView';
import { EquipmentDetailView } from './components/EquipmentDetailView';
import { RentEquipmentView } from './components/RentEquipmentView';
import { VirtualLabView } from './components/VirtualLabView';
import { LearnView } from './components/LearnView';
import { ProjectsView } from './components/ProjectsView';
import { BusinessModelView } from './components/BusinessModelView';
import { BusinessDashboardView } from './components/BusinessDashboardView';
import { AdminControlsView } from './components/AdminControlsView';
import { StudentDashboardView } from './components/StudentDashboardView';
import { EquipmentDetailModal } from './components/EquipmentDetailModal';
import { BookingModal } from './components/BookingModal';
import { AuthModal } from './components/AuthModal';
import { EquipmentItem, RentalBooking } from './types';
import { storageService } from './services/storageService';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedDetailItem, setSelectedDetailItem] = useState<EquipmentItem | null>(null);
  const [selectedBookingItem, setSelectedBookingItem] = useState<EquipmentItem | null>(null);
  const [dedicatedDetailItem, setDedicatedDetailItem] = useState<EquipmentItem | null>(null);
  
  const [comparedItemIds, setComparedItemIds] = useState<string[]>([]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  
  const [currentUser, setCurrentUser] = useState<{ name: string; role: 'student' | 'owner' | 'admin' } | null>({
    name: 'Arjun Mehta',
    role: 'student'
  });

  // Load persistent bookings
  const [bookings, setBookings] = useState<RentalBooking[]>(() => storageService.getBookings());
  const [savedCount, setSavedCount] = useState<number>(() => storageService.getSavedItemIds().length);

  const refreshAppData = () => {
    setBookings(storageService.getBookings());
    setSavedCount(storageService.getSavedItemIds().length);
  };

  const handleBookingConfirmed = (newBooking: RentalBooking) => {
    refreshAppData();
  };

  const handleSearchClick = () => {
    setActiveTab('catalogue');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenDedicatedDetail = (item: EquipmentItem) => {
    setDedicatedDetailItem(item);
    setActiveTab('equipment-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleCompare = (item: EquipmentItem) => {
    if (comparedItemIds.includes(item.id)) {
      setComparedItemIds(comparedItemIds.filter((id) => id !== item.id));
    } else {
      if (comparedItemIds.length >= 3) {
        alert('You can compare a maximum of 3 items at a time.');
        return;
      }
      setComparedItemIds([...comparedItemIds, item.id]);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b101b] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/25 selection:text-cyan-200">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        bookingCount={bookings.length}
        savedCount={savedCount}
        openBookingHistory={() => setActiveTab('student-dashboard')}
        openSavedItems={() => setActiveTab('student-dashboard')}
        openAuthModal={() => setIsAuthOpen(true)}
        currentUser={currentUser}
        setCurrentUser={setCurrentUser}
        onSearchClick={handleSearchClick}
      />

      {/* Main Dynamic View Content */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <LandingPage
            onExploreEquipment={() => setActiveTab('catalogue')}
            onStartLearning={() => setActiveTab('learn')}
            onOpenVirtualLab={() => setActiveTab('virtual-lab')}
            onSelectEquipment={handleOpenDedicatedDetail}
            onBookEquipment={(item) => setSelectedBookingItem(item)}
            onOpenBusinessHub={() => setActiveTab('business-model')}
          />
        )}

        {activeTab === 'catalogue' && (
          <CatalogueView
            onSelectEquipment={handleOpenDedicatedDetail}
            onBookEquipment={(item) => setSelectedBookingItem(item)}
          />
        )}

        {activeTab === 'equipment-detail' && dedicatedDetailItem && (
          <EquipmentDetailView
            item={dedicatedDetailItem}
            onBack={() => setActiveTab('catalogue')}
            onRentNow={(item) => setSelectedBookingItem(item)}
            onAddToCompare={handleToggleCompare}
            isCompared={comparedItemIds.includes(dedicatedDetailItem.id)}
            onSelectComplementary={handleOpenDedicatedDetail}
          />
        )}

        {activeTab === 'rentals' && (
          <RentEquipmentView
            onBookNow={(item) => setSelectedBookingItem(item)}
            onExploreCatalogue={() => setActiveTab('catalogue')}
          />
        )}

        {activeTab === 'virtual-lab' && (
          <VirtualLabView />
        )}

        {activeTab === 'learn' && (
          <LearnView />
        )}

        {activeTab === 'projects' && (
          <ProjectsView />
        )}

        {activeTab === 'business-model' && (
          <BusinessModelView
            onExploreRentals={() => setActiveTab('catalogue')}
            onOpenOwnerPortal={() => setActiveTab('business')}
          />
        )}

        {activeTab === 'business' && (
          <BusinessDashboardView />
        )}

        {activeTab === 'admin' && (
          <AdminControlsView />
        )}

        {activeTab === 'student-dashboard' && (
          <StudentDashboardView
            bookings={bookings}
            onExploreMore={() => setActiveTab('catalogue')}
            onOpenVirtualLab={() => setActiveTab('virtual-lab')}
            onViewEquipmentDetail={handleOpenDedicatedDetail}
            onNavigateToProjects={() => setActiveTab('projects')}
            onRefreshBookings={refreshAppData}
          />
        )}
      </main>

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />

      {/* Modals & Overlays */}
      <EquipmentDetailModal
        item={selectedDetailItem}
        onClose={() => setSelectedDetailItem(null)}
        onBookNow={(item) => {
          setSelectedDetailItem(null);
          setSelectedBookingItem(item);
        }}
      />

      <BookingModal
        equipment={selectedBookingItem}
        onClose={() => setSelectedBookingItem(null)}
        onBookingConfirmed={handleBookingConfirmed}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLogin={(user) => {
          setCurrentUser(user);
          if (user.role === 'admin') setActiveTab('admin');
          else if (user.role === 'owner') setActiveTab('business');
          else setActiveTab('student-dashboard');
        }}
      />
    </div>
  );
}
