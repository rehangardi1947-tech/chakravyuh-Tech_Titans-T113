import React, { useState } from 'react';
import { 
  User, 
  Calendar, 
  ShieldCheck, 
  Clock, 
  FileText, 
  CheckCircle2, 
  AlertCircle,
  ArrowRight,
  BookOpen,
  MapPin,
  Bookmark,
  Bell,
  Trash2,
  Settings,
  FolderGit2,
  ExternalLink,
  X,
  Sparkles,
  QrCode
} from 'lucide-react';
import { RentalBooking, EquipmentItem, UserProfile } from '../types';
import { storageService } from '../services/storageService';

interface StudentDashboardViewProps {
  bookings: RentalBooking[];
  onExploreMore: () => void;
  onOpenVirtualLab: () => void;
  onViewEquipmentDetail: (item: EquipmentItem) => void;
  onNavigateToProjects: () => void;
  onRefreshBookings: () => void;
}

export const StudentDashboardView: React.FC<StudentDashboardViewProps> = ({
  bookings,
  onExploreMore,
  onOpenVirtualLab,
  onViewEquipmentDetail,
  onNavigateToProjects,
  onRefreshBookings
}) => {
  const [activeTab, setActiveTab] = useState<'rentals' | 'saved' | 'reminders' | 'profile'>('rentals');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'upcoming' | 'returned' | 'cancelled'>('all');
  
  // Selected booking for detailed inspection or cancellation
  const [selectedBooking, setSelectedBooking] = useState<RentalBooking | null>(null);
  const [showQrModal, setShowQrModal] = useState<RentalBooking | null>(null);

  // User Profile state
  const [profile, setProfile] = useState<UserProfile>(() => storageService.getUserProfile());
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileSuccessMessage, setProfileSuccessMessage] = useState('');

  // Notifications state
  const [notifications, setNotifications] = useState(() => storageService.getNotifications());

  // Saved equipment list
  const savedIds = storageService.getSavedItemIds();
  const allEquipment = storageService.getEquipment();
  const savedItems = allEquipment.filter((item) => savedIds.includes(item.id));

  // Categorize bookings
  const todayStr = new Date().toISOString().split('T')[0];
  
  const filteredBookings = bookings.filter((b) => {
    if (statusFilter === 'active') return b.status === 'Rented Out' || b.status === 'Ready for Pickup';
    if (statusFilter === 'upcoming') return b.status === 'Confirmed' || b.status === 'Pending';
    if (statusFilter === 'returned') return b.status === 'Returned';
    if (statusFilter === 'cancelled') return b.status === 'Cancelled';
    return true;
  });

  const activeRentalsCount = bookings.filter((b) => b.status === 'Rented Out' || b.status === 'Ready for Pickup').length;
  const totalLockedDeposit = bookings
    .filter((b) => b.status !== 'Returned' && b.status !== 'Cancelled')
    .reduce((sum, b) => sum + b.refundableDeposit, 0);

  const [bookingToCancel, setBookingToCancel] = useState<RentalBooking | null>(null);
  const [cancelToast, setCancelToast] = useState<string | null>(null);

  const confirmCancel = () => {
    if (!bookingToCancel) return;
    const result = storageService.cancelBooking(bookingToCancel.id);
    onRefreshBookings();
    setSelectedBooking(null);
    setBookingToCancel(null);
    setCancelToast(result.message);
    setTimeout(() => setCancelToast(null), 4000);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    storageService.saveUserProfile(profile);
    setIsEditingProfile(false);
    setProfileSuccessMessage('Profile and contact preferences updated.');
    setTimeout(() => setProfileSuccessMessage(''), 3000);
  };

  const handleRemoveSaved = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    storageService.toggleSaveItem(id);
    onRefreshBookings();
  };

  const getStatusBadge = (status: RentalBooking['status']) => {
    switch (status) {
      case 'Ready for Pickup':
        return 'bg-cyan-950 text-cyan-300 border-cyan-700';
      case 'Rented Out':
        return 'bg-emerald-950 text-emerald-300 border-emerald-700';
      case 'Confirmed':
        return 'bg-blue-950 text-blue-300 border-blue-700';
      case 'Returned':
        return 'bg-slate-800 text-slate-300 border-slate-700';
      case 'Cancelled':
        return 'bg-rose-950 text-rose-300 border-rose-800';
      case 'Overdue':
        return 'bg-amber-950 text-amber-300 border-amber-800';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-left">
      {/* Student Welcome Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono mb-1">
            <User className="w-4 h-4" />
            <span>STUDENT RESEARCHER WORKSPACE</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            {profile.name}
          </h1>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-1">
            <span>{profile.college}</span>
            <span>·</span>
            <span className="font-mono text-cyan-400">PRN: {profile.studentId}</span>
            <span>·</span>
            <span className="text-emerald-400 font-medium">15% Academic Subsidy Verified</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenVirtualLab}
            className="px-4 py-2 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg cursor-pointer transition-colors"
          >
            Launch Virtual Lab
          </button>
          <button
            onClick={onExploreMore}
            className="px-4 py-2 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg cursor-pointer transition-colors"
          >
            Rent Equipment
          </button>
        </div>
      </div>

      {/* Primary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Active Handover Units</span>
          <div className="text-2xl font-bold font-mono text-cyan-400">
            {activeRentalsCount} <span className="text-xs text-slate-400 font-normal">equipment unit{activeRentalsCount !== 1 ? 's' : ''}</span>
          </div>
          <p className="text-[11px] text-slate-500">Inspected & calibrated</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Locked Security Deposits</span>
          <div className="text-2xl font-bold font-mono text-white">
            ₹{totalLockedDeposit.toLocaleString()}
          </div>
          <p className="text-[11px] text-emerald-400 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>100% Refundable on return</span>
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Bookmarked Devices</span>
          <div className="text-2xl font-bold font-mono text-amber-400">
            {savedItems.length} <span className="text-xs text-slate-400 font-normal">items saved</span>
          </div>
          <p className="text-[11px] text-slate-500">Wishlist for semester project</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Student Subsidy Saved</span>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            ₹1,840
          </div>
          <p className="text-[11px] text-slate-500">Direct savings vs market rates</p>
        </div>
      </div>

      {/* Workspace Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('rentals')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeTab === 'rentals'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          My Rentals & Bookings ({bookings.length})
        </button>

        <button
          onClick={() => setActiveTab('saved')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeTab === 'saved'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Saved Equipment ({savedItems.length})
        </button>

        <button
          onClick={() => setActiveTab('reminders')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer relative ${
            activeTab === 'reminders'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Return Reminders & Alerts
          {notifications.some((n) => !n.read) && (
            <span className="ml-1.5 w-2 h-2 rounded-full bg-cyan-400 inline-block" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`py-2 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
            activeTab === 'profile'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Profile & ID Verification
        </button>
      </div>

      {/* TAB 1: RENTALS & BOOKINGS */}
      {activeTab === 'rentals' && (
        <div className="space-y-4">
          {/* Sub-filter bar */}
          <div className="flex items-center gap-1.5 text-xs">
            {(['all', 'active', 'upcoming', 'returned', 'cancelled'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`py-1 px-3 rounded-md capitalize transition-colors cursor-pointer ${
                  statusFilter === s
                    ? 'bg-slate-800 text-cyan-300 font-semibold border border-slate-700'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {s}
              </button>
            ))}
          </div>

          <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Rental Reservations History</h3>
              <span className="text-xs font-mono text-slate-400">{filteredBookings.length} matching entries</span>
            </div>

            {filteredBookings.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-400 space-y-2">
                <p>No equipment bookings found for filter "{statusFilter}".</p>
                <button onClick={onExploreMore} className="text-cyan-400 font-semibold hover:underline">
                  Browse Equipment Catalogue →
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4 font-semibold">Ref Code</th>
                      <th className="py-3 px-4 font-semibold">Equipment Name</th>
                      <th className="py-3 px-4 font-semibold">Duration / Dates</th>
                      <th className="py-3 px-4 font-semibold">Fulfillment Station</th>
                      <th className="py-3 px-4 font-semibold">Deposit</th>
                      <th className="py-3 px-4 font-semibold">Status</th>
                      <th className="py-3 px-4 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {filteredBookings.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3.5 px-4 font-bold text-cyan-400">
                          {b.id}
                        </td>
                        <td className="py-3.5 px-4 font-sans font-semibold text-white">
                          {b.equipmentName}
                          <span className="text-[10px] text-slate-400 block font-mono">Qty: {b.quantity}</span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-300">
                          <div>{b.startDate} to {b.endDate}</div>
                          <span className="text-[10px] text-slate-500 font-mono">{b.days} {b.rentalType === 'hourly' ? 'hours' : 'days'}</span>
                        </td>
                        <td className="py-3.5 px-4 font-sans text-slate-300">
                          {b.pickupLocation}
                        </td>
                        <td className="py-3.5 px-4 text-cyan-300">
                          ₹{b.refundableDeposit}
                        </td>
                        <td className="py-3.5 px-4 font-sans">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold border ${getStatusBadge(b.status)}`}>
                            {b.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right font-sans space-x-2">
                          <button
                            onClick={() => setShowQrModal(b)}
                            className="px-2.5 py-1 text-[11px] font-medium text-cyan-300 bg-cyan-950/70 border border-cyan-800 hover:bg-cyan-900 rounded cursor-pointer"
                          >
                            Pass
                          </button>

                          {(b.status === 'Confirmed' || b.status === 'Pending') && (
                            <button
                              onClick={() => setBookingToCancel(b)}
                              className="px-2.5 py-1 text-[11px] font-medium text-rose-300 bg-rose-950/70 border border-rose-800 hover:bg-rose-900 rounded cursor-pointer"
                            >
                              Cancel
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: SAVED EQUIPMENT */}
      {activeTab === 'saved' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Saved Laboratory Hardware</h3>
            <span className="text-xs text-slate-400 font-mono">{savedItems.length} items bookmarked</span>
          </div>

          {savedItems.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-slate-900/50 border border-slate-800 text-xs text-slate-400 space-y-2">
              <Bookmark className="w-8 h-8 text-slate-600 mx-auto" />
              <p>You have not bookmarked any equipment yet.</p>
              <button onClick={onExploreMore} className="text-cyan-400 font-semibold hover:underline">
                Explore Equipment Catalogue →
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => onViewEquipmentDetail(item)}
                  className="rounded-2xl border border-slate-800 bg-slate-900/70 hover:border-slate-700 transition-all overflow-hidden flex flex-col justify-between cursor-pointer group"
                >
                  <div className="aspect-[4/3] bg-slate-950 overflow-hidden relative">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    <button
                      onClick={(e) => handleRemoveSaved(item.id, e)}
                      className="absolute top-3 right-3 p-1.5 rounded-lg bg-slate-900/90 text-rose-400 hover:bg-rose-950 border border-slate-800"
                      title="Remove bookmark"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="p-4 space-y-2">
                    <div className="text-[10px] text-cyan-400 font-mono">{item.brand} · {item.category}</div>
                    <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-1">{item.name}</h4>
                    <p className="text-xs text-slate-400 line-clamp-2">{item.shortDescription}</p>
                    <div className="pt-2 border-t border-slate-800 flex justify-between items-baseline text-xs">
                      <span className="text-white font-mono font-bold">₹{item.dailyRate}/day</span>
                      <span className="text-cyan-400 font-medium">View Details →</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: RETURN REMINDERS & NOTIFICATIONS */}
      {activeTab === 'reminders' && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Bell className="w-4 h-4 text-cyan-400" />
              <span>Showroom Return Reminders & System Notifications</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">{notifications.length} Alerts</span>
          </div>

          <div className="space-y-3">
            {notifications.map((n) => (
              <div
                key={n.id}
                className={`p-4 rounded-xl border flex items-start justify-between gap-4 text-xs ${
                  n.type === 'warning'
                    ? 'bg-amber-950/30 border-amber-800/60 text-slate-200'
                    : n.type === 'success'
                    ? 'bg-emerald-950/30 border-emerald-800/60 text-slate-200'
                    : 'bg-slate-950 border-slate-800 text-slate-300'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{n.title}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{n.timestamp}</span>
                  </div>
                  <p className="text-slate-400 leading-relaxed">{n.message}</p>
                </div>

                {!n.read && (
                  <button
                    onClick={() => {
                      storageService.markNotificationAsRead(n.id);
                      setNotifications(storageService.getNotifications());
                    }}
                    className="text-[11px] text-cyan-400 hover:underline shrink-0"
                  >
                    Mark as Read
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: PROFILE & CONTACT PREFERENCES */}
      {activeTab === 'profile' && (
        <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-6 space-y-6 max-w-2xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-bold text-white">Student Identification & Contact Preferences</h3>
              <p className="text-xs text-slate-400">Manage academic credentials and pickup verification contact info.</p>
            </div>
            {!isEditingProfile && (
              <button
                onClick={() => setIsEditingProfile(true)}
                className="px-3 py-1.5 text-xs font-medium text-cyan-400 border border-cyan-800 rounded-lg hover:bg-cyan-950 cursor-pointer"
              >
                Edit Details
              </button>
            )}
          </div>

          {profileSuccessMessage && (
            <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800 text-xs text-emerald-300">
              {profileSuccessMessage}
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-slate-400">Full Name</label>
                <input
                  type="text"
                  disabled={!isEditingProfile}
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white disabled:opacity-60"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-400">Email Address</label>
                <input
                  type="email"
                  disabled={!isEditingProfile}
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white disabled:opacity-60"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-slate-400">Mobile Phone (SMS reminders)</label>
                <input
                  type="text"
                  disabled={!isEditingProfile}
                  value={profile.phone || ''}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white disabled:opacity-60"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-400">Student ID / PRN Number</label>
                <input
                  type="text"
                  disabled={!isEditingProfile}
                  value={profile.studentId || ''}
                  onChange={(e) => setProfile({ ...profile, studentId: e.target.value })}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono disabled:opacity-60"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-slate-400">College / University</label>
              <input
                type="text"
                disabled={!isEditingProfile}
                value={profile.college || ''}
                onChange={(e) => setProfile({ ...profile, college: e.target.value })}
                className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white disabled:opacity-60"
              />
            </div>

            {isEditingProfile && (
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsEditingProfile(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-slate-900 bg-cyan-400 hover:bg-cyan-300 font-semibold rounded-lg"
                >
                  Save Changes
                </button>
              </div>
            )}
          </form>
        </div>
      )}

      {/* QR Code Counter Pass Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-[#0e1627] border border-slate-800 rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl text-center">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs font-mono text-cyan-400 font-bold">{showQrModal.id}</span>
              <button onClick={() => setShowQrModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 bg-white rounded-xl inline-block mx-auto">
              <QrCode className="w-36 h-36 text-slate-900" />
            </div>

            <div className="text-xs space-y-1 text-slate-300 text-left">
              <div className="font-bold text-white">{showQrModal.equipmentName}</div>
              <div className="text-slate-400 text-[11px]">Renter: {showQrModal.studentName}</div>
              <div className="text-slate-400 text-[11px]">Station: {showQrModal.pickupLocation}</div>
              <div className="text-slate-400 text-[11px]">Deposit: ₹{showQrModal.refundableDeposit}</div>
            </div>

            <button
              onClick={() => setShowQrModal(null)}
              className="w-full py-2 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Cancellation Confirmation Modal */}
      {bookingToCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 space-y-4 text-left shadow-2xl">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <span>Cancel Reservation {bookingToCancel.id}?</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to cancel your reservation for <span className="font-semibold text-white">{bookingToCancel.equipmentName}</span>? Your 100% security deposit (₹{bookingToCancel.refundableDeposit}) and rental fee will be fully refunded to your student account.
            </p>
            <div className="flex justify-end gap-2 pt-2 text-xs">
              <button
                onClick={() => setBookingToCancel(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
              >
                Keep Reservation
              </button>
              <button
                onClick={confirmCancel}
                className="px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 font-bold text-white cursor-pointer"
              >
                Confirm Cancellation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cancellation Toast */}
      {cancelToast && (
        <div className="fixed bottom-6 left-6 z-50 p-4 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-2xl animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{cancelToast}</span>
        </div>
      )}
    </div>
  );
};
