import React, { useState } from 'react';
import { 
  Cpu, 
  Menu, 
  X, 
  Search, 
  BookmarkCheck, 
  Bookmark, 
  User, 
  SlidersHorizontal,
  MapPin,
  ShieldAlert,
  DollarSign,
  Bot,
  Play
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  bookingCount: number;
  savedCount: number;
  openBookingHistory: () => void;
  openSavedItems: () => void;
  openAuthModal: () => void;
  openAiMentor?: () => void;
  openJudgeTour?: () => void;
  currentUser: { name: string; role: 'student' | 'owner' | 'admin' } | null;
  setCurrentUser: React.Dispatch<React.SetStateAction<{ name: string; role: 'student' | 'owner' | 'admin' } | null>>;
  onSearchClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  bookingCount,
  savedCount,
  openBookingHistory,
  openSavedItems,
  openAuthModal,
  openAiMentor,
  openJudgeTour,
  currentUser,
  setCurrentUser,
  onSearchClick
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'catalogue', label: 'Equipment Catalogue' },
    { id: 'rentals', label: 'Rent Equipment' },
    { id: 'learn', label: 'Learn ENTC' },
    { id: 'virtual-lab', label: 'Virtual Lab' },
    { id: 'projects', label: 'Projects' },
    { id: 'business-model', label: 'Business Model' },
    { id: 'business', label: 'Owner Hub' },
  ];

  if (currentUser?.role === 'admin') {
    navLinks.push({ id: 'admin', label: 'Admin Console' });
  }

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#0b101b]/95 backdrop-blur-md">
      {/* Top micro showroom locator strip */}
      <div className="hidden lg:flex items-center justify-between px-6 py-1.5 bg-slate-900/60 border-b border-slate-800/40 text-[12px] text-slate-400">
        <div className="flex items-center gap-2">
          <MapPin className="w-3.5 h-3.5 text-cyan-400" />
          <span>Physical Electronics Showroom: Pune Tech Hub, JM Road · Mon-Sun 9AM-8PM</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300">Bengaluru & Delhi Pickup Counters Active</span>
        </div>
        <div className="flex items-center gap-4 text-slate-400">
          {openJudgeTour && (
            <button
              onClick={openJudgeTour}
              className="flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-gradient-to-r from-amber-500/20 to-cyan-500/20 border border-amber-500/40 text-amber-300 hover:text-white text-[11px] font-bold cursor-pointer transition-all shadow-sm shadow-amber-500/10"
            >
              <Play className="w-3 h-3 fill-current text-amber-400" />
              <span>Live Hackathon Demo (10 Steps)</span>
            </button>
          )}
          <span className="text-slate-600">|</span>
          <span>Student Verification: Flat 15% Off Rentals</span>
          <span className="text-slate-600">|</span>
          <button 
            onClick={() => setActiveTab('business-model')} 
            className="text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer"
          >
            Explore 8 Revenue Streams →
          </button>
        </div>
      </div>

      {/* Main Top Bar Contract: 3 zones separated by gap-8 */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        {/* Zone 1: Brand Wordmark */}
        <button 
          onClick={() => setActiveTab('home')} 
          className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 group cursor-pointer focus:outline-none"
        >
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/10 group-hover:shadow-cyan-500/25 transition-all">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <span className="text-lg font-bold tracking-tight text-white group-hover:text-cyan-300 transition-colors">
              ENTCverse<span className="text-cyan-400 font-extrabold ml-1">Hub</span>
            </span>
          </div>
        </button>

        {/* Zone 2: Concise single-line nav links */}
        <nav className="hidden xl:flex items-center gap-5 text-sm font-medium text-slate-300">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`whitespace-nowrap shrink-0 transition-colors py-1 relative cursor-pointer ${
                  isActive 
                    ? 'text-cyan-400 font-semibold' 
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action + Quick Affordances */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Quick Search */}
          <button
            onClick={onSearchClick}
            title="Search equipment"
            className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-800/60 rounded-lg transition-colors cursor-pointer"
            aria-label="Search equipment"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Live Hackathon Tour Button */}
          {openJudgeTour && (
            <button
              onClick={openJudgeTour}
              title="Launch Guided Hackathon Demo (10 Steps)"
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold text-amber-300 bg-amber-950/40 hover:bg-amber-900/50 border border-amber-600/60 rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              <Play className="w-3.5 h-3.5 fill-current text-amber-400" />
              <span className="hidden sm:inline">Demo Tour</span>
            </button>
          )}

          {/* Dr. Silicon AI Mentor Button */}
          {openAiMentor && (
            <button
              onClick={openAiMentor}
              title="Dr. Silicon AI Lab Mentor"
              className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-cyan-300 bg-cyan-950/40 hover:bg-cyan-900/40 border border-cyan-800/60 rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              <Bot className="w-3.5 h-3.5 text-cyan-400" />
              <span>AI Mentor</span>
            </button>
          )}

          {/* Saved Items badge */}
          {savedCount > 0 && (
            <button
              onClick={openSavedItems}
              title="Saved items"
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-amber-300 bg-amber-950/40 border border-amber-800/60 rounded-lg hover:bg-amber-900/40 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>{savedCount}</span>
            </button>
          )}

          {/* Active Bookings badge */}
          {bookingCount > 0 && (
            <button
              onClick={openBookingHistory}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-cyan-300 bg-cyan-950/60 border border-cyan-800/80 rounded-lg hover:bg-cyan-900/40 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <BookmarkCheck className="w-3.5 h-3.5" />
              <span>{bookingCount} {bookingCount === 1 ? 'Booking' : 'Bookings'}</span>
            </button>
          )}

          {/* User Profile / Sign In */}
          {currentUser ? (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  if (currentUser.role === 'admin') setActiveTab('admin');
                  else if (currentUser.role === 'owner') setActiveTab('business');
                  else setActiveTab('student-dashboard');
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden md:inline">{currentUser.name}</span>
                <span className="text-[10px] text-cyan-400 font-mono uppercase tracking-wider">({currentUser.role})</span>
              </button>

              <button
                onClick={openAuthModal}
                className="text-xs text-slate-400 hover:text-white px-1.5 py-1 rounded bg-slate-900 border border-slate-800 cursor-pointer"
                title="Switch User Role"
              >
                Switch
              </button>
            </div>
          ) : (
            <button
              onClick={openAuthModal}
              className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Sign In
            </button>
          )}

          {/* Primary Action Button */}
          <button
            onClick={() => setActiveTab('catalogue')}
            className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-sm shadow-cyan-400/20 hover:shadow-cyan-400/40 transition-all whitespace-nowrap shrink-0 cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Explore Equipment</span>
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-b border-slate-800 bg-[#0e1524] px-4 pt-2 pb-6 space-y-1">
          <div className="py-2 px-3 text-xs text-slate-400 flex items-center gap-2 border-b border-slate-800/60 mb-2">
            <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Pune Showroom Open · 9AM - 8PM</span>
          </div>
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                activeTab === link.id
                  ? 'bg-cyan-500/10 text-cyan-400 font-semibold'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              {link.label}
            </button>
          ))}
          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
            <button
              onClick={() => handleNavClick('catalogue')}
              className="w-full py-2.5 text-center text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors cursor-pointer"
            >
              Explore Equipment Catalogue
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
