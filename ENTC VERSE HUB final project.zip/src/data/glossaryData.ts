import { GlossaryTerm } from '../types';

export const GLOSSARY_TERMS: GlossaryTerm[] = [
  // Fundamentals
  {
    term: "Ohm's Law",
    category: 'Fundamentals',
    definition: 'Fundamental physical law stating that the current (I) through a conductor between two points is directly proportional to voltage (V) and inversely proportional to resistance (R): V = I × R.',
    practicalContext: 'Used on every engineering bench to size current-limiting resistors for LEDs and prevent thermal destruction of components.',
    relatedEquipmentId: 'eq-dmm-fluke'
  },
  {
    term: "Kirchhoff's Current Law (KCL)",
    category: 'Fundamentals',
    definition: 'Conservation principle stating that the algebraic sum of currents entering any electrical circuit junction (node) is strictly zero.',
    practicalContext: 'Essential for solving parallel branches and calculating total current drawn from power supplies.',
    relatedEquipmentId: 'eq-dmm-fluke'
  },
  {
    term: "Kirchhoff's Voltage Law (KVL)",
    category: 'Fundamentals',
    definition: 'Conservation principle stating that the directed sum of electrical potential differences (voltages) around any closed loop is zero.',
    practicalContext: 'Applied to verify voltage drops across series components and design operational amplifier feedback loops.',
    relatedEquipmentId: 'eq-dc-psu'
  },
  {
    term: 'Capacitance & Decoupling',
    category: 'Fundamentals',
    definition: 'Ability of an electrical system to store energy in an electrostatic field. Decoupling capacitors (typically 100nF ceramic) filter high-frequency switching noise near IC power pins.',
    practicalContext: 'Without 0.1μF bypass capacitors placed within 2mm of microcontroller VCC pins, fast logic switching creates brownouts and resets.',
    relatedEquipmentId: 'eq-rigol-dso-1054z'
  },
  {
    term: 'Inductance & Inductive Kickback',
    category: 'Fundamentals',
    definition: 'Property of a conductor by which a change in current induces an electromotive force (EMF) in both itself and neighboring conductors: V = L × (di/dt).',
    practicalContext: 'When switching off relays or motors, collapsing magnetic fields generate dangerous reverse voltage spikes (>100V) requiring flyback diodes.',
    relatedEquipmentId: 'eq-rigol-dso-1054z'
  },
  {
    term: 'Impedance (Z)',
    category: 'Fundamentals',
    definition: 'Total opposition a circuit presents to the alternating current (AC) at a given frequency, combining resistance (R) and reactance (X): Z = R + jX.',
    practicalContext: 'Critical in audio systems and RF antenna matching where maximum power transfer occurs when source and load impedances match (e.g. 50Ω).',
    relatedEquipmentId: 'eq-lora-module'
  },
  {
    term: 'Resonance & Q-Factor',
    category: 'Fundamentals',
    definition: 'Condition in LC circuits where inductive reactance equals capacitive reactance, maximizing or minimizing impedance. Q-factor indicates damping and selectivity sharpness.',
    practicalContext: 'Determines channel selectivity in AM/FM radio receivers and bandpass filter design.',
    relatedEquipmentId: 'eq-lora-module'
  },
  {
    term: 'Thermal Dissipation & Wattage',
    category: 'Fundamentals',
    definition: 'Conversion of electrical power into thermal energy: P = V × I = I²R. Component packages specify maximum junction thermal resistance θ_JA.',
    practicalContext: 'Exceeding a 1/4W resistor rating or linear regulator thermal limit causes smoking components and delamination of PCB copper.',
    relatedEquipmentId: 'eq-dc-psu'
  },

  // Instruments
  {
    term: 'Digital Storage Oscilloscope (DSO)',
    category: 'Instruments',
    definition: 'Test instrument that digitizes and graphs varying electrical voltage signals as a function of time, capturing instantaneous waveforms, glitches, and rise times.',
    practicalContext: 'Essential for debugging PWM frequencies, SPI/I2C communication lines, and analog filter ripple.',
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    term: 'Logic Analyzer',
    category: 'Instruments',
    definition: 'Multichannel diagnostic instrument that captures and decodes digital logic states (0 and 1) across multiple synchronized channels with protocol decoders.',
    practicalContext: 'Used to inspect complex multi-wire buses like SPI, UART, CAN, and I2C simultaneously to pinpoint bus collision errors.',
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    term: 'Arbitrary Function Generator',
    category: 'Instruments',
    definition: 'Electronic signal source capable of producing repetitive sine, square, ramp, pulse, and custom mathematical waveforms with precise amplitude and frequency.',
    practicalContext: 'Injected into audio amplifiers, communication modulators, and filters to measure frequency response curves.',
    relatedEquipmentId: 'eq-sig-gen'
  },
  {
    term: 'Spectrum Analyzer',
    category: 'Instruments',
    definition: 'Radio frequency instrument that measures the magnitude of an input signal versus frequency within its full operating frequency range.',
    practicalContext: 'Used to certify RF transmitters (Wi-Fi, Bluetooth, LoRa) for spectral emissions compliance and measure harmonic distortion.',
    relatedEquipmentId: 'eq-lora-module'
  },
  {
    term: 'True-RMS Multimeter',
    category: 'Instruments',
    definition: 'Digital multimeter that accurately computes the true root-mean-square heating value of complex, non-sinusoidal AC waveforms such as inverter outputs.',
    practicalContext: 'Standard cheap averaging meters read 10-30% low on chopped thyristor or switching inverter AC waves; True-RMS meters read accurately.',
    relatedEquipmentId: 'eq-dmm-fluke'
  },
  {
    term: '10X Passive Probe Compensation',
    category: 'Instruments',
    definition: 'Adjustable capacitive trimmer inside an oscilloscope probe that balances probe tip capacitance with scope input capacitance to maintain flat frequency response.',
    practicalContext: 'An uncompensated 10X probe rounds square waves or adds artificial overshoot spikes, leading to incorrect timing diagnostics.',
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    term: 'Constant Current (CC) / Constant Voltage (CV)',
    category: 'Instruments',
    definition: 'Dual operating modes of a laboratory DC power supply. In CV mode, voltage stays fixed while current fluctuates. In CC mode, current is clamped to a set limit.',
    practicalContext: 'When bringing up prototype boards for the first time, setting CC mode to 50mA prevents catastrophic smoke if a short circuit exists.',
    relatedEquipmentId: 'eq-dc-psu'
  },

  // Semiconductors
  {
    term: 'PN Junction Diode',
    category: 'Semiconductors',
    definition: 'Two-terminal semiconductor device that permits electric current to flow easily in one direction (forward bias) while blocking it in the reverse direction.',
    practicalContext: 'Used in full-wave bridge rectifiers converting AC to DC and as reverse-polarity protection in battery-powered circuits.',
    relatedEquipmentId: 'eq-analog-multimeter'
  },
  {
    term: 'BJT Transistor (NPN / PNP)',
    category: 'Semiconductors',
    definition: 'Current-controlled three-terminal semiconductor (Base, Collector, Emitter) where a tiny base current modulates a larger collector current: Ic = β × Ib.',
    practicalContext: 'Classic building block for low-noise audio preamps and simple digital level switching of relays.',
    relatedEquipmentId: 'eq-analog-multimeter'
  },
  {
    term: 'MOSFET (N-Channel / P-Channel)',
    category: 'Semiconductors',
    definition: 'Voltage-controlled Field Effect Transistor featuring an insulated gate terminal with near-zero static gate current draw, making it ideal for power switching.',
    practicalContext: 'Dominates modern motor drivers (H-bridges) and DC-DC buck converters due to very low on-state resistance (R_DS(on) in milliohms).',
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    term: 'Operational Amplifier (Op-Amp)',
    category: 'Semiconductors',
    definition: 'High-gain differential voltage amplifier with high input impedance and low output impedance, configured with negative feedback to create linear circuits.',
    practicalContext: 'Forms active filters, instrumentation amplifiers, analog summers, and sensor signal conditioning blocks.',
    relatedEquipmentId: 'eq-sig-gen'
  },
  {
    term: 'Schmitt Trigger',
    category: 'Semiconductors',
    definition: 'Comparator circuit that incorporates positive feedback to introduce hysteresis, having two distinct switching threshold levels for rising and falling edges.',
    practicalContext: 'Eliminates switch contact bounce and false triggering caused by noisy analog sensor inputs.',
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    term: 'Zener Diode',
    category: 'Semiconductors',
    definition: 'Specialized silicon diode designed to operate reliably in its reverse breakdown region, maintaining a stable reference voltage regardless of current variations.',
    practicalContext: 'Used for simple voltage reference bias lines and overvoltage clamping on sensitive ADC input pins.',
    relatedEquipmentId: 'eq-analog-multimeter'
  },
  {
    term: 'Optocoupler (Phototransistor)',
    category: 'Semiconductors',
    definition: 'Component that transfers electrical signals between two isolated circuits using light, providing thousands of volts of galvanic isolation.',
    practicalContext: 'Protects delicate microcontrollers from high-voltage AC mains spikes in industrial PLCs and motor drives.',
    relatedEquipmentId: 'eq-dso-1054'
  },

  // Protocols & Embedded
  {
    term: 'UART (Universal Asynchronous Receiver-Transmitter)',
    category: 'Protocols',
    definition: 'Asynchronous serial communication protocol using two wires (TX and RX) operating at predetermined baud rates without a shared clock line.',
    practicalContext: 'The primary debugging console output channel for ESP32, Arduino, and embedded Linux shells.',
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    term: 'I2C (Inter-Integrated Circuit)',
    category: 'Protocols',
    definition: 'Synchronous, multi-device, bidirectional two-wire serial bus (SDA data, SCL clock) using open-drain connections and pull-up resistors.',
    practicalContext: 'Connects sensors (accelerometers, barometers, OLED displays) to microcontrollers over distances under 30 cm.',
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    term: 'SPI (Serial Peripheral Interface)',
    category: 'Protocols',
    definition: 'High-speed synchronous 4-wire serial bus (MOSI, MISO, SCK, CS) enabling full-duplex data streaming at clock rates up to 50+ MHz.',
    practicalContext: 'Used for fast peripherals like SD cards, TFT color LCDs, and LoRa transceivers.',
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    term: 'CAN Bus (Controller Area Network)',
    category: 'Protocols',
    definition: 'Robust differential two-wire vehicle bus standard designed for noise immunity in automotive and industrial machinery with priority arbitration.',
    practicalContext: 'Standard for automotive ECUs, battery management systems in EVs, and industrial robotics.',
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    term: 'Pulse Width Modulation (PWM)',
    category: 'Protocols',
    definition: 'Technique for generating analog-like power delivery by pulsing a digital signal on and off at fixed frequency while varying the pulse width (duty cycle).',
    practicalContext: 'Controls LED brightness, servo horn position (1ms - 2ms pulse width), and brushless motor ESC speeds.',
    relatedEquipmentId: 'eq-esp32-devkit'
  },
  {
    term: 'Interrupt Service Routine (ISR)',
    category: 'Protocols',
    definition: 'Specialized low-overhead software routine executed immediately when a hardware event (like a button press or timer overflow) interrupts CPU flow.',
    practicalContext: 'Crucial for reading optical rotary encoders and handling emergency limit switch trip events without latency.',
    relatedEquipmentId: 'eq-esp32-devkit'
  },
  {
    term: 'Analog-to-Digital Converter (ADC) & Quantization',
    category: 'Protocols',
    definition: 'Electronic circuit that samples continuous analog voltage and converts it into a discrete digital binary representation (e.g., 10-bit or 12-bit).',
    practicalContext: 'A 12-bit ADC on 3.3V has a resolution of 3.3V / 4096 ≈ 0.8 mV per count, dictating minimum detectable sensor changes.',
    relatedEquipmentId: 'eq-esp32-devkit'
  },

  // RF & Wireless
  {
    term: 'LoRa (Long Range RF)',
    category: 'RF & Wireless',
    definition: 'Proprietary chirp spread spectrum (CSS) radio modulation technique enabling multi-kilometer battery-powered telemetry with deep receiver sensitivity (-148 dBm).',
    practicalContext: 'Ideal for agricultural sensors and smart meters transmitting tiny sensor packets across kilometers of hills without cellular fees.',
    relatedEquipmentId: 'eq-lora-module'
  },
  {
    term: 'Decibel-Milliwatts (dBm)',
    category: 'RF & Wireless',
    definition: 'Logarithmic unit of power ratio expressed in decibels referenced to one milliwatt: 0 dBm = 1 mW, 20 dBm = 100 mW, -30 dBm = 1 μW.',
    practicalContext: 'Standard metric for expressing receiver sensitivity and Wi-Fi transmitter output power in telecommunications.',
    relatedEquipmentId: 'eq-lora-module'
  },
  {
    term: 'Antenna Return Loss & VSWR',
    category: 'RF & Wireless',
    definition: 'Voltage Standing Wave Ratio (VSWR) measures impedance matching between transmission line and antenna. Low VSWR (< 1.5:1) indicates minimal reflected power.',
    practicalContext: 'A badly tuned antenna reflects transmitter power back into the output stage, overheating the RF power amplifier and drastically cutting range.',
    relatedEquipmentId: 'eq-lora-module'
  },
  {
    term: 'Quadrature Amplitude Modulation (QAM)',
    category: 'RF & Wireless',
    definition: 'Modulation scheme that conveys two digital message signals by modulating the amplitudes of two carrier waves 90 degrees out of phase (I and Q).',
    practicalContext: 'Used in modern Wi-Fi 6 (1024-QAM) and 5G cellular communication to achieve high data spectral efficiency.',
    relatedEquipmentId: 'eq-lora-module'
  },
  {
    term: 'Nyquist-Shannon Sampling Theorem',
    category: 'RF & Wireless',
    definition: 'Information theory law stating that an analog bandlimited signal can be perfectly reconstructed only if sampled at a rate greater than twice its highest frequency component (f_s > 2 f_max).',
    practicalContext: 'Dictates minimum oscilloscope sampling rate (e.g., 1 GSa/s for 100MHz analog bandwidth) to prevent aliasing distortions.',
    relatedEquipmentId: 'eq-dso-1054'
  },

  // Fabrication & Assembly
  {
    term: 'FR4 Glass Epoxy Substrate',
    category: 'Fabrication',
    definition: 'Industry standard composite material consisting of woven fiberglass cloth with an epoxy resin binder used as the dielectric core in printed circuit boards.',
    practicalContext: 'Provides high mechanical strength, dielectric breakdown resistance (>50 kV), and standard dielectric constant ε_r ≈ 4.4.',
    relatedEquipmentId: 'eq-solder-station'
  },
  {
    term: 'Eutectic Solder (63/37 Sn/Pb)',
    category: 'Fabrication',
    definition: 'Alloy with 63% tin and 37% lead that transitions instantaneously between liquid and solid phases at 183°C without an intermediate pasty plastic state.',
    practicalContext: 'Preferred in aerospace and educational prototyping because instantaneous freezing minimizes disturbed or fractured solder joints.',
    relatedEquipmentId: 'eq-solder-station'
  },
  {
    term: 'Rosin Flux & Oxide Reduction',
    category: 'Fabrication',
    definition: 'Chemical purifying agent applied during soldering that removes copper surface oxidation at elevated temperatures and promotes wetting.',
    practicalContext: 'Attempting to solder without flux produces balled-up solder bridges and high-resistance cold joints.',
    relatedEquipmentId: 'eq-solder-station'
  },
  {
    term: 'Thermal Relief Pad',
    category: 'Fabrication',
    definition: 'A printed circuit board pad connected to a large copper ground plane through narrow spoke traces rather than a solid pour.',
    practicalContext: 'Prevents the massive copper ground plane from acting as an uncontrollable heat sink, making hand soldering possible without overheating the component.',
    relatedEquipmentId: 'eq-solder-station'
  },
  {
    term: 'Silkscreen & Designators',
    category: 'Fabrication',
    definition: 'Ink layer printed on a PCB surface indicating component outlines, reference designators (R1, C1, U1), polarity marks, and safety warnings.',
    practicalContext: 'Ensures correct orientation of polarized electrolytic capacitors and IC pin 1 notches during assembly.',
    relatedEquipmentId: 'eq-solder-station'
  },
  {
    term: 'Cold Solder Joint',
    category: 'Fabrication',
    definition: 'Defective electrical connection caused when solder fails to melt fully, the work piece was moved during cooling, or the copper was oxidized.',
    practicalContext: 'Appears dull and grainy instead of shiny and concave; causes intermittent circuit failures when vibrations occur.',
    relatedEquipmentId: 'eq-solder-station'
  }
];
