import { Lesson } from '../types';

export const ACADEMY_LESSONS: Lesson[] = [
  {
    id: 'lesson-basic-electricity',
    pathId: 'path-foundations',
    title: '1. Basic Electricity & Electrical Charge',
    category: 'Fundamentals',
    order: 1,
    difficulty: 'Beginner',
    readTime: '6 min read',
    objectives: [
      'Understand the nature of electrons, atoms, and electrical charge',
      'Distinguish between conductors, insulators, and semiconductors',
      'Identify complete closed circuits versus open circuits'
    ],
    explanation: 'Electricity is the physical flow of tiny subatomic particles called electrons. In conductive materials like copper, valence electrons are loosely bound and jump freely between atoms when stimulated by an electric field. An electric circuit requires a closed loop: without a continuous conductive path back to the power source, electrons stop flowing immediately.',
    practicalExamples: [
      'Flashlight switch: closes the copper path between batteries and bulb filament',
      'Wall phone charger: converts 230V AC mains into 5V DC electron flow',
      'Static discharge: electrons jumping from carpet to door handle'
    ],
    requiredComponents: ['1.5V AA Battery Cell', 'Miniature 3V Incandescent Lamp or LED', 'Alligator Clip Test Leads', 'Conductive strip (foil) vs Plastic insulator'],
    stepByStepInstructions: [
      '1. Connect the positive terminal (+) of the battery to one terminal of the lamp holder using an alligator wire.',
      '2. Connect the second wire to the lamp, but leave the other end floating (open circuit). Observe that the lamp remains unlit.',
      '3. Touch the free wire to the negative terminal (-) of the battery to close the circuit loop. Observe instant illumination.',
      '4. Insert a piece of paper or plastic between the wire and battery. Note that the non-conductive barrier breaks the electron circuit.'
    ],
    expectedObservations: [
      'The lamp turns on instantly when the circuit loop is completed without gaps.',
      'Inserting insulators (wood, plastic, paper) stops current immediately.',
      'Inserting metals (copper coin, steel clip, brass key) allows illumination.'
    ],
    commonMistakes: [
      'Leaving battery terminals directly short-circuited together without a load, causing rapid chemical heating.',
      'Confusing conventional current flow (positive to negative) with actual electron flow (negative to positive).'
    ],
    troubleshooting: [
      'If lamp does not illuminate, verify battery voltage with a multimeter.',
      'Check for oxidized coatings or varnish on test wires.'
    ],
    quiz: [
      {
        id: 'q-elec-1',
        question: 'What is required for electric current to flow through a circuit?',
        options: [
          'An open switch',
          'A closed continuous conductive loop',
          'An insulating air gap',
          'A high magnetic field only'
        ],
        correctIndex: 1,
        explanation: 'Electrons require an uninterrupted conductive path from higher potential back to ground/lower potential.'
      },
      {
        id: 'q-elec-2',
        question: 'Which of the following is an electrical conductor?',
        options: ['Dry wood', 'Ceramic porcelain', 'Copper wire', 'Pure glass'],
        correctIndex: 2,
        explanation: 'Copper has loosely bound valence electrons that drift freely under electric potential.'
      }
    ],
    relatedEquipmentId: 'eq-dmm-fluke',
    relatedEquipmentName: 'True-RMS Digital Multimeter',
    simulationExperimentId: 'ohms_law'
  },
  {
    id: 'lesson-voltage-current-resistance',
    pathId: 'path-foundations',
    title: '2. Voltage, Current, Resistance & Ohm’s Law',
    category: 'Fundamentals',
    order: 2,
    difficulty: 'Beginner',
    readTime: '8 min read',
    objectives: [
      'Define Voltage (V in Volts), Current (I in Amperes), and Resistance (R in Ohms)',
      'Apply Ohm’s Law formula V = I × R to compute unknown circuit parameters',
      'Measure voltage drops and currents using a digital multimeter'
    ],
    explanation: 'Think of electricity as water flowing in a pipe: Voltage is the water pressure pushing electrons; Current is the flow rate of electrons (1 Ampere = 6.24 × 10^18 electrons per second); Resistance is the pipe constriction opposing flow. Georg Ohm proved that current is directly proportional to voltage and inversely proportional to resistance: V = I × R.',
    practicalExamples: [
      'Volume knob: a variable resistor (potentiometer) restricting audio signal current',
      'Electric stove burner: high resistance nichrome wire converting electrical current into heat',
      'Multimeter safety fuse: burns open if current exceeds 10 Amperes'
    ],
    requiredComponents: ['Variable DC Bench Power Supply or 9V Battery', '1kΩ and 330Ω Resistors', 'Digital Multimeter with Test Probes', 'Breadboard'],
    stepByStepInstructions: [
      '1. Insert a 1,000Ω (1kΩ) resistor into the breadboard.',
      '2. Set the power supply to 5.0V and connect it across the resistor terminals.',
      '3. Turn on the multimeter, select DC Volts mode, and touch probes across the resistor to confirm 5.0V.',
      '4. Switch the meter to DC Milliamps (mA), break the loop, and place the meter in series to measure current: I = 5V / 1000Ω = 5 mA.',
      '5. Double voltage to 10V and observe that current proportionally doubles to 10 mA.'
    ],
    expectedObservations: [
      'At 5V with 1kΩ, current reads approximately 5.0 mA (±5% resistor tolerance).',
      'Doubling voltage doubles the current; doubling resistance cuts current in half.'
    ],
    commonMistakes: [
      'Plugging multimeter in parallel while in current (A/mA) mode, creating a dead short that blows the internal meter fuse.',
      'Reading resistor color bands in reverse order.'
    ],
    troubleshooting: [
      'Meter reads 0.00 mA: Check if red lead is plugged into the dedicated mA jack rather than the V/Ω jack.',
      'Check if internal fuse has blown by testing continuity across meter jacks with another meter.'
    ],
    quiz: [
      {
        id: 'q-ohm-1',
        question: 'If a 12V voltage source is connected across a 4Ω resistor, what current flows?',
        options: ['48 Amperes', '3 Amperes', '0.33 Amperes', '8 Amperes'],
        correctIndex: 1,
        explanation: 'According to Ohm’s Law: I = V / R = 12V / 4Ω = 3 Amperes.'
      },
      {
        id: 'q-ohm-2',
        question: 'What happens to the current in a circuit if the resistance is doubled while voltage remains constant?',
        options: ['Current doubles', 'Current halves', 'Current stays the same', 'Current drops to zero'],
        correctIndex: 1,
        explanation: 'Current is inversely proportional to resistance (I = V/R), so doubling R cuts current by half.'
      }
    ],
    relatedEquipmentId: 'eq-dc-psu',
    relatedEquipmentName: 'Precision Variable Linear DC Power Supply',
    simulationExperimentId: 'ohms_law'
  },
  {
    id: 'lesson-series-parallel',
    pathId: 'path-foundations',
    title: '3. Series and Parallel Circuits',
    category: 'Circuit Analysis',
    order: 3,
    difficulty: 'Beginner',
    readTime: '7 min read',
    objectives: [
      'Calculate equivalent resistance for series (R_eq = R1 + R2) and parallel (1/R_eq = 1/R1 + 1/R2) circuits',
      'Understand Kirchhoff’s Voltage Law (KVL) and Kirchhoff’s Current Law (KCL)',
      'Analyze why household sockets are wired in parallel rather than series'
    ],
    explanation: 'In a Series circuit, components are connected end-to-end like train cars: the current is identical through every component, while total voltage divides across them. In a Parallel circuit, components share common nodes: the voltage across each branch is identical, while the total supply current splits between branches.',
    practicalExamples: [
      'Old holiday string lights: wired in series—if one bulb filament snaps, the entire string goes dark.',
      'Household wall outlets: wired in parallel—unplugging your laptop charger leaves the lamp illuminated at constant 230V.',
      'Car battery jump-start: connected in parallel to maintain 12V while doubling starting current capacity.'
    ],
    requiredComponents: ['3x 1kΩ Resistors', 'Digital Multimeter', 'Breadboard and Jumper Wires', 'DC Power Supply'],
    stepByStepInstructions: [
      '1. Series Setup: Place two 1kΩ resistors end-to-end on breadboard. Measure total resistance across outer ends: R_eq = 1k + 1k = 2.0 kΩ.',
      '2. Apply 6V across the series chain. Measure voltage across each resistor with DMM: both show 3.0V (KVL verified).',
      '3. Parallel Setup: Place two 1kΩ resistors side-by-side sharing common power and ground rails.',
      '4. Measure parallel resistance: R_eq = (1k × 1k) / (1k + 1k) = 500 Ω.',
      '5. Apply 6V: both resistors experience the full 6V, and each draws 6 mA, totaling 12 mA from the supply (KCL verified).'
    ],
    expectedObservations: [
      'Adding resistors in series increases total circuit resistance.',
      'Adding resistors in parallel decreases total equivalent resistance below any individual branch.'
    ],
    commonMistakes: [
      'Assuming parallel resistors split voltage. Parallel branches always share the same voltage potential.'
    ],
    troubleshooting: [
      'Check breadboard contact clips: breadboard tie-points run in vertical columns of 5 holes.'
    ],
    quiz: [
      {
        id: 'q-sp-1',
        question: 'Two 100Ω resistors are connected in parallel. What is their equivalent resistance?',
        options: ['200 Ω', '100 Ω', '50 Ω', '25 Ω'],
        correctIndex: 2,
        explanation: 'For two identical resistors in parallel, R_eq = R / 2 = 100Ω / 2 = 50Ω.'
      }
    ],
    relatedEquipmentId: 'eq-breadboard-pack',
    relatedEquipmentName: 'Twin 830-Point Breadboards & Jumper Wires',
    simulationExperimentId: 'series_parallel'
  },
  {
    id: 'lesson-components-symbols',
    pathId: 'path-foundations',
    title: '4. Electronic Components & Circuit Symbols',
    category: 'Circuit Analysis',
    order: 4,
    difficulty: 'Beginner',
    readTime: '6 min read',
    objectives: [
      'Read and interpret standard schematic symbols (resistors, capacitors, inductors, grounds, switches)',
      'Decode 4-band and 5-band through-hole resistor color codes',
      'Distinguish polarized components (electrolytic capacitors, diodes) from non-polarized components'
    ],
    explanation: 'Schematics are the architectural blueprints of electronics. Standardized IEC and IEEE symbols represent components abstractly so any engineer worldwide can reproduce the circuit. Always pay strict attention to component polarity: inserting electrolytic capacitors or diodes backwards can cause component failure or rupture.',
    practicalExamples: [
      'Bypass capacitors: placed right next to microcontroller chips to suppress high-frequency supply ripple',
      'Pull-up resistor: keeps a pushbutton digital input pin firmly at logic HIGH (3.3V) when not pressed'
    ],
    requiredComponents: ['Assorted Ceramic and Electrolytic Capacitors', 'Assorted 1/4W Resistors', 'Breadboard', 'Schematic Diagram Sheet'],
    stepByStepInstructions: [
      '1. Inspect an electrolytic capacitor: locate the silver negative stripe (-) indicating the shorter cathode lead.',
      '2. Inspect a 1/4W resistor: align bands with the gold or silver tolerance band on the right. Decode digits from left to right.',
      '3. Match schematic symbols on paper with their physical hardware counterparts on your workbench.'
    ],
    expectedObservations: [
      'Ceramic disc capacitors (marked 104) are non-polarized and read 100 nF (0.1 μF).',
      'Electrolytic capacitors have explicit polarity stripes and longer positive anode leads.'
    ],
    commonMistakes: [
      'Connecting electrolytic capacitors in reverse polarity, leading to electrolyte venting.'
    ],
    troubleshooting: [
      'Use the capacitance testing mode on a True-RMS DMM to verify unmarked surface-mount capacitors.'
    ],
    quiz: [
      {
        id: 'q-sym-1',
        question: 'What does a straight line with an arrow pointing to a vertical bar represent in schematics?',
        options: ['Resistor', 'PN Junction Diode', 'Bipolar Transistor', 'Ground'],
        correctIndex: 1,
        explanation: 'The arrow represents the anode pointing toward the cathode bar, indicating forward current direction.'
      }
    ],
    relatedEquipmentId: 'eq-lab-kit-full',
    relatedEquipmentName: 'Complete ENTC Analog & Digital Kit',
    simulationExperimentId: 'led_resistor'
  },
  {
    id: 'lesson-diodes-transistors',
    pathId: 'path-semiconductors',
    title: '5. Diodes, LEDs & Transistor Switching',
    category: 'Semiconductors',
    order: 5,
    difficulty: 'Intermediate',
    readTime: '9 min read',
    objectives: [
      'Understand PN junction behavior, forward voltage drop (V_f ≈ 0.7V for Silicon, ~2.0V for Red LED)',
      'Size a current-limiting resistor for LEDs to prevent thermal blowout',
      'Use a BJT NPN transistor (2N2222 / BC547) as an electronic switch to drive heavy DC loads'
    ],
    explanation: 'A diode is a one-way electronic valve. LEDs (Light Emitting Diodes) emit photons when electrons recombine with electron holes in forward bias. Because LEDs exhibit low dynamic resistance once forward biased, you must ALWAYS include a series resistor: R = (V_supply - V_f) / I_led. Transistors act as electronically controlled switches: a tiny current into the Base terminal turns ON a large current through Collector-Emitter.',
    practicalExamples: [
      'Smartphone screen backlights: strings of white LEDs driven with constant-current drivers',
      'Microcontroller relay driver: an ESP32 pin (12mA limit) controls a 200mA relay coil via an NPN transistor',
      'Flyback diode: absorbs reverse inductive voltage spikes across relay coils and DC motor windings'
    ],
    requiredComponents: ['5mm Red LED', '1kΩ and 330Ω Resistors', '2N2222 NPN Transistor', '5V Power Supply', 'Pushbutton Switch'],
    stepByStepInstructions: [
      '1. Connect 5V to breadboard. Place 330Ω resistor in series with Red LED (anode long leg to resistor, cathode flat edge to GND).',
      '2. Verify LED illuminates cleanly. Measure current: (5V - 2.0V) / 330Ω ≈ 9.1 mA (safe range).',
      '3. Transistor Switch: Connect 2N2222 Emitter to GND.',
      '4. Connect Collector to LED cathode through a 220Ω resistor. Connect LED anode to 5V rail.',
      '5. Connect Base to 5V through a 10kΩ resistor via a pushbutton switch.',
      '6. Press the pushbutton: injecting 0.4mA into the Base fully saturates the transistor, lighting the LED.'
    ],
    expectedObservations: [
      'Without base current, transistor Collector-Emitter path is an open circuit (LED OFF).',
      'Injecting base current saturates the transistor with V_ce(sat) < 0.2V (LED ON).'
    ],
    commonMistakes: [
      'Connecting an LED directly across 5V without a current-limiting resistor, causing immediate burnout within 500ms.',
      'Swapping Collector and Emitter leads on the transistor package.'
    ],
    troubleshooting: [
      'Transistor gets hot: base resistor is too low or load is short-circuited.',
      'LED won’t light: reverse LED leads (anode is longer lead with rounded cup; cathode has flat edge on lens rim).'
    ],
    quiz: [
      {
        id: 'q-dio-1',
        question: 'What is the required resistance for a Red LED (V_f = 2.0V, I = 15mA) powered by a 5.0V supply?',
        options: ['100 Ω', '200 Ω', '1,000 Ω', '330 Ω'],
        correctIndex: 1,
        explanation: 'R = (V_s - V_f) / I = (5.0V - 2.0V) / 0.015A = 3.0V / 0.015A = 200 Ω.'
      }
    ],
    relatedEquipmentId: 'eq-lab-kit-full',
    relatedEquipmentName: 'Complete ENTC Analog & Digital Kit',
    simulationExperimentId: 'transistor_switch'
  },
  {
    id: 'lesson-logic-gates',
    pathId: 'path-digital',
    title: '6. Digital Electronics & Logic Gates',
    category: 'Digital Systems',
    order: 6,
    difficulty: 'Intermediate',
    readTime: '8 min read',
    objectives: [
      'Master binary boolean logic: AND, OR, NOT, NAND, NOR, and XOR truth tables',
      'Interface 74LSxx TTL logic integrated circuits (ICs) on a breadboard',
      'Implement a half-adder combinational logic circuit for 1-bit arithmetic'
    ],
    explanation: 'Digital electronics abstracts continuous analog voltages into two discrete logic states: HIGH (1, typically 5V or 3.3V) and LOW (0, 0V). Logic gates are the fundamental decision-making blocks in microprocessors. NAND and NOR are called "Universal Gates" because any conceivable boolean function can be built exclusively from them.',
    practicalExamples: [
      'Automotive seatbelt buzzer: BUZZER = (IGNITION == 1) AND (SEATBELT_BUCKLED == 0)',
      'Digital safe combination lock: built from cascaded logic gates and flip-flops',
      'ALU (Arithmetic Logic Unit): millions of XOR, AND, and OR gates adding numbers in CPU cores'
    ],
    requiredComponents: ['74LS08 (Quad AND)', '74LS32 (Quad OR)', '74LS04 (Hex NOT)', 'Breadboard', '2x Pushbuttons', 'LED indicators', '5V Power Supply'],
    stepByStepInstructions: [
      '1. Place 74LS08 (AND gate IC) across breadboard center groove. Connect Pin 14 to +5V (Vcc) and Pin 7 to GND.',
      '2. Wire two pull-down switches to Pin 1 (Input A) and Pin 2 (Input B).',
      '3. Connect Pin 3 (Output Y) to an LED with a 330Ω ballast resistor to GND.',
      '4. Test all 4 combinations: (0,0), (0,1), (1,0), (1,1). Observe LED only lights for (1,1).'
    ],
    expectedObservations: [
      'AND gate output is strictly 1 only when BOTH inputs A and B are simultaneously HIGH.',
      'Floating TTL inputs can drift to logic HIGH due to internal pull-ups; always wire pull-downs.'
    ],
    commonMistakes: [
      'Forgetting to connect Vcc (Pin 14) and GND (Pin 7) power rails to the IC.',
      'Leaving input pins disconnected (floating).'
    ],
    troubleshooting: [
      'IC feels hot: check if IC was plugged in backwards (notch must point toward Pin 1 / top-left).'
    ],
    quiz: [
      {
        id: 'q-log-1',
        question: 'Which logic gate produces a LOW (0) output ONLY when all inputs are HIGH (1)?',
        options: ['AND Gate', 'NAND Gate', 'OR Gate', 'XOR Gate'],
        correctIndex: 1,
        explanation: 'A NAND gate is an inverted AND gate: output is 0 only when both inputs are 1.'
      }
    ],
    relatedEquipmentId: 'eq-lab-kit-full',
    relatedEquipmentName: 'Complete ENTC Practice Kit',
    simulationExperimentId: 'logic_gates'
  },
  {
    id: 'lesson-arduino-esp32',
    pathId: 'path-microcontrollers',
    title: '7. Arduino & ESP32 Microcontroller Programming',
    category: 'Embedded Systems',
    order: 7,
    difficulty: 'Beginner',
    readTime: '9 min read',
    objectives: [
      'Understand the microcontroller anatomy: CPU, Flash, SRAM, GPIO, Timers, ADC, and DAC',
      'Master the setup() and loop() execution paradigm in C/C++',
      'Control digital outputs (LEDs) and read digital inputs (pushbuttons) with debouncing'
    ],
    explanation: 'A microcontroller is a complete computer on a single chip. While a desktop CPU requires external RAM, SSD, and motherboards, an ESP32 or ATmega328P integrates processor, memory, and programmable physical input/output (GPIO) pins on one die. Code written in the Arduino IDE compiles to machine instructions that manipulate hardware registers thousands of times per second.',
    practicalExamples: [
      'Microwave timer panel: microcontroller monitoring button presses and driving relay and buzzer',
      '3D printer controller: reads temperature sensors and pulses stepper motors thousands of times per second',
      'Automotive anti-lock brake controller (ABS): reads wheel speed sensors in real time'
    ],
    requiredComponents: ['ESP32 DevKit or Arduino Uno R3', 'USB Data Cable', 'Breadboard', 'LED and 220Ω Resistor', 'Pushbutton'],
    stepByStepInstructions: [
      '1. Connect microcontroller to PC via USB cable. Launch Arduino IDE and select correct COM port.',
      '2. Wire an LED from GPIO pin (e.g. GPIO 2 on ESP32 or Pin 13 on Arduino) through 220Ω to GND.',
      '3. Open Examples -> 01.Basics -> Blink.',
      '4. Click Upload and watch the RX/TX LEDs flash during programming.',
      '5. Modify delay(1000) to delay(200) and re-upload to observe high-speed flashing.'
    ],
    expectedObservations: [
      'The LED switches state predictably according to firmware delays.',
      'Firmware persists in non-volatile flash memory and runs immediately upon power-up without a PC.'
    ],
    commonMistakes: [
      'Using a cheap "charge-only" USB cable that lacks D+ and D- data lines, preventing PC serial detection.',
      'Overloading GPIO pins beyond their maximum drive capacity (12mA for ESP32, 20mA for Arduino).'
    ],
    troubleshooting: [
      'Port not appearing in IDE: Install CP2102 or CH340 USB-UART bridge driver.',
      'ESP32 flash timeout: Hold down BOOT button when "Connecting..." appears in terminal.'
    ],
    quiz: [
      {
        id: 'q-mcu-1',
        question: 'Which function runs repeatedly and indefinitely in an Arduino sketch?',
        options: ['setup()', 'main()', 'loop()', 'start()'],
        correctIndex: 2,
        explanation: 'setup() executes once on power-up/reset; loop() executes repeatedly forever.'
      }
    ],
    relatedEquipmentId: 'eq-esp32-devkit',
    relatedEquipmentName: 'ESP32 IoT Development & Sensor Suite',
    simulationExperimentId: 'mcu_io'
  },
  {
    id: 'lesson-sensors-actuators',
    pathId: 'path-microcontrollers',
    title: '8. Sensors & Actuators Interfacing',
    category: 'Embedded Systems',
    order: 8,
    difficulty: 'Intermediate',
    readTime: '8 min read',
    objectives: [
      'Interface analog sensors (thermistor, LDR, potentiometer) using Analog-to-Digital Converters (ADC)',
      'Interface digital sensors (ultrasonic HC-SR04, DHT22) with timing protocols',
      'Drive actuators (servo motors, DC motors, buzzer) using Pulse Width Modulation (PWM)'
    ],
    explanation: 'Sensors translate physical quantities (temperature, sound, light, distance) into electrical signals. Actuators do the reverse: converting electrical signals into physical action (motion, sound, light). Analog sensors output a continuous voltage read by an ADC (e.g. 12-bit ADC on ESP32 yields values from 0 to 4095). Actuators like servos interpret PWM pulse widths (1ms to 2ms) to position output shafts.',
    practicalExamples: [
      'Air conditioner thermostat: thermistor sensor reading room temperature to cycle the compressor relay',
      'Drone gimbal: brushless servo actuators maintaining camera horizon stability from gyroscope data',
      'Automatic soap dispenser: infrared optical sensor triggering a miniature peristaltic pump'
    ],
    requiredComponents: ['ESP32 or Arduino', 'HC-SR04 Ultrasonic Sensor', 'SG90 Micro Servo', 'LDR Light Sensor', '10kΩ Resistor', 'Breadboard'],
    stepByStepInstructions: [
      '1. Ultrasonic Sensor: Wire VCC to 5V, GND to GND, TRIG to GPIO 5, ECHO to GPIO 18 (with voltage divider for 3.3V ESP32).',
      '2. Pulse TRIG pin HIGH for 10 microseconds to emit an 8-cycle 40 kHz acoustic burst.',
      '3. Measure pulse duration on ECHO pin using pulseIn(): Distance = (Time in μs × 0.0343) / 2.',
      '4. Connect SG90 servo signal wire to GPIO 13. Map distance (5cm - 50cm) to servo angle (0° - 180°).'
    ],
    expectedObservations: [
      'Distance reads in real time on the Serial Monitor at ~10 Hz update rate.',
      'Moving your hand closer smoothly rotates the servo arm.'
    ],
    commonMistakes: [
      'Connecting HC-SR04 5V ECHO output directly to ESP32 3.3V GPIO without a voltage divider.',
      'Powering servos directly from microcontroller 3.3V pin, causing brownouts when the motor starts.'
    ],
    troubleshooting: [
      'Ultrasonic sensor reads 0 or 3000cm: verify 10μs trigger pulse width and target reflection angle.'
    ],
    quiz: [
      {
        id: 'q-sen-1',
        question: 'Why do ultrasonic distance sensors divide echo travel time by 2?',
        options: [
          'Sound travels twice as fast in air',
          'The acoustic pulse travels to the target and back',
          'To compensate for temperature',
          'Because of ADC resolution'
        ],
        correctIndex: 1,
        explanation: 'The sound wave makes a round-trip (out to target and reflecting back), so one-way distance is half.'
      }
    ],
    relatedEquipmentId: 'eq-sensor-kit-37',
    relatedEquipmentName: '37-in-1 Ultimate Sensor Kit',
    simulationExperimentId: 'temp_fan'
  },
  {
    id: 'lesson-embedded-systems',
    pathId: 'path-embedded',
    title: '9. Embedded Systems & Serial Communication (UART, I2C, SPI)',
    category: 'Embedded Systems',
    order: 9,
    difficulty: 'Intermediate',
    readTime: '9 min read',
    objectives: [
      'Compare bus topologies: UART (asynchronous 2-wire), I2C (synchronous 2-wire multi-device), SPI (synchronous 4-wire high-speed)',
      'Analyze baud rate, start/stop framing, and parity in UART',
      'Use an oscilloscope to visually inspect serial data packets and clock jitter'
    ],
    explanation: 'Chips inside an electronics device communicate using serial protocols. UART connects two devices without a clock line using matched baud rates (e.g. 115200 bps). I2C uses two bidirectional open-drain lines (SDA data, SCL clock) with pull-up resistors to connect up to 127 addressed sensors. SPI uses dedicated clock (SCK), data out (MOSI), data in (MISO), and chip select (CS) lines for ultra-high-speed transfers up to 50 MHz.',
    practicalExamples: [
      'OLED displays: communicate with ESP32 over I2C at address 0x3C using only 2 pins',
      'SD Cards: transfer megabytes of telemetry data to microcontrollers over high-speed SPI bus',
      'GPS modules: stream NMEA sentence packets to navigation computers over UART at 9600 baud'
    ],
    requiredComponents: ['ESP32 DevKit', '0.96" I2C OLED (SSD1306)', 'Rigol Digital Storage Oscilloscope', 'Breadboard'],
    stepByStepInstructions: [
      '1. Connect OLED SDA to ESP32 GPIO 21 and SCL to GPIO 22.',
      '2. Run an I2C address scanner sketch to confirm device acknowledges at address 0x3C.',
      '3. Connect DSO Probe 1 to SCL clock and Probe 2 to SDA data line.',
      '4. Set oscilloscope trigger to falling edge on SDA and timebase to 2.5 μs/div.',
      '5. Inspect the START condition (SDA drops while SCL is HIGH) and observe 8 clock pulses followed by the ACK bit.'
    ],
    expectedObservations: [
      'Clean square clock bursts visible on SCL at 100 kHz or 400 kHz standard rates.',
      'DSO protocol decoder decodes hex address 0x3C directly on screen.'
    ],
    commonMistakes: [
      'Swapping SDA and SCL lines.',
      'Missing I2C pull-up resistors (4.7kΩ) on custom sensor breakout boards.'
    ],
    troubleshooting: [
      'OLED remains blank: verify 3.3V supply and run I2C scanner sketch to verify bus address.'
    ],
    quiz: [
      {
        id: 'q-emb-1',
        question: 'Which serial communication protocol requires only 2 wires and uses unique device addresses?',
        options: ['SPI', 'UART', 'I2C', 'Parallel 8-bit'],
        correctIndex: 2,
        explanation: 'I2C uses SDA and SCL with unique 7-bit device addresses to share a single bus.'
      }
    ],
    relatedEquipmentId: 'eq-dso-1054',
    relatedEquipmentName: 'Rigol 100MHz 4-Channel DSO',
    simulationExperimentId: 'mcu_io'
  },
  {
    id: 'lesson-iot-cloud',
    pathId: 'path-iot',
    title: '10. Internet of Things (IoT) & Cloud Telemetry',
    category: 'Internet of Things',
    order: 10,
    difficulty: 'Intermediate',
    readTime: '8 min read',
    objectives: [
      'Understand the IoT architecture: Device Layer, Gateway, MQTT Broker, and Dashboard',
      'Publish telemetry data over Wi-Fi using the lightweight MQTT protocol',
      'Implement deep-sleep power management to run IoT sensor nodes for months on battery'
    ],
    explanation: 'The Internet of Things connects physical objects to internet clouds. Traditional HTTP has heavy header overhead; IoT devices use MQTT (Message Queuing Telemetry Transport)—an extremely lightweight publish-subscribe protocol with tiny 2-byte packet headers. To survive on battery, IoT microcontrollers spend 99% of their life in Deep Sleep (consuming < 15 microamps), waking up for 200ms to read sensors and publish packets.',
    practicalExamples: [
      'Smart agricultural soil probe: broadcasts soil moisture and salinity over MQTT every 30 minutes',
      'Smart home energy meter: streams RMS wattage to home automation server over local Wi-Fi',
      'Industrial motor bearing vibration monitor: predicts mechanical failure via cloud anomalies'
    ],
    requiredComponents: ['ESP32 DevKit', 'DHT22 Temperature Sensor', 'Wi-Fi Connection', 'Free MQTT Broker (HiveMQ or EMQX)'],
    stepByStepInstructions: [
      '1. Connect DHT22 data pin to ESP32 GPIO 4 with a 10kΩ pull-up resistor.',
      '2. Connect ESP32 to Wi-Fi credentials in sketch setup.',
      '3. Connect to MQTT broker (broker.hivemq.com on port 1883).',
      '4. Format sensor readings into JSON payload: {"temp": 24.8, "humidity": 45.2}.',
      '5. Publish to topic: entcverse/lab/sensor1.',
      '6. Open web dashboard to view live streamed telemetry.'
    ],
    expectedObservations: [
      'Live temperature and humidity readings appear on remote dashboard within 50ms of publishing.',
      'ESP32 current drops from 80mA (active Wi-Fi transmit) to 15μA during deep sleep.'
    ],
    commonMistakes: [
      'Publishing too frequently (e.g. every 50ms) causing broker connection throttling.',
      'Hardcoding Wi-Fi credentials into public GitHub repositories.'
    ],
    troubleshooting: [
      'MQTT connection error (-2): check if Wi-Fi network blocks outbound port 1883 (common on college captive portals).'
    ],
    quiz: [
      {
        id: 'q-iot-1',
        question: 'Why is MQTT preferred over HTTP for battery-powered IoT devices?',
        options: [
          'It uses more bandwidth',
          'It has minimal header overhead and supports publish-subscribe architecture',
          'It requires continuous video streaming',
          'It operates without IP addresses'
        ],
        correctIndex: 1,
        explanation: 'MQTT is designed for constrained networks with low packet overhead and asynchronous pub/sub.'
      }
    ],
    relatedEquipmentId: 'eq-esp32-devkit',
    relatedEquipmentName: 'ESP32 IoT Development & Sensor Suite',
    simulationExperimentId: 'temp_fan'
  },
  {
    id: 'lesson-comm-fundamentals',
    pathId: 'path-telecom',
    title: '11. Analog & Digital Communication Fundamentals',
    category: 'Telecommunication',
    order: 11,
    difficulty: 'Advanced',
    readTime: '9 min read',
    objectives: [
      'Understand modulation fundamentals: Carrier waves, Amplitude Modulation (AM), and Frequency Modulation (FM)',
      'Explore digital modulation: Amplitude Shift Keying (ASK), Frequency Shift Keying (FSK), and Phase Shift Keying (PSK)',
      'Understand the Nyquist-Shannon Sampling Theorem (f_sample ≥ 2 × f_max)'
    ],
    explanation: 'Baseband signals (voice, audio, data) cannot travel long distances through air because low frequencies require impractically large antennas (antenna length ≈ λ/4). Modulation superimposes the information signal onto a high-frequency carrier wave. In AM, message amplitude modulates carrier height; in FM, message modulates carrier instantaneous frequency. In digital communications, bits shift the carrier frequency (FSK) or phase (BPSK/QPSK).',
    practicalExamples: [
      'FM Radio broadcast: 88 MHz - 108 MHz carrier modulated by high-fidelity audio up to 15 kHz',
      'RFID keycards: use 125 kHz or 13.56 MHz carrier wave with ASK modulation',
      '4G and 5G cellular: multi-carrier Orthogonal Frequency Division Multiplexing (OFDM) with 256-QAM'
    ],
    requiredComponents: ['Arbitrary Function Generator', 'Digital Storage Oscilloscope with FFT', 'BNC Coaxial Leads'],
    stepByStepInstructions: [
      '1. Set function generator Channel 1 to Carrier: 1 MHz Sine Wave at 1.0 Vpp.',
      '2. Enable AM modulation with internal 1 kHz Sine message at 80% modulation depth.',
      '3. Connect generator output to DSO Channel 1. Adjust timebase to 200 μs/div to view the modulated AM envelope.',
      '4. Switch DSO to MATH -> FFT (Fast Fourier Transform). Observe the carrier peak at 1 MHz and two sidebands at 999 kHz and 1001 kHz.'
    ],
    expectedObservations: [
      'Envelope height expands and contracts in exact synchrony with the 1 kHz audio message.',
      'FFT spectrum analyzer clearly resolves carrier and upper/lower sidebands separated by 1 kHz.'
    ],
    commonMistakes: [
      'Over-modulation (> 100% depth) in AM, causing envelope pinch-off and severe audio distortion.'
    ],
    troubleshooting: [
      'Waveform appears unstable: adjust DSO Trigger Type to Edge, Source to CH1, and Level to 0V.'
    ],
    quiz: [
      {
        id: 'q-com-1',
        question: 'According to the Nyquist Sampling Theorem, what is the minimum sampling frequency required for a 20 kHz audio signal?',
        options: ['10 kHz', '20 kHz', '40 kHz', '100 kHz'],
        correctIndex: 2,
        explanation: 'The sampling rate must be at least twice the maximum frequency component: f_s ≥ 2 × 20 kHz = 40 kHz.'
      }
    ],
    relatedEquipmentId: 'eq-sig-gen',
    relatedEquipmentName: 'Siglent 30MHz Function Generator',
    simulationExperimentId: 'ohms_law'
  },
  {
    id: 'lesson-wireless-rf',
    pathId: 'path-telecom',
    title: '12. Wireless Communication Fundamentals & LoRa',
    category: 'Telecommunication',
    order: 12,
    difficulty: 'Advanced',
    readTime: '9 min read',
    objectives: [
      'Understand RF propagation, Path Loss, and Friis Transmission Equation',
      'Master LoRa Chirp Spread Spectrum (CSS) modulation for ultra-long range links',
      'Optimize Spreading Factor (SF), Bandwidth (BW), and Coding Rate (CR) trade-offs'
    ],
    explanation: 'Wireless communication transmits electromagnetic energy through free space. High-frequency signals (Wi-Fi 5 GHz) carry huge bandwidth but suffer severe attenuation through walls. LoRa (Long Range) operates at lower sub-gigahertz ISM bands (868 MHz / 915 MHz) and uses Chirp Spread Spectrum: continuously sweeping carrier frequencies across bandwidth to decode signals up to 20 dB BELOW the ambient RF noise floor.',
    practicalExamples: [
      'Smart water meters: send daily meter readings from underground vaults to city gateways over LoRa',
      'Forest fire early warning network: LoRa sensors deployed across national parks broadcasting smoke alerts',
      'Satellite LoRa links: direct telemetry uplinks from maritime buoys to Low Earth Orbit satellites'
    ],
    requiredComponents: ['Pair of SX1276/SX1278 LoRa Breakout Modules with Antennas', '2x ESP32 Microcontrollers', 'Breadboard'],
    stepByStepInstructions: [
      '1. Screw high-gain whip antennas into the SMA connector on both LoRa modules before powering up.',
      '2. Wire LoRa SPI bus (NSS, MOSI, MISO, SCK, DIO0) to ESP32 DevKits.',
      '3. Flash Transmitter sketch with Spreading Factor 7 and Frequency 868 MHz.',
      '4. Flash Receiver sketch displaying RSSI (signal strength) and SNR (signal-to-noise ratio).',
      '5. Walk 500m across campus: observe that LoRa maintains packet reception even when RSSI drops to -120 dBm.'
    ],
    expectedObservations: [
      'Transmitter packet counter increments and receiver confirms 100% packet delivery.',
      'LoRa packet signals penetrate concrete walls where Wi-Fi completely fails.'
    ],
    commonMistakes: [
      'Powering up an RF transceiver without an antenna connected, reflecting transmit power back into the output amplifier and damaging the silicon.'
    ],
    troubleshooting: [
      'Packet drop rate high: increase Spreading Factor from SF7 to SF10 for increased processing gain.'
    ],
    quiz: [
      {
        id: 'q-rf-1',
        question: 'Why should you NEVER transmit RF signals without an antenna connected?',
        options: [
          'It changes the baud rate',
          'Reflected RF energy can thermally destroy the output power amplifier stage',
          'It flips the binary bits',
          'The battery voltage will reverse'
        ],
        correctIndex: 1,
        explanation: 'Without a matched 50Ω antenna load, transmitted RF energy reflects back as high standing waves, overheating the output stage.'
      }
    ],
    relatedEquipmentId: 'eq-lora-module',
    relatedEquipmentName: 'Long-Range LoRa RF Transceiver Kit',
    simulationExperimentId: 'mcu_io'
  },
  {
    id: 'lesson-instrumentation-measurement',
    pathId: 'path-instrumentation',
    title: '13. Signal Measurement & Instrumentation Mastery',
    category: 'Instrumentation',
    order: 13,
    difficulty: 'Intermediate',
    readTime: '8 min read',
    objectives: [
      'Master Digital Storage Oscilloscope (DSO) trigger modes: Auto, Normal, and Single-Shot',
      'Compensate 10X oscilloscope probes to eliminate capacitive distortion',
      'Understand ground loops and avoid shorting circuits through earth ground leads'
    ],
    explanation: 'Instrumentation is the window through which engineers verify reality. An oscilloscope displays voltage vs time, but high-frequency measurements are vulnerable to probe capacitance (which distorts rise times) and ground loops. Using 10X probe attenuation reduces probe tip capacitance by 10× and expands measurement bandwidth, at the cost of dividing signal amplitude by 10.',
    practicalExamples: [
      'Debugging digital SPI glitch: using Single-Shot trigger mode to capture a one-time transient reset error',
      'Measuring AC ripple voltage on a DC power supply using AC-coupling mode on the oscilloscope',
      'Automotive CAN-bus differential voltage verification'
    ],
    requiredComponents: ['Rigol DS1054Z 100MHz DSO', '10X Calibrated Probe with Ground Lead', 'Trimmer Screwdriver'],
    stepByStepInstructions: [
      '1. Connect BNC probe to Channel 1. Slide probe switch to 10X.',
      '2. In DSO channel menu, set Probe Attenuation to 10X.',
      '3. Attach probe hook to front-panel CAL terminal (1 kHz 3Vpp square wave reference) and ground lead to ground lug.',
      '4. Observe the square wave corners: if rounded (under-compensated) or spiked (over-compensated), rotate the probe trimmer until corners are crisp and flat.',
      '5. Switch Trigger Mode from Auto to Single: observe DSO wait for the next edge event.'
    ],
    expectedObservations: [
      'Square corners become perfectly flat when probe compensation trimmer capacitor matches scope input.',
      'Auto trigger constantly refreshes screen; Normal trigger holds stable trace; Single captures one event.'
    ],
    commonMistakes: [
      'Leaving probe on 1X mode while measuring high-frequency digital clock lines, attenuating edges.',
      'Connecting oscilloscope ground clip to a non-ground potential, creating a catastrophic ground loop through the AC mains earth wire.'
    ],
    troubleshooting: [
      'Trace is rolling or flickering: adjust trigger level knob to place trigger threshold inside the signal waveform.'
    ],
    quiz: [
      {
        id: 'q-ins-1',
        question: 'What is the purpose of adjusting the trimmer capacitor on a 10X oscilloscope probe?',
        options: [
          'To increase battery life',
          'To match probe capacitance with scope input capacitance for flat frequency response',
          'To change probe cable color',
          'To convert AC signals into DC'
        ],
        correctIndex: 1,
        explanation: 'Probe compensation balances the probe divider capacitor with the scope input capacitance, eliminating signal distortion.'
      }
    ],
    relatedEquipmentId: 'eq-dso-1054',
    relatedEquipmentName: 'Rigol 100MHz 4-Channel DSO',
    simulationExperimentId: 'ohms_law'
  },
  {
    id: 'lesson-robotics-automation',
    pathId: 'path-robotics',
    title: '14. Robotics & Motor Control Automation',
    category: 'Robotics',
    order: 14,
    difficulty: 'Intermediate',
    readTime: '8 min read',
    objectives: [
      'Control DC motors using H-Bridge topology (L298N driver) for forward/reverse and PWM speed control',
      'Decode optical quadrature encoders for precise wheel speed and distance odometry',
      'Implement closed-loop PID (Proportional-Integral-Derivative) control for trajectory tracking'
    ],
    explanation: 'Robots interact with the physical world through motors. Microcontroller pins cannot directly drive motors because DC motors draw hundreds of milliamps and generate severe back-EMF inductive spikes. An H-Bridge circuit uses 4 switching transistors to reverse current flow through the motor winding, while high-speed flyback diodes protect the driver circuitry from voltage spikes.',
    practicalExamples: [
      'Autonomous warehouse AGVs (Automated Guided Vehicles): following optical floor markers using PID loops',
      'CNC milling machines: closed-loop stepper motor drivers positioning axes within 0.01mm tolerance',
      'Robotic surgical arms: high-precision brushless servo actuators with zero backlash'
    ],
    requiredComponents: ['4WD Robotics Chassis', 'L298N Dual H-Bridge Driver Board', 'ESP32 or Arduino', '7.4V Li-ion Battery Pack', 'Breadboard'],
    stepByStepInstructions: [
      '1. Mount 4 DC geared motors to chassis. Connect left motor pair to L298N OUT1/OUT2 and right pair to OUT3/OUT4.',
      '2. Connect battery pack +7.4V to L298N 12V input and battery ground to L298N GND and microcontroller GND.',
      '3. Connect L298N IN1, IN2, IN3, IN4 to microcontroller digital output pins.',
      '4. Connect ENA and ENB speed pins to PWM output pins.',
      '5. Set IN1=HIGH, IN2=LOW to spin forward. Apply 60% PWM to ENA: verify motor spins smoothly at controlled speed.'
    ],
    expectedObservations: [
      'Setting IN1=HIGH and IN2=LOW spins motor clockwise; setting IN1=LOW and IN2=HIGH instantly reverses direction.',
      'PWM duty cycle cleanly regulates motor speed and torque.'
    ],
    commonMistakes: [
      'Forgetting common ground: microcontroller and motor driver MUST share a common GND wire.',
      'Powering high-current motors directly from microcontroller 5V regulator, triggering thermal resets.'
    ],
    troubleshooting: [
      'Motors make high-pitched whining noise without turning: PWM duty cycle is too low to overcome static friction.'
    ],
    quiz: [
      {
        id: 'q-rob-1',
        question: 'What is the function of an H-Bridge circuit in robotics?',
        options: [
          'To step down AC voltage',
          'To reverse current through a motor winding, enabling bidirectional rotation',
          'To measure battery percentage',
          'To generate Wi-Fi packets'
        ],
        correctIndex: 1,
        explanation: 'An H-Bridge uses 4 switches to route current in either direction through a DC motor.'
      }
    ],
    relatedEquipmentId: 'eq-robot-car',
    relatedEquipmentName: '4WD Autonomous Smart Robotics Kit',
    simulationExperimentId: 'mcu_io'
  },
  {
    id: 'lesson-pcb-soldering-safety',
    pathId: 'path-fabrication',
    title: '15. PCB Basics, Schematics & Soldering Safety',
    category: 'Fabrication & Safety',
    order: 15,
    difficulty: 'Beginner',
    readTime: '7 min read',
    objectives: [
      'Understand PCB anatomy: Substrate (FR4), Copper Traces, Solder Mask, Silkscreen, and Annular Rings',
      'Master the thermal heat-bridge soldering protocol for IPC-A-610 concave fillets',
      'Practice lab safety: ventilation, eye protection, lead-free alloys, and ESD grounding'
    ],
    explanation: 'A Printed Circuit Board (PCB) replaces messy breadboard jumper wires with etched copper tracks bonded onto a fiberglass substrate (FR4). Soldering creates both an electrical connection and mechanical bond using a metal alloy melted at ~320°C. Solder flux is critical: it chemically removes invisible microscopic metal oxidation so molten solder can wet the copper surface and form a shiny concave fillet.',
    practicalExamples: [
      'Smartphone motherboards: ultra-dense 12-layer HDI PCBs with micro-vias smaller than human hair',
      'Power electronics boards: thick 2oz copper planes carrying 50A current with large thermal relief vias',
      'Surface Mount (SMD) components: soldered onto surface pads without drilling holes through the board'
    ],
    requiredComponents: ['Dual Hot Air & Soldering Station', 'Lead-Free Solder Reel (60/40 or SAC305)', 'Rosin Flux Pen', 'Brass Sponge Tip Cleaner', 'Practice PCB with Header Pins'],
    stepByStepInstructions: [
      '1. Wear safety glasses. Turn on bench fume extractor or position fan.',
      '2. Set soldering station temperature to 330°C. Clean tip in brass wire sponge.',
      '3. Tin the iron tip with a tiny dab of fresh solder to establish a thermal heat-bridge.',
      '4. Touch the iron tip simultaneously to the copper pad and component pin for 1.5 seconds.',
      '5. Feed solder wire to the opposite side of the heated joint (not onto the iron). Watch solder flow smoothly.',
      '6. Remove solder wire, then withdraw the iron smoothly along the lead. Allow to cool undisturbed for 3 seconds.'
    ],
    expectedObservations: [
      'A perfect solder joint forms a bright, shiny concave cone (fillet) with smooth edges feathering to copper.',
      'Overheated joints look dull, crusty, or pitted with burned flux residues.'
    ],
    commonMistakes: [
      'Holding the iron on a small component for > 5 seconds, delaminating the copper pad from the PCB substrate.',
      'Blowing on a cooling solder joint with your mouth, causing a brittle "cold solder joint" with high resistance.'
    ],
    troubleshooting: [
      'Solder forms a ball on the iron and refuses to stick to the PCB pad: apply fresh rosin flux to strip pad oxidation.'
    ],
    quiz: [
      {
        id: 'q-pcb-1',
        question: 'What is the ideal visual shape of a high-reliability through-hole solder joint?',
        options: [
          'A round spherical blob',
          'A concave cone (fillet) with wetting angle < 45 degrees',
          'A flat pancake with burnt flux',
          'A jagged, dull gray mound'
        ],
        correctIndex: 1,
        explanation: 'According to IPC standards, a concave fillet indicates proper wetting of both lead and pad.'
      }
    ],
    relatedEquipmentId: 'eq-solder-station',
    relatedEquipmentName: 'Digital Dual Soldering Station',
    simulationExperimentId: 'led_resistor'
  }
];
