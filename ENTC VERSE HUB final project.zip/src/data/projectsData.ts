import { StudentProject } from '../types';

export const STUDENT_PROJECTS: StudentProject[] = [
  {
    id: 'proj-lora-agri',
    title: 'Solar-Powered Long Range Soil Telemetry Node',
    author: 'Aarav Sharma & Priya Nair',
    college: 'COEP Technological University, Pune',
    category: 'Telecommunication',
    difficulty: 'Intermediate',
    summary: 'A sub-gigahertz LoRa wireless node broadcasting soil moisture, NPK estimates, and ambient humidity across a 3.8 km agricultural canopy with battery life > 18 months.',
    description: 'Built as an end-semester ENTC capstone project. Leveraged our rented SX1276 LoRa transceiver and Rigol DS1054Z oscilloscope to inspect SPI packet timing and tune the matching antenna network. Features sleep-mode power dissipation under 15 microamps.',
    componentsUsed: ['SX1276 LoRa 868MHz Transceiver', 'ESP32 Microcontroller', 'Capacitive Soil Moisture Sensor v1.2', 'TP4056 Solar Charger Module', '18650 LiFePO4 Cell', 'SMA Whip Antenna (868MHz)'],
    schematicSummary: 'ESP32 SPI Bus (GPIO 18, 19, 23) connected to LoRa module with RF ground plane isolation. Analog capacitive sensor wired to ADC1_CH0 with 100nF filter capacitor. Deep-sleep wake on RTC timer.',
    githubUrl: 'https://github.com/entcverse-student-showcase/lora-telemetry-node',
    likes: 142,
    learningOutcomes: [
      'Sub-GHz wireless propagation and link budget calculations',
      'Ultra-low power microcontroller sleep states and RTC timer management',
      'Capacitive analog sensor calibration and noise reduction'
    ],
    suggestedEquipmentIds: ['eq-rigol-dso-1054z', 'eq-esp32-iot-kit', 'eq-spectrum-analyzer'],
    implementationSteps: [
      'Assemble 3.3V power regulator circuit with low quiescent current LDO',
      'Wire SPI interface between ESP32 and SX1276 transceiver with 50Ω trace layout',
      'Configure RadioHead / LoRa library with Spreading Factor 9, Bandwidth 125kHz',
      'Program RTC deep sleep routine to wake for 800ms every 15 minutes',
      'Field test packet reception at 500m, 1km, 2km, and 3.8km benchmarks'
    ],
    testingGuidance: 'Use oscilloscope Channel 1 on NSS chip select and Channel 2 on SCK to verify SPI clock integrity. Measure sleep current using μA setting on bench multimeter.',
    futureImprovements: ['Add MPPT solar tracking logic', 'Implement LoRaWAN OTAA encryption keys']
  },
  {
    id: 'proj-quad-flight',
    title: 'Autonomous Flight Controller with Kalman Filter',
    author: 'Rohan Deshmukh & Sneha Patil',
    college: 'MIT World Peace University',
    category: 'Robotics',
    difficulty: 'Advanced',
    summary: 'Custom STM32 flight controller implementing a 6-state quaternion Extended Kalman Filter (EKF) with 500Hz attitude stabilization loop and fail-safe return-to-home.',
    description: 'Developed using rented logic analyzers and hot air rework stations from ENTCverse Hub. The team soldered fine-pitch QFN IMU chips and verified I2C clock stretch times using the digital storage oscilloscope.',
    componentsUsed: ['STM32F405 ARM Cortex-M4 (168MHz)', 'MPU6000 6-Axis SPI IMU', 'BMP280 Barometric Altimeter', '4x 30A BLHeli_S ESCs', 'FrSky SBUS Receiver', 'Carbon Fiber Frame'],
    schematicSummary: 'Hardware SPI bus at 10 MHz connecting STM32 to MPU6000 with low-ESR ceramic bypass capacitors. Dedicated 5V low-noise LDO regulator for analog IMU power rail.',
    githubUrl: 'https://github.com/entcverse-student-showcase/stm32-quad-ekf',
    likes: 189,
    learningOutcomes: [
      'Sensor fusion algorithms (Complementary filter & Extended Kalman Filter)',
      'High-speed PWM / DShot motor signaling protocols',
      'Vibration isolation and board layout for sensitive MEMS accelerometers'
    ],
    suggestedEquipmentIds: ['eq-soldering-station', 'eq-rigol-dso-1054z', 'eq-logic-analyzer'],
    implementationSteps: [
      'Solder QFN gyroscope/accelerometer package using solder paste and hot-air reflow',
      'Write DMA-based SPI driver reading raw 16-bit accel/gyro registers at 1kHz',
      'Implement quaternion orientation integration with gyro bias tracking',
      'Develop cascaded PID control loop: Angle loop (250Hz) and Rate loop (1kHz)',
      'Conduct tethered bench test on pivot gimbal before untethered flight'
    ],
    testingGuidance: 'Verify DShot600 waveform edges on oscilloscope to ensure clean switching without inductive motor ringing.',
    futureImprovements: ['Optical flow camera integration for indoor GPS-denied hover']
  },
  {
    id: 'proj-substation-iot',
    title: 'Smart 3-Phase Grid Telemetry & Arc-Fault Detector',
    author: 'Vikram Joshi & Ananya Roy',
    college: 'Pune Institute of Computer Technology (PICT)',
    category: 'IoT',
    difficulty: 'Advanced',
    summary: 'Real-time electrical grid monitoring system measuring True-RMS current, harmonic distortion (THD), and optical high-speed arc-flash detection for transformer safety.',
    description: 'Rented precision Fluke True-RMS multimeters and Korad bench power supplies to calibrate split-core current transformers across 0 to 50 Amps with 0.5% measurement accuracy.',
    componentsUsed: ['ESP32 Dual-Core DevKit', 'SCT-013-000 Non-Invasive CT Sensors', 'ADS1115 16-Bit I2C ADC', 'Photodiode High-Speed Arc Detector', 'Opto-Isolated Triac Driver', 'OLED Telemetry Display'],
    schematicSummary: 'AC current transformer burden resistor bias circuit centered at 1.65V DC. ADS1115 differential inputs reading continuous waveform with FFT harmonic calculation in firmware.',
    githubUrl: 'https://github.com/entcverse-student-showcase/smart-grid-telemetry',
    likes: 116,
    learningOutcomes: [
      'Non-invasive AC power measurement and power factor computation',
      'Fast Fourier Transform (FFT) analysis on microcontroller for THD',
      'Galvanic isolation techniques for high-voltage industrial telemetry'
    ],
    suggestedEquipmentIds: ['eq-fluke-dmm-87v', 'eq-power-supply-30v', 'eq-esp32-iot-kit'],
    implementationSteps: [
      'Build analog front-end with precision burden resistor and 1.65V DC offset reference',
      'Configure ADC sampling at 1.6 kHz to capture up to 15th harmonic on 50Hz mains',
      'Calculate active power, reactive power (kVAR), and power factor in real-time',
      'Publish telemetry via MQTT over Wi-Fi to AWS IoT / ThingsBoard dashboard'
    ],
    testingGuidance: 'Calibrate readings against Fluke True-RMS clamp meter under resistive and inductive loads.',
    futureImprovements: ['Cellular 4G fallback using SIM7600 module']
  },
  {
    id: 'proj-dsp-synth',
    title: 'Polyphonic FM Synthesizer with Real-Time I2S Audio',
    author: 'Kunal Verma',
    college: 'Vishwakarma Institute of Technology (VIT)',
    category: 'DSP',
    difficulty: 'Intermediate',
    summary: '8-voice polyphonic frequency modulation audio synthesizer running on a 240MHz microcontroller with custom wavetable synthesis and analog resonant low-pass filter.',
    description: 'Simulated the digital filter poles in ENTCverse Virtual Lab before deploying the firmware to physical hardware rented from our showroom.',
    componentsUsed: ['Teensy 4.0 / ESP32', 'PCM5102A 32-Bit I2S Stereo DAC', '4x Rotary Optical Encoders', 'LM358 Active Output Buffer', 'MIDI DIN-5 Interface with 6N138 Optocoupler'],
    schematicSummary: 'Bit-clock, word-select, and serial data lines connected via matched 33Ω damping resistors to eliminate digital overshoot ringing on high-speed audio DAC.',
    githubUrl: 'https://github.com/entcverse-student-showcase/polyphonic-fm-synth',
    likes: 98,
    learningOutcomes: [
      'Digital signal processing: Phase accumulator and sine lookup tables',
      'I2S digital audio transmission and DAC reconstruction filtering',
      'MIDI protocol decoding with optocoupler isolation'
    ],
    suggestedEquipmentIds: ['eq-function-gen-25mhz', 'eq-rigol-dso-1054z'],
    implementationSteps: [
      'Build opto-isolated MIDI input circuit using 6N138 and 1N4148 protection diode',
      'Implement audio synthesis engine running dual-operator FM modulation algorithms',
      'Configure I2S peripheral with DMA double-buffering at 44.1kHz 16-bit stereo',
      'Add second-order active low-pass reconstruction filter to smooth DAC steps'
    ],
    testingGuidance: 'Probe I2S bit clock (1.411 MHz) with DSO to verify signal integrity without jitter.',
    futureImprovements: ['Add USB MIDI class-compliant audio interface']
  },
  {
    id: 'proj-smart-irrigation',
    title: 'Automatic Precision Plant Watering with Capacitive Feedback',
    author: 'Neha Deshpande',
    college: 'Government College of Engineering, Pune',
    category: 'IoT',
    difficulty: 'Beginner',
    summary: 'Self-regulating plant care system that monitors soil volumetric water content, activates a 12V submersible peristaltic pump via MOSFET, and logs metrics to an e-paper dashboard.',
    description: 'Created as a first-year IoT lab project. By testing in the ENTCverse Virtual Lab first, avoided frying the microcontroller with inductive motor spikes.',
    componentsUsed: ['Arduino Nano / ESP32', 'Capacitive Moisture Sensor v1.2', 'IRFZ44N N-Channel MOSFET', '1N4007 Flyback Diode', '12V DC Miniature Water Pump', '12V 2A Power Adapter'],
    schematicSummary: 'Microcontroller GPIO drives MOSFET gate through 220Ω resistor, with 10kΩ pull-down to Ground. 1N4007 diode clamped in reverse across DC pump terminals.',
    githubUrl: 'https://github.com/entcverse-student-showcase/smart-irrigation',
    likes: 76,
    learningOutcomes: [
      'Low-side N-channel MOSFET switching fundamentals',
      'Inductive kickback suppression with clamping diodes',
      'Hysteresis threshold programming to avoid motor oscillation'
    ],
    suggestedEquipmentIds: ['eq-analog-multimeter', 'eq-power-supply-30v'],
    implementationSteps: [
      'Wire the low-side N-MOSFET switch circuit on a breadboard',
      'Attach flyback diode across pump terminals (Cathode to +12V, Anode to Drain)',
      'Submerge sensor in dry soil and saturated soil to map calibration values (0-100%)',
      'Implement software hysteresis: turn pump on at <25% moisture, turn off at >65%'
    ],
    testingGuidance: 'Check Drain-to-Source voltage with DMM: should drop below 0.1V when gate is driven at 5V.',
    futureImprovements: ['Solar panel charging circuit with 18650 lithium battery']
  },
  {
    id: 'proj-obstacle-rover',
    title: 'Differential Drive Obstacle-Avoiding Robotics Rover',
    author: 'Tanmay Kulkarni & Aditya Joshi',
    college: 'Sinhgad College of Engineering',
    category: 'Robotics',
    difficulty: 'Beginner',
    summary: 'Two-wheeled autonomous robotic platform with HC-SR04 ultrasonic sonar sensor on a micro servo scanning head, navigating obstacle courses using reactive avoidance algorithms.',
    description: 'Built during an ENTC robotics workshop. The team rented dual-channel power supplies and DSO to debug servo PWM jitter caused by motor battery sag.',
    componentsUsed: ['Arduino Uno R3', 'L298N Dual H-Bridge Motor Driver', '2x Geared DC Motors with Wheels', 'HC-SR04 Ultrasonic Sensor', 'SG90 Micro Servo', '7.4V 2S Li-Po Battery Pack'],
    schematicSummary: 'HC-SR04 Trigger on GPIO 9, Echo on GPIO 10 with 5V to 3.3V divider. L298N IN1-IN4 connected to digital pins with PWM speed control on ENA and ENB.',
    githubUrl: 'https://github.com/entcverse-student-showcase/obstacle-rover',
    likes: 85,
    learningOutcomes: [
      'Speed of sound time-of-flight distance calculation',
      'H-bridge bidirectional motor direction and PWM speed control',
      'Power supply decoupling between noisy motors and sensitive logic'
    ],
    suggestedEquipmentIds: ['eq-power-supply-30v', 'eq-rigol-dso-1054z'],
    implementationSteps: [
      'Mount motors and caster wheel onto laser-cut acrylic chassis',
      'Wire L298N driver and verify forward/reverse rotation for each wheel',
      'Mount ultrasonic sensor onto SG90 servo horn at front bumper',
      'Write obstacle detection routine: sweep servo 45° left and right when distance < 20cm',
      'Select clearest path and execute turning maneuver'
    ],
    testingGuidance: 'Measure battery voltage during sudden motor reversal to detect potential brownout resets.',
    futureImprovements: ['PID wall-following algorithm', 'IR edge sensors to prevent table drops']
  },
  {
    id: 'proj-smart-parking',
    title: 'Automated Multi-Bay Smart Parking Management System',
    author: 'Pooja Hegde & Sameer Qureshi',
    college: 'BMS College of Engineering, Bengaluru',
    category: 'Embedded Systems',
    difficulty: 'Intermediate',
    summary: 'Infrared reflective bay sensing system with automated boom barrier servo, RFID entry authentication, and real-time bay vacancy display on a 16x2 I2C LCD.',
    description: 'Designed as an embedded systems mini-project using rented logic analyzers to verify RC522 RFID SPI timing.',
    componentsUsed: ['RC522 13.56MHz RFID Reader', '4x TCRT5000 IR Proximity Sensors', 'MG996R Metal Gear Servo (Boom barrier)', '16x2 I2C Character LCD', 'Buzzer & Indicator LEDs'],
    schematicSummary: 'RFID reader wired via 3.3V SPI. IR sensors wired to digital input pins with comparator sensitivity potentiometers. Servo driven via 50Hz PWM signal.',
    githubUrl: 'https://github.com/entcverse-student-showcase/smart-parking-system',
    likes: 104,
    learningOutcomes: [
      'RFID Mifare classic card authentication protocols',
      'Digital sensor debounce and false-positive filtering',
      'State machine design for barrier entry and exit cycles'
    ],
    suggestedEquipmentIds: ['eq-logic-analyzer', 'eq-esp32-iot-kit'],
    implementationSteps: [
      'Wire RC522 module to SPI pins with dedicated 3.3V power regulator',
      'Calibrate TCRT5000 IR sensor thresholds for car chassis reflectivity',
      'Program finite state machine: IDLE -> SCAN -> VALIDATE -> OPEN -> DETECT_PASS -> CLOSE',
      'Update live vacant count on LCD screen whenever car enters or leaves'
    ],
    testingGuidance: 'Inspect SPI communication on logic analyzer during card tap to confirm UID transmission.',
    futureImprovements: ['Automatic number plate recognition (ANPR) camera integration']
  },
  {
    id: 'proj-water-tank',
    title: 'Ultrasonic Water Level Telemetry with SMS Alerts',
    author: 'Omkar Bhole',
    college: 'Walchand College of Engineering, Sangli',
    category: 'IoT',
    difficulty: 'Intermediate',
    summary: 'Non-contact ultrasonic water tank depth transmitter with SIM800L GSM modem broadcasting low-level warnings and triggering an automatic overhead refill relay.',
    description: 'Prototyped using rented multimeters and solder stations. Avoided corrosion issues common to submerged metal electrode level sensors.',
    componentsUsed: ['JSN-SR04T Waterproof Ultrasonic Sensor', 'SIM800L GSM Cellular Module', 'Arduino Pro Mini (3.3V 8MHz)', '10A 5V Relay Module', 'LM2596 DC-DC Buck Step-Down Regulator'],
    schematicSummary: 'SIM800L powered by LM2596 set to 4.0V with 1000μF low-ESR capacitor for 2A GSM burst transmission spikes. Waterproof ultrasonic sensor wired to pins 8 & 9.',
    githubUrl: 'https://github.com/entcverse-student-showcase/water-tank-telemetry',
    likes: 92,
    learningOutcomes: [
      'High-current pulsed load management in GSM modems',
      'Non-contact acoustic distance measurement in enclosed cavities',
      'Relay safety and isolation for 230V AC water pumps'
    ],
    suggestedEquipmentIds: ['eq-power-supply-30v', 'eq-soldering-station', 'eq-fluke-dmm-87v'],
    implementationSteps: [
      'Configure LM2596 buck converter output to 4.0V for SIM800L supply',
      'Connect large 1000μF electrolytic capacitor directly across SIM800L power pins',
      'Mount JSN-SR04T probe in center of water tank roof pointing down',
      'Program depth computation: Water Height = Tank Height - Measured Distance',
      'Send automated SMS when level drops below 20% or rises above 95%'
    ],
    testingGuidance: 'Monitor GSM power rail on oscilloscope during SMS dispatch: voltage must not dip below 3.7V.',
    futureImprovements: ['Blynk mobile app cloud integration']
  },
  {
    id: 'proj-weather-station',
    title: 'Solar Environmental Weather Station with BME280',
    author: 'Kavita Nair & Deepak Rao',
    college: 'RV College of Engineering, Bengaluru',
    category: 'IoT',
    difficulty: 'Intermediate',
    summary: 'Compact outdoor weather station measuring barometric pressure, relative humidity, ambient temperature, and UV index, transmitting data to OpenWeatherMap via MQTT.',
    description: 'Designed and assembled with rented test equipment from ENTCverse Hub. Uses low-noise I2C sensor wiring in a 3D-printed Stevenson screen.',
    componentsUsed: ['ESP32 DevKit v1', 'BME280 Pressure/Humidity/Temp Sensor', 'VEML6075 UVA/UVB Sensor', '0.96-inch OLED I2C Display', '6V 2W Solar Panel', '18650 Battery Shield'],
    schematicSummary: 'Shared I2C bus (SDA GPIO 21, SCL GPIO 22) with 4.7kΩ pull-up resistors connecting BME280 (0x76) and OLED (0x3C). Deep sleep between sensor readings.',
    githubUrl: 'https://github.com/entcverse-student-showcase/solar-weather-station',
    likes: 128,
    learningOutcomes: [
      'Multi-device I2C bus addressing and clock stretching',
      'Barometric altitude calculation using hypsometric formula',
      'Weather-resistant outdoor enclosures and thermal shielding'
    ],
    suggestedEquipmentIds: ['eq-esp32-iot-kit', 'eq-analog-multimeter'],
    implementationSteps: [
      'Connect BME280 and OLED to ESP32 hardware I2C bus with pull-up resistors',
      'Read sensor registers and apply factory calibration trimming coefficients',
      'Connect ESP32 to Wi-Fi access point and publish JSON payload to MQTT broker',
      'Put MCU into deep sleep for 10 minutes to maintain solar battery reserve'
    ],
    testingGuidance: 'Verify I2C bus waveforms on oscilloscope to ensure rise time < 1000ns with chosen pull-up resistors.',
    futureImprovements: ['Anemometer wind speed sensor integration']
  },
  {
    id: 'proj-home-automation',
    title: 'Voice & App-Controlled Smart Room Power Controller',
    author: 'Rahul Shinde',
    college: 'Dwarkadas J. Sanghvi College of Engineering, Mumbai',
    category: 'Embedded Systems',
    difficulty: 'Beginner',
    summary: '4-channel smart relay controller with optocoupled AC isolation, capacitive touch wall panel override, and local Home Assistant MQTT integration.',
    description: 'Built safely with guidance from ENTCverse lab mentors. All high-voltage AC tracks feature physical 5mm isolation air gaps on the circuit board.',
    componentsUsed: ['ESP8266 / ESP32', '4-Channel Optocoupled 5V Relay Board', 'TTP223 Capacitive Touch Sensors', 'HLK-PM01 AC-to-DC 5V Converter', 'Snubber Network (100Ω + 100nF)'],
    schematicSummary: 'ESP32 GPIOs drive optocoupler inputs on relay board. TTP223 capacitive touch pads connected as physical manual toggles. High-voltage relays control room lights.',
    githubUrl: 'https://github.com/entcverse-student-showcase/smart-room-controller',
    likes: 111,
    learningOutcomes: [
      'Safe galvanic isolation between low-voltage digital circuits and 230V AC mains',
      'RC snubber network design for quenching contact arcing with inductive loads',
      'Local IoT communication protocols (MQTT, WebSockets, mDNS)'
    ],
    suggestedEquipmentIds: ['eq-soldering-station', 'eq-fluke-dmm-87v', 'eq-analog-multimeter'],
    implementationSteps: [
      'Wire ESP32 to optocoupled relay module with separate VCC/JD-VCC jumper configuration',
      'Install TTP223 touch switches to enable physical manual control even if Wi-Fi drops',
      'Flash ESPHome / custom C++ firmware with local web server and MQTT client',
      'Add RC snubber circuit across relay contacts to protect against inductive fluorescent lamp spikes'
    ],
    testingGuidance: 'Test insulation resistance with multimeter megohmmeter before applying AC line power.',
    futureImprovements: ['Current monitoring on each channel using ACS712 sensors']
  }
];
