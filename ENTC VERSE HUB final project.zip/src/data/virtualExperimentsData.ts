import { VirtualExperiment } from '../types';

export const VIRTUAL_EXPERIMENTS: VirtualExperiment[] = [
  {
    id: 'exp-led-resistor',
    title: '1. LED Current-Limiting Resistor Circuit',
    category: 'Fundamentals',
    difficulty: 'Beginner',
    circuitType: 'led_resistor',
    objective: 'Determine how varying resistance protects an LED from thermal runaway, calculates diode forward current, and regulates luminous intensity.',
    requiredComponents: ['5V DC Power Source', 'Current-Limiting Resistor (100Ω to 2.2kΩ)', '5mm Red / Green / Blue LED', 'Virtual Ammeter', 'Virtual Voltmeter'],
    wiringInstructions: [
      'Connect +5V DC source to Resistor lead 1.',
      'Connect Resistor lead 2 to LED Anode (+ longer lead).',
      'Connect LED Cathode (- flat edge) to DC Ground (0V).',
      'Insert virtual ammeter in series between resistor and LED anode.',
      'Connect virtual voltmeter across LED terminals to measure forward voltage drop Vf.'
    ],
    procedure: [
      'Set DC supply voltage to 5.0V.',
      'Select a 330Ω resistor and observe LED brightness and current (approx. 9.1 mA for Red LED).',
      'Decrease resistance to 50Ω and note excessive current (>50mA) triggering thermal overload warning.',
      'Increase resistance to 2.2kΩ and observe safe, dim illumination (<1.5mA).',
      'Switch between Red (Vf ~2.0V), Green (Vf ~2.2V), and Blue (Vf ~3.2V) LEDs to compare forward drop.'
    ],
    expectedOutput: 'Forward current I = (V_supply - V_f) / R. At 330Ω with Red LED (V_f = 2.0V), current is approximately 9.1 mA with optimal brightness. Below 68Ω, current exceeds 25mA maximum continuous rating.',
    underlyingConcept: "Diodes have exponential I-V curves. Without a current-limiting resistor, a small increase in voltage creates uncontrolled current surge, instantly destroying the semiconductor junction.",
    commonErrors: [
      'Omitting the current-limiting resistor entirely, resulting in immediate diode burnout.',
      'Reversing LED polarity (Cathode to positive rail) preventing any forward conduction.',
      'Using a resistor wattage rating lower than I²R dissipated power.'
    ],
    safetyWarnings: [
      'In a physical lab, never power an LED directly from a USB or 9V battery without a series resistor.',
      'High-brightness LEDs can cause retinal glare; do not look directly into bare optical diodes.'
    ],
    completionChecklist: [
      'Calculate theoretical current using Ohm’s Law and diode Vf',
      'Observe safe operating region (5mA - 20mA)',
      'Trigger overload warning safely in virtual simulation',
      'Test red, green, and blue LED voltage drops'
    ],
    relatedEquipmentId: 'eq-dmm-fluke'
  },
  {
    id: 'exp-series-parallel',
    title: '2. Series and Parallel Resistor Networks',
    category: 'Circuit Analysis',
    difficulty: 'Beginner',
    circuitType: 'series_parallel',
    objective: 'Verify Kirchhoff’s laws and calculate equivalent resistances for both series and parallel resistor combinations.',
    requiredComponents: ['12V Regulated DC Supply', 'Resistor R1 (100Ω - 10kΩ)', 'Resistor R2 (100Ω - 10kΩ)', 'Virtual Multimeter (Ohmmeter & Ammeter)'],
    wiringInstructions: [
      'Series Mode: Connect DC+ to R1, connect R1 other end to R2, connect R2 other end to DC-. Current flows through a single sequential branch.',
      'Parallel Mode: Tie tops of R1 and R2 together to DC+, tie bottoms of R1 and R2 together to DC-. Both resistors experience identical potential difference.'
    ],
    procedure: [
      'Select Series configuration with R1 = 1kΩ and R2 = 2kΩ. Measure equivalent R_eq = 3kΩ.',
      'Observe current across both resistors remains identical at 4.0 mA with 12V supply.',
      'Switch to Parallel configuration with same R1 = 1kΩ and R2 = 2kΩ. Measure equivalent R_eq = 667Ω.',
      'Observe branch currents: I1 = 12mA, I2 = 6mA, Total current = 18mA.'
    ],
    expectedOutput: 'Series R_eq = R1 + R2 (higher resistance, lower total current). Parallel 1/R_eq = 1/R1 + 1/R2 (lower equivalent resistance than either individual branch, higher total draw).',
    underlyingConcept: 'Charge conservation dictates Kirchhoff’s Current Law (sum of currents entering a node equals sum leaving). Energy conservation dictates Kirchhoff’s Voltage Law (sum of voltage drops around a closed loop equals zero).',
    commonErrors: [
      'Measuring resistance with power supply energized (in physical labs, this blows multimeter fuses).',
      'Misidentifying breadboard internal tie lines when wiring parallel nodes.'
    ],
    safetyWarnings: [
      'Always disconnect circuit power before measuring resistance with an ohmmeter.',
      'Ensure resistor power ratings (P = V² / R) are not exceeded during low-resistance parallel loads.'
    ],
    completionChecklist: [
      'Confirm series equivalent resistance equals R1 + R2',
      'Confirm parallel equivalent resistance is strictly less than smallest resistor',
      'Verify Kirchhoff’s Current Law at parallel junction node'
    ],
    relatedEquipmentId: 'eq-dmm-fluke'
  },
  {
    id: 'exp-ohms-law',
    title: "3. Ohm's Law Verification & I-V Curve",
    category: 'Fundamentals',
    difficulty: 'Beginner',
    circuitType: 'ohms_law',
    objective: 'Establish the linear proportional relationship between applied voltage (V), resulting current (I), and circuit resistance (R).',
    requiredComponents: ['Adjustable DC Power Supply (0V - 30V)', 'Precision Resistor (100Ω, 470Ω, or 1kΩ)', 'Dual Multimeters (Current & Voltage)'],
    wiringInstructions: [
      'Connect Variable DC Supply (+) to the Ammeter (A+) input.',
      'Connect Ammeter common (COM) to the input lead of Test Resistor R.',
      'Connect Test Resistor output lead to DC Supply (-).',
      'Connect Voltmeter in parallel across the two leads of Test Resistor R.'
    ],
    procedure: [
      'Select a fixed resistance (e.g. 500Ω).',
      'Sweep voltage from 0V to 20V in 2V increments.',
      'Record corresponding current reading in milliamps at each step.',
      'Observe the slope of the V-I curve equals the resistance value R.',
      'Change resistance value and observe how slope steepness reflects conductance (G = 1/R).'
    ],
    expectedOutput: 'Straight-line linear relationship through origin: I = V / R. Power dissipation P = V × I increases quadratically with voltage.',
    underlyingConcept: "Ohm's Law (V = IR) defines ideal linear resistive behavior where drift velocity of charge carriers scales directly with electrical field intensity.",
    commonErrors: [
      'Connecting the ammeter in parallel across the power supply, producing a dead short.',
      'Connecting the voltmeter in series, breaking the circuit because of high internal input impedance (>10MΩ).'
    ],
    safetyWarnings: [
      'Bench power supplies can deliver dangerous current if shorted; always set the current limit dial before testing.'
    ],
    completionChecklist: [
      'Take 5 data points across voltage range',
      'Confirm linearity of the current response',
      'Calculate instantaneous thermal power dissipation'
    ],
    relatedEquipmentId: 'eq-dc-psu'
  },
  {
    id: 'exp-voltage-divider',
    title: '4. Unloaded & Loaded Voltage Divider',
    category: 'Circuit Analysis',
    difficulty: 'Beginner',
    circuitType: 'voltage_divider',
    objective: 'Analyze how two series resistors partition a reference voltage, and investigate loading effect when a low-impedance sensor or load is attached.',
    requiredComponents: ['10V DC Voltage Rail', 'Resistor R1 (Upper arm)', 'Resistor R2 (Lower arm)', 'Load Resistor R_L (Optional tap)'],
    wiringInstructions: [
      'Connect +10V DC to top lead of R1.',
      'Connect bottom lead of R1 to top lead of R2 (this is the V_out node).',
      'Connect bottom lead of R2 to Circuit Ground.',
      'Connect high-impedance voltmeter between V_out node and Ground.',
      'Switchably connect Load Resistor R_L in parallel across R2 to observe output sagging.'
    ],
    procedure: [
      'Set Vin = 10.0V, R1 = 10kΩ, and R2 = 10kΩ. Observe ideal unloaded Vout = 5.00V.',
      'Alter R2 to 30kΩ and verify Vout = 10V × (30 / 40) = 7.50V.',
      'Turn on Load Resistor with RL = 10kΩ in parallel with R2 (10kΩ).',
      'Notice output voltage drops from 5.0V to 3.33V due to the parallel loading effect.'
    ],
    expectedOutput: 'Unloaded output: V_out = V_in × (R2 / (R1 + R2)). With load attached, equivalent lower resistance is R2 || R_L, pulling V_out down significantly.',
    underlyingConcept: 'Voltage dividers provide convenient reference biases for high-impedance operational amplifier inputs or ADC references, but cannot efficiently power low-resistance loads.',
    commonErrors: [
      'Using a resistive voltage divider as a power supply for motors or microcontrollers instead of an active voltage regulator.',
      'Ignoring the ADC input impedance of microcontrollers when reading resistive sensor dividers.'
    ],
    safetyWarnings: [
      'Avoid very low resistance values (<10Ω) on higher voltage rails, as passive heat generation will scorch breadboards.'
    ],
    completionChecklist: [
      'Verify unloaded voltage divider formula with varying ratios',
      'Enable load resistor and quantify output voltage sag',
      'Calculate current drawn through the divider ladder'
    ],
    relatedEquipmentId: 'eq-breadboard-pack'
  },
  {
    id: 'exp-transistor-switch',
    title: '5. BJT NPN Transistor Switch & Saturation',
    category: 'Semiconductors',
    difficulty: 'Intermediate',
    circuitType: 'transistor_switch',
    objective: 'Use a miniature base current from a logic pin to switch a high-current load (lamp/relay) using an NPN bipolar junction transistor (2N2222 / BC547).',
    requiredComponents: ['12V Load Supply', '5V Logic Control Signal', 'NPN Transistor (2N2222)', 'Base Resistor Rb (1kΩ - 10kΩ)', 'Load (12V Motor / Lamp)', 'Virtual Oscilloscope / DMM'],
    wiringInstructions: [
      'Connect Transistor Emitter directly to Ground (0V common).',
      'Connect Transistor Collector to one terminal of the 12V Load (Lamp).',
      'Connect other terminal of the Load to the +12V supply rail.',
      'Connect Logic Input switch (0V / 5V) through Base Resistor Rb to the Transistor Base pin.'
    ],
    procedure: [
      'Set Base logic input to LOW (0V). Observe Collector current is 0 mA, Transistor is in Cut-Off, and load is OFF.',
      'Set Base logic input to HIGH (5V) with Rb = 4.7kΩ. Base current Ib ≈ (5V - 0.7V) / 4.7kΩ ≈ 0.91 mA.',
      'Observe Collector enters Saturation: Vce drops to ~0.2V, full 12V rail appears across load, and lamp glows brightly.',
      'Decrease Base current below minimum saturation threshold to see transistor enter linear active region with high heat dissipation.'
    ],
    expectedOutput: 'Cut-off state: Ib = 0, Ic = 0, Vce = 12V (switch open). Saturation state: Ib > Ic / β_forced, Vce ≈ 0.2V, Ic = (Vcc - Vce_sat) / R_load (switch closed).',
    underlyingConcept: 'BJT transistors are current-controlled current sources. By overdriving the base with sufficient charge carriers (forced beta < 20), the collector-emitter voltage collapses into low-resistance saturation.',
    commonErrors: [
      'Omitting the base resistor Rb, causing direct diode conduction between base and emitter that burns the transistor and MCU GPIO.',
      'Omitting a flyback diode when switching inductive loads like relay coils or DC motors.'
    ],
    safetyWarnings: [
      'In physical labs, an un-saturated BJT driving high currents dissipates huge thermal energy (P = Vce × Ic) and can burn skin on touch.'
    ],
    completionChecklist: [
      'Toggle digital logic switch between Cutoff and Saturation',
      'Verify Vce drop in saturation is approximately 0.2V',
      'Calculate forced beta ratio (Ic / Ib)'
    ],
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    id: 'exp-logic-gates',
    title: '6. Digital Logic Gate Verification & Truth Tables',
    category: 'Digital Electronics',
    difficulty: 'Beginner',
    circuitType: 'logic_gates',
    objective: 'Explore fundamental boolean logic functions (AND, OR, NOT, NAND, NOR, XOR) with interactive binary inputs and real-time output verification.',
    requiredComponents: ['5V TTL Logic Supply', '2x Toggle Input Switches (A & B)', 'Selected Logic Gate IC (74LS08, 74LS32, 74LS04, 74LS00, 74LS02, 74LS86)', 'Output Indicator LED with 330Ω Resistor'],
    wiringInstructions: [
      'Connect IC Pin 14 to +5V VCC and Pin 7 to Ground (standard TTL pinout).',
      'Connect Logic Switch A to Gate Input 1.',
      'Connect Logic Switch B to Gate Input 2.',
      'Connect Gate Output Pin to indicator LED anode through a 330Ω pull-down resistor to Ground.'
    ],
    procedure: [
      'Select logic gate type from dropdown (AND, OR, NOT, NAND, NOR, XOR).',
      'Set inputs A and B through all 4 binary states: (0,0), (0,1), (1,0), (1,1).',
      'Verify output LED state matches the formal mathematical truth table.',
      'Observe universal NAND gate equivalents and De Morgan’s theorem in action.'
    ],
    expectedOutput: 'AND: High only when both A=1 and B=1. OR: High when either A=1 or B=1. XOR: High strictly when inputs differ (parity detector). NAND: Inverse of AND.',
    underlyingConcept: 'Digital computing is constructed entirely from boolean logic primitives. Silicon MOSFET transistors act as microscopic binary switches encoding 0s (0V) and 1s (3.3V or 5V).',
    commonErrors: [
      'Leaving CMOS logic inputs floating (unconnected), which causes erratic oscillations and excessive static current draw.',
      'Confusing TTL (0.8V / 2.0V thresholds) with CMOS (30% / 70% VDD thresholds).'
    ],
    safetyWarnings: [
      'Electrostatic discharge (ESD) can puncture gate dielectric oxide in logic ICs; use grounded wrist straps in physical labs.'
    ],
    completionChecklist: [
      'Complete all 4 input permutations for selected gate',
      'Verify XOR parity behavior',
      'Compare NAND gate inverted response with standard AND'
    ],
    relatedEquipmentId: 'eq-lab-kit-full'
  },
  {
    id: 'exp-temp-fan',
    title: '7. Temperature Sensor & Comparator Fan Controller',
    category: 'Sensors & Automation',
    difficulty: 'Intermediate',
    circuitType: 'temp_fan',
    objective: 'Implement an analog closed-loop temperature monitor using an NTC thermistor / LM35 sensor and an operational amplifier comparator to drive a cooling fan.',
    requiredComponents: ['12V DC Supply', 'Analog Temperature Sensor (LM35: 10mV/°C)', 'LM393 Dual Comparator IC', 'Setpoint Calibration Potentiometer (10kΩ)', '12V DC Brushless Fan', 'Flyback Diode (1N4007)'],
    wiringInstructions: [
      'Connect LM35 sensor output to non-inverting (+) comparator input Pin 3.',
      'Connect wiper of 10kΩ potentiometer to inverting (-) comparator input Pin 2 to set temperature threshold.',
      'Connect comparator output Pin 1 through 1kΩ base resistor to 2N2222 transistor.',
      'Connect 12V Fan between +12V rail and transistor collector, with 1N4007 flyback diode in reverse across fan terminals.'
    ],
    procedure: [
      'Adjust virtual ambient temperature slider between 15°C and 80°C.',
      'Set trigger threshold potentiometer to 40°C (corresponding to 400mV on LM35 output).',
      'Observe comparator output remains LOW when ambient temperature is below 40°C.',
      'Increase temperature past 40°C: comparator output swings HIGH, transistor turns ON, fan spins at full RPM, preventing thermal damage.',
      'Implement virtual hysteresis feedback resistor (Schmitt trigger) to prevent chatter near the threshold.'
    ],
    expectedOutput: 'When V_sensor > V_threshold, V_out switches from 0V to 12V, activating cooling airflow. With Schmitt trigger hysteresis, turn-on occurs at 42°C and turn-off at 38°C.',
    underlyingConcept: 'Analog comparators perform 1-bit analog-to-digital quantization by amplifying the differential voltage (V+ - V-) with open-loop gain greater than 100,000.',
    commonErrors: [
      'Forgetting hysteresis in noisy real-world thermal environments, leading to rapid acoustic chatter and contact relay wear.',
      'Omitting the flyback diode across inductive fan coils, producing destructive inductive kickback spikes (>100V).'
    ],
    safetyWarnings: [
      'Keep fingers clear of high-speed cooling fan impellers during live bench testing.'
    ],
    completionChecklist: [
      'Sweep temperature above and below threshold',
      'Observe fan state change and RPM readout',
      'Tune potentiometer setpoint to change switching trigger'
    ],
    relatedEquipmentId: 'eq-dso-1054'
  },
  {
    id: 'exp-mcu-io',
    title: '8. Microcontroller Digital I/O & PWM Control',
    category: 'Embedded Systems',
    difficulty: 'Intermediate',
    circuitType: 'mcu_io',
    objective: 'Simulate microcontroller GPIO behavior: digital debounced button inputs, pull-up resistors, and Pulse Width Modulation (PWM) duty cycle control of LED brightness and buzzer pitch.',
    requiredComponents: ['ESP32 / Arduino Microcontroller Dev Board', 'Tactile Pushbutton with Internal Pull-Up', 'PWM Controllable LED', 'Piezo Buzzer', 'Virtual Logic / Scope Probe'],
    wiringInstructions: [
      'Connect tactile button between GPIO 4 and Circuit Ground (using internal INPUT_PULLUP).',
      'Connect LED anode through 220Ω resistor to PWM GPIO 18.',
      'Connect Piezo buzzer positive terminal to PWM GPIO 19 and negative terminal to Ground.',
      'Ground reference tied together across all peripherals.'
    ],
    procedure: [
      'Press virtual pushbutton to trigger interrupt or polled digital state transition (HIGH -> LOW).',
      'Adjust PWM duty cycle slider from 0% (off) to 100% (full on) and observe average DC voltage and LED brightness.',
      'Adjust PWM carrier frequency from 500 Hz to 5 kHz and observe corresponding acoustic tone on piezo buzzer.',
      'Examine simulated oscilloscope trace showing square wave high-time versus period ratio (T_on / T_period).'
    ],
    expectedOutput: 'V_average = V_peak × (Duty Cycle / 100). At 50% duty cycle on 3.3V GPIO, effective perceived RMS voltage is 1.65V. Frequency changes pitch while duty cycle regulates volume/brightness.',
    underlyingConcept: 'Microcontrollers are digital devices that cannot output arbitrary analog voltages directly. PWM generates effective analog levels by switching digital outputs on and off at rates faster than human eye persistence (for light) or mechanical response (for motors).',
    commonErrors: [
      'Leaving digital input pins floating without pull-up or pull-down resistors, creating random spurious triggers from ambient electromagnetic noise.',
      'Drawing more than 12mA directly from an ESP32 GPIO pin.'
    ],
    safetyWarnings: [
      'Do not connect inductive loads like DC motors or solenoids directly to microcontroller pins without driver transistors and clamp diodes.'
    ],
    completionChecklist: [
      'Toggle digital input button and verify state inversion with pull-up',
      'Vary PWM duty cycle from 10% to 90% and observe perceived brightness',
      'Inspect digital waveform pulse width on virtual scope'
    ],
    relatedEquipmentId: 'eq-esp32-devkit'
  }
];
