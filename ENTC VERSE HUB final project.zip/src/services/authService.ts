import { 
  signInWithPopup, 
  signOut as fbSignOut, 
  onAuthStateChanged,
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs 
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from './firebase';
import { UserProfile, RentalBooking } from '../types';
import { storageService } from './storageService';

export interface AuthUserState {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  role: 'student' | 'owner' | 'admin';
  college?: string;
  studentId?: string;
  phone?: string;
  isFirebaseUser: boolean;
}

class AuthService {
  // Sign in with Google Popup
  async signInWithGoogle(preferredRole: 'student' | 'owner' | 'admin' = 'student'): Promise<AuthUserState> {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      
      // Sync or retrieve user profile from Firestore
      const userDocRef = doc(db, 'users', fbUser.uid);
      let userProfile: UserProfile;

      try {
        const snap = await getDoc(userDocRef);
        if (snap.exists()) {
          userProfile = snap.data() as UserProfile;
        } else {
          // Determine initial role (admin if email matches admin email)
          const isAdmin = fbUser.email === 'rehangardi1947@gmail.com' || preferredRole === 'admin';
          const assignedRole = isAdmin ? 'admin' : preferredRole;

          userProfile = {
            id: fbUser.uid,
            email: fbUser.email || '',
            name: fbUser.displayName || 'ENTC Innovator',
            role: assignedRole,
            college: preferredRole === 'student' ? 'COEP Technological University' : 'Pune Institute of Tech',
            studentId: preferredRole === 'student' ? 'COEP-2026-ENTC-' + Math.floor(100 + Math.random() * 900) : '',
            phone: '+91 98230 ' + Math.floor(10000 + Math.random() * 90000),
            isVerified: true,
            savedEquipmentIds: ['eq-dso-1054', 'eq-esp32-devkit']
          };

          await setDoc(userDocRef, {
            ...userProfile,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${fbUser.uid}`);
        throw err;
      }

      // Also sync to local storage for offline state
      storageService.saveUserProfile(userProfile);

      return {
        uid: fbUser.uid,
        email: fbUser.email,
        displayName: userProfile.name,
        photoURL: fbUser.photoURL,
        role: userProfile.role,
        college: userProfile.college,
        studentId: userProfile.studentId,
        phone: userProfile.phone,
        isFirebaseUser: true
      };
    } catch (error) {
      console.error('Google Sign-In Error:', error);
      throw error;
    }
  }

  // Sign out from Firebase
  async signOut(): Promise<void> {
    try {
      await fbSignOut(auth);
    } catch (err) {
      console.error('Firebase sign out error:', err);
    }
  }

  // Update user profile in Firestore
  async updateUserProfile(uid: string, updates: Partial<UserProfile>): Promise<void> {
    const userRef = doc(db, 'users', uid);
    try {
      await updateDoc(userRef, {
        ...updates,
        updatedAt: new Date().toISOString()
      });
      const current = storageService.getUserProfile();
      storageService.saveUserProfile({ ...current, ...updates });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${uid}`);
    }
  }

  // Fetch user bookings from Firestore
  async getUserBookingsFromDb(uid: string): Promise<RentalBooking[]> {
    try {
      const q = query(collection(db, 'bookings'), where('userId', '==', uid));
      const querySnap = await getDocs(q);
      const bookings: RentalBooking[] = [];
      querySnap.forEach((doc) => {
        bookings.push(doc.data() as RentalBooking);
      });
      return bookings;
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, 'bookings');
      return [];
    }
  }

  // Save booking to Firestore database
  async saveBookingToDb(booking: RentalBooking, userId: string): Promise<void> {
    try {
      const bookingRef = doc(db, 'bookings', booking.id);
      await setDoc(bookingRef, {
        ...booking,
        userId
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `bookings/${booking.id}`);
    }
  }

  // Subscribe to auth state changes
  onAuthChange(callback: (user: AuthUserState | null) => void): () => void {
    return onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const userDocRef = doc(db, 'users', fbUser.uid);
          const snap = await getDoc(userDocRef);
          let profile: UserProfile;
          if (snap.exists()) {
            profile = snap.data() as UserProfile;
          } else {
            profile = {
              id: fbUser.uid,
              email: fbUser.email || '',
              name: fbUser.displayName || 'ENTC Student',
              role: fbUser.email === 'rehangardi1947@gmail.com' ? 'admin' : 'student',
              college: 'COEP Technological University',
              studentId: 'COEP-2026-ENTC-042',
              phone: '+91 98230 45112',
              isVerified: true,
              savedEquipmentIds: []
            };
            await setDoc(userDocRef, {
              ...profile,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            });
          }
          callback({
            uid: fbUser.uid,
            email: fbUser.email,
            displayName: profile.name,
            photoURL: fbUser.photoURL,
            role: profile.role,
            college: profile.college,
            studentId: profile.studentId,
            phone: profile.phone,
            isFirebaseUser: true
          });
        } catch (e) {
          console.warn('Could not read user profile from Firestore on auth change:', e);
          callback({
            uid: fbUser.uid,
            email: fbUser.email,
            displayName: fbUser.displayName || 'ENTC User',
            photoURL: fbUser.photoURL,
            role: fbUser.email === 'rehangardi1947@gmail.com' ? 'admin' : 'student',
            isFirebaseUser: true
          });
        }
      } else {
        callback(null);
      }
    });
  }
}

export const authService = new AuthService();
