import React, { useState } from 'react';
import { 
  GraduationCap, 
  Building2, 
  ShieldAlert, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  LogOut, 
  Database, 
  Cpu, 
  KeyRound, 
  UserCheck, 
  ExternalLink,
  Layers,
  AlertCircle
} from 'lucide-react';
import { authService, AuthUserState } from '../services/authService';

interface LoginPageProps {
  currentUser: { name: string; role: 'student' | 'owner' | 'admin'; email?: string; uid?: string } | null;
  onLoginSuccess: (user: { name: string; role: 'student' | 'owner' | 'admin'; email?: string; uid?: string }) => void;
  onLogout: () => void;
  onNavigateToTab: (tab: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  currentUser,
  onLoginSuccess,
  onLogout,
  onNavigateToTab
}) => {
  const [selectedRole, setSelectedRole] = useState<'student' | 'owner' | 'admin'>('student');
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [demoNotice, setDemoNotice] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setAuthError(null);
    try {
      const user = await authService.signInWithGoogle(selectedRole);
      onLoginSuccess({
        name: user.displayName || user.email || 'ENTC Innovator',
        role: user.role,
        email: user.email || undefined,
        uid: user.uid
      });
    } catch (err: unknown) {
      console.error('Google Sign-in failed', err);
      const message = err instanceof Error ? err.message : 'Authentication failed. Please retry.';
      setAuthError(message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoSignIn = (role: 'student' | 'owner' | 'admin') => {
    let name = 'Arjun Mehta';
    let email = 'arjun.mehta@coep.ac.in';
    if (role === 'owner') {
      name = 'Prof. Suresh Kulkarni';
      email = 'suresh.kulkarni@labgears.in';
    } else if (role === 'admin') {
      name = 'Dr. Rajiv Menon';
      email = 'rehangardi1947@gmail.com';
    }

    onLoginSuccess({
      name,
      role,
      email,
      uid: `demo-${role}-${Date.now()}`
    });
    setDemoNotice(`Signed in as demo ${role.toUpperCase()} (${name})`);
    setTimeout(() => setDemoNotice(null), 3500);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-[#09090b] bg-tech-grid py-12 px-4 sm:px-6 lg:px-8 relative">
      {/* Background radial gradient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-amber-500/10 blur-[130px] rounded-full pointer-events-none" />

      <div className="max-w-4xl mx-auto space-y-8 relative z-10">
        {/* Top Header & Breadcrumb */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neutral-900/90 border border-amber-500/30 text-amber-300 text-xs font-mono shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>CLOUD FIRESTORE DATABASE CONNECTED</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            ENTCverse Hub <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500">Authentication Portal</span>
          </h1>
          <p className="text-neutral-400 max-w-xl mx-auto text-sm sm:text-base">
            Secure, role-based access for electronics engineering students, lab owners, and research faculty with persistent cloud database profiles.
          </p>
        </div>

        {/* Database Status Strip */}
        <div className="bg-neutral-900/70 border border-neutral-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-neutral-400">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-amber-400" />
            <span className="text-neutral-300 font-semibold">Active Backend:</span>
            <span className="text-amber-300">Firebase Firestore Enterprise</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span className="text-neutral-400">Project: <code className="text-neutral-200">zeta-wares-8ds98</code></span>
            <span className="text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              ABAC Rules Active
            </span>
          </div>
        </div>

        {/* Main Card */}
        {currentUser ? (
          /* Active User Profile Card */
          <div className="bg-neutral-900/90 border border-amber-500/30 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-800 pb-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-neutral-950 font-bold text-xl shadow-lg shadow-amber-500/20">
                  {currentUser.name.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-white">{currentUser.name}</h2>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono uppercase font-bold tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      {currentUser.role}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 font-mono mt-0.5">
                    {currentUser.email || 'Authenticated Account'}
                  </p>
                </div>
              </div>

              <button
                onClick={onLogout}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-semibold border border-neutral-700 transition-colors cursor-pointer self-start sm:self-auto"
              >
                <LogOut className="w-4 h-4 text-rose-400" />
                <span>Sign Out</span>
              </button>
            </div>

            {/* Quick Profile Details Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-neutral-950/60 border border-neutral-800 space-y-1">
                <span className="text-[11px] font-mono text-neutral-500 uppercase">Current Access Tier</span>
                <p className="text-sm font-semibold text-white capitalize">{currentUser.role} Account</p>
                <p className="text-[11px] text-neutral-400">
                  {currentUser.role === 'student' && 'Eligible for 15% student subsidy and free pickup.'}
                  {currentUser.role === 'owner' && 'Full consignment & monthly disbursement controls.'}
                  {currentUser.role === 'admin' && 'Root platform privileges & pricing configuration.'}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-neutral-950/60 border border-neutral-800 space-y-1">
                <span className="text-[11px] font-mono text-neutral-500 uppercase">Database Status</span>
                <p className="text-sm font-semibold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Synced to Firestore
                </p>
                <p className="text-[11px] text-neutral-400 font-mono truncate">
                  UID: {currentUser.uid || 'auth-session-active'}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-neutral-950/60 border border-neutral-800 space-y-1">
                <span className="text-[11px] font-mono text-neutral-500 uppercase">Showroom Verification</span>
                <p className="text-sm font-semibold text-amber-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  Fast-Track Verified
                </p>
                <p className="text-[11px] text-neutral-400">Pune Tech Hub Counter (Bench A-04)</p>
              </div>
            </div>

            {/* Next Action Destinations */}
            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => {
                  if (currentUser.role === 'admin') onNavigateToTab('admin');
                  else if (currentUser.role === 'owner') onNavigateToTab('business');
                  else onNavigateToTab('student-dashboard');
                }}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-neutral-950 font-bold text-xs transition-all shadow-md shadow-amber-500/20 cursor-pointer"
              >
                <span>Go to {currentUser.role === 'admin' ? 'Admin Console' : currentUser.role === 'owner' ? 'Owner Portal' : 'Student Dashboard'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigateToTab('catalogue')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-medium text-xs border border-neutral-700 transition-colors cursor-pointer"
              >
                <Cpu className="w-4 h-4 text-amber-400" />
                <span>Browse Equipment Catalogue</span>
              </button>

              <button
                onClick={() => onNavigateToTab('virtual-lab')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-medium text-xs border border-neutral-700 transition-colors cursor-pointer"
              >
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>Open Virtual Circuits Lab</span>
              </button>
            </div>
          </div>
        ) : (
          /* Authentication Form & Role Selector */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left 7 cols: Role selection & Sign-in Actions */}
            <div className="lg:col-span-7 bg-neutral-900/90 border border-neutral-800 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
              <div>
                <span className="text-[11px] font-mono text-amber-400 uppercase tracking-wider">
                  Step 1: Choose Your Account Role
                </span>
                <h3 className="text-lg font-bold text-white mt-1">Select your access persona</h3>
                <p className="text-xs text-neutral-400 mt-1">
                  Your role determines access permissions, pricing subsidies, and dashboard capabilities.
                </p>
              </div>

              {/* 3 Role Selection Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedRole('student')}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                    selectedRole === 'student'
                      ? 'bg-amber-500/10 border-amber-500/60 shadow-md shadow-amber-500/10 ring-1 ring-amber-500/40'
                      : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700 text-neutral-400'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <GraduationCap className={`w-5 h-5 ${selectedRole === 'student' ? 'text-amber-400' : 'text-neutral-500'}`} />
                    {selectedRole === 'student' && <span className="w-2 h-2 rounded-full bg-amber-400" />}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Student</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">Rent gear & learn</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedRole('owner')}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                    selectedRole === 'owner'
                      ? 'bg-amber-500/10 border-amber-500/60 shadow-md shadow-amber-500/10 ring-1 ring-amber-500/40'
                      : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700 text-neutral-400'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <Building2 className={`w-5 h-5 ${selectedRole === 'owner' ? 'text-amber-400' : 'text-neutral-500'}`} />
                    {selectedRole === 'owner' && <span className="w-2 h-2 rounded-full bg-amber-400" />}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Lab Owner</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">List & consign gear</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedRole('admin')}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                    selectedRole === 'admin'
                      ? 'bg-amber-500/10 border-amber-500/60 shadow-md shadow-amber-500/10 ring-1 ring-amber-500/40'
                      : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700 text-neutral-400'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <ShieldAlert className={`w-5 h-5 ${selectedRole === 'admin' ? 'text-amber-400' : 'text-neutral-500'}`} />
                    {selectedRole === 'admin' && <span className="w-2 h-2 rounded-full bg-amber-400" />}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Administrator</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">Control hub & rules</p>
                  </div>
                </button>
              </div>

              {/* Dynamic Role Highlights */}
              <div className="p-3.5 rounded-xl bg-neutral-950/80 border border-neutral-800 text-xs space-y-2">
                <div className="flex items-center gap-2 text-amber-300 font-semibold">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>
                    {selectedRole === 'student' && 'Student Privileges & Subsidies'}
                    {selectedRole === 'owner' && 'Consignment Partner Economics'}
                    {selectedRole === 'admin' && 'Central Control & Governance'}
                  </span>
                </div>
                <ul className="text-[11px] text-neutral-400 space-y-1.5 list-disc list-inside">
                  {selectedRole === 'student' && (
                    <>
                      <li>Flat 15% discount on all lab oscilloscopes, function generators, and kits.</li>
                      <li>Zero security deposit on verified student identity card upload.</li>
                      <li>Instant sync with Dr. Silicon AI Mentor and Virtual Experiment progress.</li>
                    </>
                  )}
                  {selectedRole === 'owner' && (
                    <>
                      <li>65% monthly gross revenue share deposited directly to bank account.</li>
                      <li>₹50,000 damage coverage guarantee backed by platform escrow.</li>
                      <li>Live dashboard tracking equipment utilization and maintenance history.</li>
                    </>
                  )}
                  {selectedRole === 'admin' && (
                    <>
                      <li>Global oversight of rental reservations, security deposits, and pickups.</li>
                      <li>Dynamic pricing algorithm adjustment and courier delivery rate control.</li>
                      <li>Maintenance scheduling and physical showroom rack allocation.</li>
                    </>
                  )}
                </ul>
              </div>

              {/* Error Display */}
              {authError && (
                <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-800/60 text-xs text-rose-300 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                  <div>
                    <span className="font-semibold">Sign-In Error:</span> {authError}
                  </div>
                </div>
              )}

              {/* Step 2: Primary Google Auth Button */}
              <div className="space-y-3 pt-2">
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={isLoading}
                  className="w-full py-3.5 px-4 rounded-xl bg-white hover:bg-neutral-100 text-neutral-900 font-bold text-sm flex items-center justify-center gap-3 transition-all cursor-pointer shadow-xl shadow-black/40 disabled:opacity-50"
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-neutral-900 border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <svg className="w-5 h-5" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      />
                    </svg>
                  )}
                  <span>Continue with Google as {selectedRole.toUpperCase()}</span>
                </button>

                <p className="text-[11px] text-center text-neutral-500">
                  By connecting, your account profile is stored securely in Firebase Firestore.
                </p>
              </div>
            </div>

            {/* Right 5 cols: Instant Evaluator & Demo Accounts */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-neutral-900/90 border border-amber-500/20 rounded-2xl p-6 shadow-xl space-y-4">
                <div className="flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-amber-400" />
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                    Instant Demo Switcher
                  </h3>
                </div>
                <p className="text-xs text-neutral-400">
                  Evaluating this application? Test each role persona instantly with pre-populated electronics rentals, lab progress, and permissions:
                </p>

                {demoNotice && (
                  <div className="p-2.5 rounded-lg bg-emerald-950/60 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2 animate-in fade-in duration-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{demoNotice}</span>
                  </div>
                )}

                <div className="space-y-2.5">
                  <button
                    type="button"
                    onClick={() => handleDemoSignIn('student')}
                    className="w-full p-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 hover:border-amber-500/40 text-left transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <GraduationCap className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                        <div>
                          <div className="text-xs font-semibold text-white">Arjun Mehta (Student)</div>
                          <div className="text-[10px] text-neutral-400">COEP Tech · 3 Active Rentals · 280 XP</div>
                        </div>
                      </div>
                      <span className="text-[10px] text-amber-400 font-mono">Try →</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDemoSignIn('owner')}
                    className="w-full p-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 hover:border-amber-500/40 text-left transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <Building2 className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                        <div>
                          <div className="text-xs font-semibold text-white">Prof. Suresh Kulkarni (Owner)</div>
                          <div className="text-[10px] text-neutral-400">LabGears India · 14 Consigned Units</div>
                        </div>
                      </div>
                      <span className="text-[10px] text-amber-400 font-mono">Try →</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDemoSignIn('admin')}
                    className="w-full p-3 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 hover:border-amber-500/40 text-left transition-all cursor-pointer group"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <ShieldAlert className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                        <div>
                          <div className="text-xs font-semibold text-white">Dr. Rajiv Menon (Lead Admin)</div>
                          <div className="text-[10px] text-neutral-400">System Admin · Full DB & Pricing Control</div>
                        </div>
                      </div>
                      <span className="text-[10px] text-amber-400 font-mono">Try →</span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Physical Security & Verification Note */}
              <div className="bg-neutral-950/70 border border-neutral-800 rounded-2xl p-5 space-y-2 text-xs text-neutral-400">
                <div className="flex items-center gap-2 text-neutral-300 font-semibold">
                  <UserCheck className="w-4 h-4 text-amber-400" />
                  <span>Physical Verification Protocol</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  First-time equipment rentals require presenting a physical college identity card or government photo ID at the Pune Central Showroom checkout counter for initial biometric verification.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
