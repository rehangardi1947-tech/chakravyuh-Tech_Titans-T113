import React, { useState } from 'react';
import { 
  X, 
  Building2, 
  GraduationCap, 
  ShieldCheck, 
  ShieldAlert,
  Mail, 
  Lock,
  ArrowRight,
  Database,
  AlertCircle
} from 'lucide-react';
import { authService } from '../services/authService';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: { name: string; role: 'student' | 'owner' | 'admin'; email?: string; uid?: string }) => void;
  onOpenFullLoginPage?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLogin,
  onOpenFullLoginPage
}) => {
  if (!isOpen) return null;

  const [mode, setMode] = useState<'signin' | 'register'>('signin');
  const [role, setRole] = useState<'student' | 'owner' | 'admin'>('student');
  const [name, setName] = useState('Arjun Mehta');
  const [email, setEmail] = useState('arjun.mehta@coep.ac.in');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const user = await authService.signInWithGoogle(role);
      onLogin({
        name: user.displayName || user.email || 'ENTC Innovator',
        role: user.role,
        email: user.email || undefined,
        uid: user.uid
      });
      onClose();
    } catch (err: unknown) {
      console.error('Google Sign-in failed', err);
      const msg = err instanceof Error ? err.message : 'Google authentication failed';
      setErrorMessage(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let displayName = name || 'Arjun Mehta';
    let userEmail = email || 'arjun.mehta@coep.ac.in';
    if (role === 'owner') {
      displayName = 'Prof. Suresh Kulkarni';
      userEmail = 'suresh.kulkarni@labgears.in';
    } else if (role === 'admin') {
      displayName = 'Dr. Rajiv Menon (Lead Admin)';
      userEmail = 'rehangardi1947@gmail.com';
    }

    onLogin({
      name: displayName,
      role,
      email: userEmail,
      uid: `demo-${role}-${Date.now()}`
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0e0e12] border border-amber-500/30 rounded-2xl max-w-md w-full p-6 space-y-5 shadow-2xl text-left relative">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
          <div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-amber-400 uppercase tracking-wider">
              <Database className="w-3 h-3 text-amber-400" />
              <span>FIRESTORE DATABASE AUTH</span>
            </div>
            <h3 className="text-lg font-bold text-white mt-0.5">
              {mode === 'signin' ? 'Sign In to ENTCverse Hub' : 'Register New Account'}
            </h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-white cursor-pointer p-1 rounded-lg hover:bg-neutral-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Google Sign-In */}
        <div className="space-y-2">
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={isLoading}
            className="w-full py-2.5 px-3 rounded-xl bg-white hover:bg-neutral-100 text-neutral-900 font-semibold text-xs flex items-center justify-center gap-2.5 transition-all cursor-pointer shadow-md shadow-white/5 disabled:opacity-50"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-neutral-900 border-t-transparent rounded-full animate-spin" />
            ) : (
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
            )}
            <span>Sign In with Google</span>
          </button>

          {errorMessage && (
            <div className="p-2 rounded-lg bg-rose-950/60 border border-rose-800 text-[11px] text-rose-300 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="flex items-center gap-2 my-2 text-neutral-600 text-[10px]">
            <div className="flex-1 h-px bg-neutral-800" />
            <span className="uppercase font-mono">OR SELECT ROLE DEMO</span>
            <div className="flex-1 h-px bg-neutral-800" />
          </div>
        </div>

        {/* Role Selector: Student vs Owner vs Admin */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-neutral-950 rounded-xl border border-neutral-800">
          <button
            type="button"
            onClick={() => {
              setRole('student');
              setName('Arjun Mehta');
              setEmail('arjun.mehta@coep.ac.in');
            }}
            className={`py-2 px-1 text-center rounded-lg text-xs font-semibold flex flex-col items-center gap-1 transition-colors cursor-pointer ${
              role === 'student'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Student</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setRole('owner');
              setName('Prof. Suresh Kulkarni');
              setEmail('suresh.kulkarni@labgears.in');
            }}
            className={`py-2 px-1 text-center rounded-lg text-xs font-semibold flex flex-col items-center gap-1 transition-colors cursor-pointer ${
              role === 'owner'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Owner</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setRole('admin');
              setName('Dr. Rajiv Menon');
              setEmail('rehangardi1947@gmail.com');
            }}
            className={`py-2 px-1 text-center rounded-lg text-xs font-semibold flex flex-col items-center gap-1 transition-colors cursor-pointer ${
              role === 'admin'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Admin</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {mode === 'register' && (
            <div className="space-y-1">
              <label className="text-neutral-300 font-medium">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>
          )}

          <div className="space-y-1">
            <label className="text-neutral-300 font-medium">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-white focus:outline-none focus:border-amber-500/50"
              />
            </div>
          </div>

          <div className="p-3 rounded-lg bg-neutral-950/80 border border-neutral-800 text-[11px] text-neutral-300 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-amber-400" />
            <span>
              {role === 'student' && 'College ID unlocks instant 15% discount and waived deposit fees.'}
              {role === 'owner' && 'Consignment portal provides automated 65% monthly bank disbursements.'}
              {role === 'admin' && 'Admin credentials unlock global booking overrides and pricing engine configuration.'}
            </span>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 text-xs font-bold text-neutral-950 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 rounded-lg transition-all cursor-pointer shadow-md shadow-amber-500/20"
          >
            {mode === 'signin' ? `Continue as ${role.toUpperCase()}` : 'Complete Registration'}
          </button>
        </form>

        {onOpenFullLoginPage && (
          <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
            <span>Prefer dedicated portal?</span>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenFullLoginPage();
              }}
              className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>Open Login Page</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
