import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Calendar, 
  MapPin, 
  Truck, 
  CheckCircle2, 
  ShieldCheck, 
  QrCode, 
  FileText,
  Clock,
  Sparkles,
  AlertTriangle,
  Info,
  Scale
} from 'lucide-react';
import { EquipmentItem, RentalBooking } from '../types';
import { storageService } from '../services/storageService';
import { authService } from '../services/authService';
import { auth } from '../services/firebase';

interface BookingModalProps {
  equipment: EquipmentItem | null;
  onClose: () => void;
  onBookingConfirmed: (booking: RentalBooking) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  equipment,
  onClose,
  onBookingConfirmed
}) => {
  if (!equipment) return null;

  // Step state: 1: Dates & Quantity, 2: Customer Contact, 3: Review & Confirm, 4: Receipt
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Rental parameters
  const [rentalType, setRentalType] = useState<'daily' | 'weekly' | 'hourly'>('daily');
  const [quantity, setQuantity] = useState<number>(1);

  // Default dates: tomorrow to +3 days
  const tomorrow = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  }, []);

  const defaultEnd = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 4);
    return d.toISOString().split('T')[0];
  }, []);

  const [startDate, setStartDate] = useState<string>(tomorrow);
  const [endDate, setEndDate] = useState<string>(defaultEnd);
  const [hourlyCount, setHourlyCount] = useState<number>(4);

  // Delivery method
  const [deliveryType, setDeliveryType] = useState<'showroom_pickup' | 'express_courier'>('showroom_pickup');
  const [pickupLocation, setPickupLocation] = useState<string>(
    equipment.showroomLocation || 'Pune Central Electronics Showroom (JM Road)'
  );
  const [deliveryAddress, setDeliveryAddress] = useState<string>('COEP Hostel Block B, Shivaji Nagar, Pune');

  // Customer credentials
  const currentUser = storageService.getUserProfile();
  const [studentName, setStudentName] = useState(currentUser.name || 'Arjun Mehta');
  const [studentEmail, setStudentEmail] = useState(currentUser.email || 'arjun.mehta@coep.ac.in');
  const [studentPhone, setStudentPhone] = useState(currentUser.phone || '+91 98230 45112');
  const [collegeName, setCollegeName] = useState(currentUser.college || 'COEP Technological University');
  const [idNumber, setIdNumber] = useState(currentUser.studentId || 'COEP-2023-ENTC-042');
  const [hasStudentCard, setHasStudentCard] = useState(true);

  // Confirmed booking record
  const [confirmedBooking, setConfirmedBooking] = useState<RentalBooking | null>(null);

  // Calculate rental duration in days
  const computedDays = useMemo(() => {
    if (rentalType === 'hourly') return hourlyCount;
    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();
    if (isNaN(start) || isNaN(end) || end < start) return 1;
    const diffTime = Math.abs(end - start);
    return Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
  }, [startDate, endDate, rentalType, hourlyCount]);

  // Real-time availability check
  const availability = useMemo(() => {
    return storageService.checkAvailability(equipment.id, startDate, endDate, quantity);
  }, [equipment.id, startDate, endDate, quantity]);

  // Pricing engine calculations
  const quote = useMemo(() => {
    return storageService.calculatePricingQuote(
      equipment.dailyRate,
      equipment.deposit,
      computedDays,
      quantity,
      hasStudentCard,
      deliveryType,
      rentalType,
      equipment.hourlyRate
    );
  }, [equipment, computedDays, quantity, hasStudentCard, deliveryType, rentalType]);

  const handleConfirmReservation = () => {
    if (!availability.available) {
      alert(availability.message);
      return;
    }

    const bookingId = `ENTC-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newBooking: RentalBooking = {
      id: bookingId,
      equipmentId: equipment.id,
      equipmentName: equipment.name,
      quantity,
      startDate,
      endDate: rentalType === 'hourly' ? startDate : endDate,
      days: computedDays,
      rentalType,
      dailyRate: equipment.dailyRate,
      rawRent: quote.rawRent,
      durationDiscount: quote.durationDiscount,
      studentDiscount: quote.studentDiscount,
      deliveryFee: quote.deliveryFee,
      refundableDeposit: quote.totalDeposit,
      totalRent: quote.finalRent,
      totalPaid: quote.totalInitialDue,
      deliveryType,
      pickupLocation: deliveryType === 'showroom_pickup' ? pickupLocation : deliveryAddress,
      studentName,
      studentEmail,
      studentPhone,
      collegeName,
      idNumber,
      status: 'Confirmed',
      createdAt: new Date().toISOString(),
      isDemo: true
    };

    // Save to persistent storage service
    storageService.saveBooking(newBooking);

    // Synchronize to Firestore Database
    const currentUid = auth.currentUser?.uid || 'guest-user';
    authService.saveBookingToDb(newBooking, currentUid).catch((err) => {
      console.warn('Could not sync booking to Firestore immediately:', err);
    });

    setConfirmedBooking(newBooking);
    onBookingConfirmed(newBooking);
    setStep(4);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-[#0e1627] border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto p-6 space-y-6 shadow-2xl text-left">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2 text-[10px] font-mono text-cyan-400 uppercase tracking-wider">
              <span>RENTAL WORKFLOW</span>
              <span>·</span>
              <span className="text-amber-400">DEMO VERIFICATION MODE</span>
            </div>
            <h2 className="text-xl font-bold text-white mt-0.5">
              {step === 4 ? 'Reservation Confirmed' : `Reserve ${equipment.name}`}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP 4: CONFIRMATION RECEIPT */}
        {step === 4 && confirmedBooking && (
          <div className="space-y-6">
            <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/80 flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
              <div className="space-y-1 text-xs">
                <h4 className="text-sm font-bold text-white">
                  Booking Confirmed: {confirmedBooking.id}
                </h4>
                <p className="text-emerald-300">
                  Demo reservation logged to your browser session. Bench calibration verification has been requested at {confirmedBooking.pickupLocation}.
                </p>
              </div>
            </div>

            {/* QR Counter Pass and Verification Instructions */}
            <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center gap-6">
              <div className="p-3 bg-white rounded-xl text-slate-900 flex flex-col items-center shrink-0">
                <QrCode className="w-24 h-24 text-slate-900" />
                <span className="text-[10px] font-mono font-bold mt-1">SHOWROOM PASS</span>
              </div>
              <div className="space-y-2 text-xs">
                <div className="text-cyan-400 font-semibold uppercase tracking-wider text-[11px]">
                  Counter Pickup Guidelines
                </div>
                <p className="text-slate-300">
                  Present this QR pass along with your <strong className="text-white">{confirmedBooking.collegeName}</strong> student ID ({confirmedBooking.idNumber}) at the counter desk.
                </p>
                <div className="text-slate-400 space-y-1 font-mono text-[11px] pt-1">
                  <div>Equipment: <span className="text-white">{confirmedBooking.equipmentName}</span> (Qty: {confirmedBooking.quantity})</div>
                  <div>Period: <span className="text-white">{confirmedBooking.startDate}</span> to <span className="text-white">{confirmedBooking.endDate}</span> ({confirmedBooking.days} {confirmedBooking.rentalType === 'hourly' ? 'Hours' : 'Days'})</div>
                  <div>Security Deposit: <span className="text-cyan-400">₹{confirmedBooking.refundableDeposit}</span> (100% Refundable)</div>
                  <div>Current Status: <span className="text-emerald-400 font-bold">{confirmedBooking.status}</span></div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => {
                  alert(`Receipt for booking ${confirmedBooking.id} downloaded for ${confirmedBooking.studentName}.`);
                }}
                className="px-4 py-2.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-2 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Save Digital Receipt</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg cursor-pointer"
              >
                Close & View in Dashboard
              </button>
            </div>
          </div>
        )}

        {/* STEP 1: DATES, DURATION & QUANTITY */}
        {step === 1 && (
          <div className="space-y-5">
            {/* Equipment Thumbnail Header */}
            <div className="flex items-center gap-3.5 p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="w-14 h-14 rounded-lg overflow-hidden bg-slate-900 shrink-0">
                <img src={equipment.image} alt={equipment.name} className="w-full h-full object-cover" />
              </div>
              <div className="text-xs space-y-0.5">
                <div className="text-[10px] text-cyan-400 font-mono">{equipment.brand} · {equipment.category}</div>
                <h4 className="text-sm font-bold text-white">{equipment.name}</h4>
                <div className="text-slate-400 font-mono text-[11px]">
                  Daily: ₹{equipment.dailyRate} · Deposit: ₹{equipment.deposit} · Total Stock: {equipment.stockCount} units
                </div>
              </div>
            </div>

            {/* Rental Duration Mode */}
            <div className="space-y-2 text-xs">
              <label className="text-slate-300 font-semibold">Rental Pricing Option:</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setRentalType('daily')}
                  className={`p-2.5 rounded-lg border text-left cursor-pointer transition-colors ${
                    rentalType === 'daily'
                      ? 'bg-cyan-500/20 border-cyan-400 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="font-bold">Standard Daily</div>
                  <div className="text-[11px] text-slate-400 font-mono">₹{equipment.dailyRate}/day</div>
                </button>

                <button
                  type="button"
                  onClick={() => setRentalType('weekly')}
                  className={`p-2.5 rounded-lg border text-left cursor-pointer transition-colors ${
                    rentalType === 'weekly'
                      ? 'bg-cyan-500/20 border-cyan-400 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="font-bold">Weekly Pass</div>
                  <div className="text-[11px] text-emerald-400 font-mono">20% Multi-Day Off</div>
                </button>

                <button
                  type="button"
                  onClick={() => setRentalType('hourly')}
                  className={`p-2.5 rounded-lg border text-left cursor-pointer transition-colors ${
                    rentalType === 'hourly'
                      ? 'bg-cyan-500/20 border-cyan-400 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="font-bold">Lab Hours</div>
                  <div className="text-[11px] text-slate-400 font-mono">₹{equipment.hourlyRate || 35}/hr</div>
                </button>
              </div>
            </div>

            {/* Date Pickers or Hour Count */}
            {rentalType === 'hourly' ? (
              <div className="space-y-2 text-xs">
                <label className="text-slate-300 font-semibold">Bench Session Hours:</label>
                <div className="flex items-center gap-2">
                  {[2, 4, 6, 8].map((h) => (
                    <button
                      key={h}
                      type="button"
                      onClick={() => setHourlyCount(h)}
                      className={`flex-1 py-2 text-xs font-mono font-bold rounded-lg border transition-colors cursor-pointer ${
                        hourlyCount === h
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {h} Hours
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div>
                  <label className="text-slate-300 block mb-1 font-sans font-semibold">Start Date:</label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-sans font-semibold">End Date:</label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
                  />
                </div>
              </div>
            )}

            {/* Quantity Stepper */}
            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs">
              <div>
                <span className="font-semibold text-white">Quantity Needed:</span>
                <p className="text-[11px] text-slate-400">Available units in showroom: {availability.maxAvailable}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-white hover:bg-slate-800"
                >
                  -
                </button>
                <span className="w-8 text-center font-mono font-bold text-white">{quantity}</span>
                <button
                  type="button"
                  disabled={quantity >= equipment.stockCount}
                  onClick={() => setQuantity(Math.min(equipment.stockCount, quantity + 1))}
                  className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-white hover:bg-slate-800 disabled:opacity-40"
                >
                  +
                </button>
              </div>
            </div>

            {/* Live Inventory Availability Banner */}
            <div className={`p-3 rounded-xl border flex items-start gap-2.5 text-xs ${
              availability.available
                ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-300'
                : 'bg-rose-950/50 border-rose-800 text-rose-300'
            }`}>
              {availability.available ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              )}
              <div className="space-y-0.5">
                <div className="font-bold">{availability.available ? 'Inventory Reserved & Ready' : 'Reservation Conflict'}</div>
                <p className="text-[11px] opacity-90">{availability.message}</p>
              </div>
            </div>

            {/* Next Button */}
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!availability.available}
                onClick={() => setStep(2)}
                className="px-6 py-2.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg"
              >
                Continue to Contact Details →
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: CUSTOMER CONTACT & FULFILLMENT MODE */}
        {step === 2 && (
          <div className="space-y-5">
            {/* Fulfillment Mode */}
            <div className="space-y-2 text-xs">
              <label className="text-slate-300 font-semibold">Handover / Fulfillment Option:</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDeliveryType('showroom_pickup')}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-colors ${
                    deliveryType === 'showroom_pickup'
                      ? 'bg-cyan-950/40 border-cyan-500/70 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold flex items-center gap-1.5 text-white">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                      Showroom Pickup
                    </span>
                    <span className="text-[10px] text-emerald-400 font-bold uppercase">FREE</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">Ready in 1 hour. Bench test before leaving.</p>
                </button>

                <button
                  type="button"
                  onClick={() => setDeliveryType('express_courier')}
                  className={`p-3 rounded-xl border text-left cursor-pointer transition-colors ${
                    deliveryType === 'express_courier'
                      ? 'bg-cyan-950/40 border-cyan-500/70 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold flex items-center gap-1.5 text-white">
                      <Truck className="w-3.5 h-3.5 text-cyan-400" />
                      Campus Courier
                    </span>
                    <span className="text-[10px] font-mono text-slate-300">+₹99</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">Directly delivered to college lab or hostel.</p>
                </button>
              </div>
            </div>

            {deliveryType === 'express_courier' ? (
              <div className="space-y-1 text-xs">
                <label className="text-slate-300 font-medium">Campus Delivery Address</label>
                <input
                  type="text"
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-white"
                />
              </div>
            ) : (
              <div className="space-y-1 text-xs">
                <label className="text-slate-300 font-medium">Showroom Location</label>
                <input
                  type="text"
                  readOnly
                  value={pickupLocation}
                  className="w-full p-2.5 bg-slate-950/60 border border-slate-800 rounded-lg text-slate-400"
                />
              </div>
            )}

            {/* Contact Details */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
              <h4 className="font-semibold text-white">Student Identification & Contact</h4>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400 text-[11px]">Full Name</label>
                  <input
                    type="text"
                    required
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    className="w-full p-2 bg-slate-900 border border-slate-800 rounded text-slate-200"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 text-[11px]">Mobile Number</label>
                  <input
                    type="text"
                    required
                    value={studentPhone}
                    onChange={(e) => setStudentPhone(e.target.value)}
                    className="w-full p-2 bg-slate-900 border border-slate-800 rounded text-slate-200"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-400 text-[11px]">College / Institute</label>
                  <input
                    type="text"
                    required
                    value={collegeName}
                    onChange={(e) => setCollegeName(e.target.value)}
                    className="w-full p-2 bg-slate-900 border border-slate-800 rounded text-slate-200"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 text-[11px]">Student ID / PRN</label>
                  <input
                    type="text"
                    required
                    value={idNumber}
                    onChange={(e) => setIdNumber(e.target.value)}
                    className="w-full p-2 bg-slate-900 border border-slate-800 rounded text-slate-200"
                  />
                </div>
              </div>

              {/* Student Discount Toggle */}
              <div className="pt-2 flex items-center justify-between border-t border-slate-800/80">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span>Apply 15% Verified Student Subsidy</span>
                </div>
                <input
                  type="checkbox"
                  checked={hasStudentCard}
                  onChange={(e) => setHasStudentCard(e.target.checked)}
                  className="w-4 h-4 accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>

            {/* Back / Next */}
            <div className="flex justify-between items-center pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                ← Back to Dates
              </button>
              <button
                type="button"
                onClick={() => setStep(3)}
                className="px-6 py-2.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg"
              >
                Review Itemized Pricing →
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: ITEMIZED PRICING ENGINE REVIEW */}
        {step === 3 && (
          <div className="space-y-5 text-xs">
            {/* Transparent Cost Breakdown */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
              <h4 className="font-semibold text-white border-b border-slate-800 pb-2">
                Itemized Rental Price Engine
              </h4>

              <div className="flex justify-between text-slate-400">
                <span>
                  Base Rental ({computedDays} {rentalType === 'hourly' ? 'hours' : 'days'} × {quantity} unit @ ₹{rentalType === 'hourly' ? equipment.hourlyRate : equipment.dailyRate}):
                </span>
                <span className="font-mono text-white">₹{quote.rawRent}</span>
              </div>

              {quote.durationDiscount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Multi-day Duration Discount:</span>
                  <span className="font-mono">-₹{quote.durationDiscount}</span>
                </div>
              )}

              {quote.studentDiscount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Student ID Subsidy (15%):</span>
                  <span className="font-mono">-₹{quote.studentDiscount}</span>
                </div>
              )}

              {quote.deliveryFee > 0 && (
                <div className="flex justify-between text-slate-400">
                  <span>Campus Express Delivery:</span>
                  <span className="font-mono text-white">+₹{quote.deliveryFee}</span>
                </div>
              )}

              <div className="flex justify-between text-cyan-300 pt-1 border-t border-slate-800/80">
                <span>Net Rental Fee:</span>
                <span className="font-mono font-bold">₹{quote.finalRent}</span>
              </div>

              <div className="flex justify-between text-amber-300">
                <span>Refundable Security Deposit ({quantity} × ₹{equipment.deposit}):</span>
                <span className="font-mono font-bold">+₹{quote.totalDeposit}</span>
              </div>

              <div className="pt-2 border-t border-slate-800 flex justify-between items-baseline text-sm font-bold text-white">
                <span>Total Due on Handover:</span>
                <span className="text-xl font-mono text-cyan-400">₹{quote.totalInitialDue}</span>
              </div>
            </div>

            {/* Policy Invariants Callout */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-400 space-y-1">
              <div className="text-white font-semibold">Late Returns & Missing Accessory Policy:</div>
              <ul className="list-disc pl-4 space-y-0.5">
                <li>Late returns billed at 1.5× daily rate per day overdue.</li>
                <li>₹{quote.totalDeposit} security deposit is 100% refunded immediately upon bench check.</li>
                <li>Free cancellation anytime before bench test checkout.</li>
              </ul>
            </div>

            {/* Buttons */}
            <div className="flex justify-between items-center pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white"
              >
                ← Back to Details
              </button>
              <button
                type="button"
                onClick={handleConfirmReservation}
                className="px-6 py-2.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg shadow-md shadow-cyan-400/25"
              >
                Confirm Demo Reservation
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
