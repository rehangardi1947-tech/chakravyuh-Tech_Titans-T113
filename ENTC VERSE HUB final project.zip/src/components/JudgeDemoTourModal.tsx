import React, { useState } from 'react';
import { 
  Play, 
  RotateCcw, 
  CheckCircle2, 
  ChevronRight, 
  ChevronLeft, 
  X, 
  Sparkles, 
  Maximize2, 
  Minimize2, 
  Search, 
  Cpu, 
  Activity, 
  Bot, 
  DollarSign, 
  TrendingUp, 
  BookOpen, 
  Layers,
  HelpCircle,
  ExternalLink
} from 'lucide-react';
import { storageService } from '../services/storageService';

interface JudgeDemoTourModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: string) => void;
  onSelectEquipmentId: (equipmentId: string) => void;
  onOpenBooking: (equipmentId: string) => void;
  onOpenAiMentor: (initialQuery?: string) => void;
  onResetApp: () => void;
  onSearchEquipment: (query: string) => void;
}

interface DemoStep {
  step: number;
  title: string;
  category: string;
  description: string;
  talkingPoints: string[];
  actionLabel: string;
  actionIcon: React.ElementType;
  execute: (props: JudgeDemoTourModalProps) => void;
}

const DEMO_STEPS: DemoStep[] = [
  {
    step: 1,
    title: 'Landing Page & The Affordability Problem',
    category: 'Problem & Concept',
    description: 'Students often cannot afford expensive lab equipment (DSOs, bench power supplies, RF kits) just to practice experiments. Show how ENTCverse connects online virtual learning with physical showroom rentals.',
    talkingPoints: [
      'Personal laboratory equipment easily exceeds ₹50,000–₹1,50,000, creating an unequal barrier for engineering students.',
      'ENTCverse Hub is a hybrid platform: learn virtually for free, rent physical hardware for affordable short durations (₹65–₹290/day).',
      'Showrooms in Pune, Bengaluru, and Delhi with student verification and subsidized deposits.'
    ],
    actionLabel: 'Go to Landing Page',
    actionIcon: ExternalLink,
    execute: (props) => {
      props.onNavigateTab('home');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  },
  {
    step: 2,
    title: 'Search for ESP32 Temperature Kit',
    category: 'Discovery',
    description: 'Jump into the equipment catalogue and search for the ESP32 IoT Development and temperature sensor suite.',
    talkingPoints: [
      'Full catalog with 12 equipment categories, search filter, and real-time showroom availability.',
      'Items include comprehensive specifications, included kit accessories, and damage policy information.'
    ],
    actionLabel: 'Search ESP32 in Catalogue',
    actionIcon: Search,
    execute: (props) => {
      props.onNavigateTab('catalogue');
      props.onSearchEquipment('ESP32');
    }
  },
  {
    step: 3,
    title: 'Equipment Detail & Transparent Pricing',
    category: 'Product Details',
    description: 'Open the dedicated product view for the ESP32 IoT Suite with plain-English explanation, syllabus experiments, and rental options.',
    talkingPoints: [
      'Beginner-friendly explanation ("Think of this as a miniature Wi-Fi computer chip...")',
      'Transparent pricing breakdown: hourly (₹15), daily (₹65), and weekly (₹320) rates.',
      'Refundable security deposit and consumable accessories policy (zero deduction for jumper wires).'
    ],
    actionLabel: 'Open ESP32 Detail View',
    actionIcon: Cpu,
    execute: (props) => {
      props.onSelectEquipmentId('eq-esp32-devkit');
    }
  },
  {
    step: 4,
    title: 'Create a Demo Rental Booking',
    category: 'Rental Workflow',
    description: 'Open the 4-step rental checkout flow. See conflict detection, student 15% discount, showroom pickup, and demo booking confirmation.',
    talkingPoints: [
      'Multi-day discount logic + 15% student ID subsidy automatically applied.',
      'Collision prevention stops double-booking unavailable stock.',
      'Generates unique booking reference QR pass (e.g. ENTC-2026-XXXX) for instant showroom pickup.'
    ],
    actionLabel: 'Launch Booking Checkout',
    actionIcon: CheckCircle2,
    execute: (props) => {
      props.onOpenBooking('eq-esp32-devkit');
    }
  },
  {
    step: 5,
    title: 'Learning Academy: Temperature Monitoring',
    category: 'Education',
    description: 'Navigate to the ENTC Learning Academy and open Lesson #8 (Sensors & Actuators) or #7 (Temperature Fan Controller).',
    talkingPoints: [
      '15 structured curriculum paths designed for complete beginners.',
      'Includes learning objectives, everyday practical analogies, step-by-step lab procedures, common mistakes, and knowledge check quizzes.',
      'Awards real XP and gamification progress.'
    ],
    actionLabel: 'Open Learning Academy',
    actionIcon: BookOpen,
    execute: (props) => {
      props.onNavigateTab('learn');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  },
  {
    step: 6,
    title: 'Virtual Lab: Experiment #7 (Temp Fan Controller)',
    category: 'Simulation',
    description: 'Enter the Virtual Electronics Lab and launch Experiment #7: Temperature Sensor & Comparator Fan Controller.',
    talkingPoints: [
      'Safe sandbox with 8 supported circuits based on real mathematical calculation models.',
      'LM35 sensor outputs 10mV/°C to LM393 operational amplifier comparator.',
      'Includes clear callout on Software Simulation vs. Physical Bench Tolerances (±5% passive drift).'
    ],
    actionLabel: 'Open Virtual Lab (Exp #7)',
    actionIcon: Activity,
    execute: (props) => {
      props.onNavigateTab('virtual-lab');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  },
  {
    step: 7,
    title: 'Observe Reactive Simulation: Fan Activates',
    category: 'Interactive Physics',
    description: 'Slide the ambient chamber temperature slider above the 40°C threshold to observe the comparator swing to 12V and the cooling fan spin up to 3,200 RPM.',
    talkingPoints: [
      'Real-time reactive visual feedback: digital readouts, fan RPM animation, and hysteresis toggle.',
      'Students can save and reopen circuit configurations to browser storage.',
      'Direct "Rent Real Lab Kit" button connects virtual practice to physical showroom hardware.'
    ],
    actionLabel: 'Inspect Virtual Lab Controls',
    actionIcon: Activity,
    execute: (props) => {
      props.onNavigateTab('virtual-lab');
    }
  },
  {
    step: 8,
    title: 'Consult Dr. Silicon AI Mentor',
    category: 'AI Guidance',
    description: 'Open Dr. Silicon, the ENTCverse AI Lab Mentor, to explain temperature threshold switching, flyback diode protection, or Arduino code.',
    talkingPoints: [
      'Domain-specialized AI mentor tailored for electronics engineering education.',
      'Explains circuit theory, pinout traps, and identifies wiring mistakes before students power on physical hardware.',
      'Recommends exact test instruments required for capstone projects.'
    ],
    actionLabel: 'Ask Dr. Silicon Mentor',
    actionIcon: Bot,
    execute: (props) => {
      props.onOpenAiMentor("Can you explain how an analog comparator and flyback diode protect a circuit when driving an inductive cooling fan?");
    }
  },
  {
    step: 9,
    title: 'Equipment-Owner Console & Revenue Summary',
    category: 'Owner Hub',
    description: 'Open the Owner Hub to showcase the consignment marketplace where equipment owners, alumni, and colleges monetize idle hardware.',
    talkingPoints: [
      'Consignment listings with payout splits (65% owner / 35% platform).',
      'Showroom bench inspection modal with damage rating and deposit deduction workflows.',
      'Maintenance ledger and ledger CSV export for laboratory inventory managers.'
    ],
    actionLabel: 'Open Owner Console',
    actionIcon: DollarSign,
    execute: (props) => {
      props.onNavigateTab('business');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  },
  {
    step: 10,
    title: 'Business Model & Showroom Expansion',
    category: 'Commercial Scaling',
    description: 'Review the 8 diversified revenue streams and interactive financial calculator modeling showroom expansion across engineering hubs.',
    talkingPoints: [
      '8 sustainable revenue streams: Rentals, consumables, kits, corporate sponsorship, repairs, damage protection, workshops, and showroom access.',
      'Interactive financial calculator with adjustable inventory and utilization sliders.',
      'Strategic roadmap from Pune flagship showroom to university campus locker hubs.'
    ],
    actionLabel: 'Open Business Model Calculator',
    actionIcon: TrendingUp,
    execute: (props) => {
      props.onNavigateTab('business-model');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }
];

export const JudgeDemoTourModal: React.FC<JudgeDemoTourModalProps> = (props) => {
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [isMinimized, setIsMinimized] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [resetSuccessToast, setResetSuccessToast] = useState(false);

  if (!props.isOpen) return null;

  const step = DEMO_STEPS[currentStepIdx];
  const ActionIcon = step.actionIcon;

  const handleNext = () => {
    if (currentStepIdx < DEMO_STEPS.length - 1) {
      const nextIdx = currentStepIdx + 1;
      setCurrentStepIdx(nextIdx);
      DEMO_STEPS[nextIdx].execute(props);
    }
  };

  const handlePrev = () => {
    if (currentStepIdx > 0) {
      const prevIdx = currentStepIdx - 1;
      setCurrentStepIdx(prevIdx);
      DEMO_STEPS[prevIdx].execute(props);
    }
  };

  const handleJumpToStep = (idx: number) => {
    setCurrentStepIdx(idx);
    DEMO_STEPS[idx].execute(props);
  };

  const handleExecuteCurrent = () => {
    step.execute(props);
  };

  const handleResetData = () => {
    storageService.resetToFactoryDefaults();
    setShowResetConfirm(false);
    setResetSuccessToast(true);
    props.onResetApp();
    setTimeout(() => setResetSuccessToast(false), 3000);
  };

  return (
    <div className="fixed bottom-4 left-4 z-50 max-w-lg w-full text-left font-sans">
      {/* Toast Notification */}
      {resetSuccessToast && (
        <div className="mb-2 p-3 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>Demo data successfully reset to pristine factory state!</span>
        </div>
      )}

      {/* Confirmation Dialog for Reset */}
      {showResetConfirm && (
        <div className="mb-3 p-4 rounded-2xl bg-slate-900 border border-red-500/50 shadow-2xl space-y-3">
          <div className="text-xs text-white">
            <span className="font-bold text-red-400 block mb-1">Reset All Demo Data?</span>
            This will restore all default bookings, inventory, student XP (280 XP / Lvl 2), and clean virtual lab configs for a fresh judge demonstration.
          </div>
          <div className="flex justify-end gap-2 text-xs">
            <button
              onClick={() => setShowResetConfirm(false)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleResetData}
              className="px-3 py-1.5 rounded-lg bg-red-500 text-white font-bold hover:bg-red-600 cursor-pointer"
            >
              Confirm Reset
            </button>
          </div>
        </div>
      )}

      {/* Minimized Pill */}
      {isMinimized ? (
        <div className="bg-slate-900/95 border border-cyan-500/50 rounded-2xl p-3 shadow-2xl flex items-center justify-between gap-3 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
            <span className="text-xs font-mono font-bold text-white">
              Demo Step {step.step}/10: {step.title}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleExecuteCurrent}
              className="px-2.5 py-1 rounded-lg bg-cyan-500 text-slate-950 font-bold text-xs cursor-pointer"
            >
              Run
            </button>
            <button
              onClick={() => setIsMinimized(false)}
              className="p-1 text-slate-400 hover:text-white cursor-pointer"
              title="Expand"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
            <button
              onClick={props.onClose}
              className="p-1 text-slate-400 hover:text-white cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* Full Expanded Tour Box */
        <div className="bg-slate-900/98 border border-cyan-500/40 rounded-2xl p-5 shadow-2xl backdrop-blur-md space-y-4">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 font-bold">
                <Play className="w-3.5 h-3.5 fill-current" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-xs sm:text-sm font-extrabold text-white tracking-tight">
                    Live Hackathon Judge Tour
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    Step {step.step} of 10
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono uppercase">{step.category}</span>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setShowResetConfirm(true)}
                title="Reset Demo Data to Pristine Defaults"
                className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsMinimized(true)}
                title="Minimize"
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
              <button
                onClick={props.onClose}
                title="Close Tour"
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Current Step Content */}
          <div className="space-y-2.5">
            <h4 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 font-mono font-bold text-xs flex items-center justify-center">
                {step.step}
              </span>
              <span>{step.title}</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              {step.description}
            </p>

            {/* Judge Talking Points */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
              <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider block">
                Key Judge Talking Points:
              </span>
              <ul className="space-y-1 text-xs text-slate-300">
                {step.talkingPoints.map((tp, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <span className="text-cyan-400 mt-0.5">•</span>
                    <span>{tp}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Step Action Button */}
          <div>
            <button
              onClick={handleExecuteCurrent}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-cyan-500/20"
            >
              <ActionIcon className="w-4 h-4" />
              <span>{step.actionLabel}</span>
            </button>
          </div>

          {/* Stepper Navigation */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
            <button
              onClick={handlePrev}
              disabled={currentStepIdx === 0}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 flex items-center gap-1 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>

            {/* Quick Step Indicators */}
            <div className="flex items-center gap-1">
              {DEMO_STEPS.map((s, idx) => (
                <button
                  key={s.step}
                  onClick={() => handleJumpToStep(idx)}
                  className={`w-5 h-5 rounded-md font-mono text-[10px] transition-all cursor-pointer ${
                    currentStepIdx === idx
                      ? 'bg-cyan-500 text-slate-950 font-bold'
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
                  title={s.title}
                >
                  {s.step}
                </button>
              ))}
            </div>

            <button
              onClick={handleNext}
              disabled={currentStepIdx === DEMO_STEPS.length - 1}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 flex items-center gap-1 cursor-pointer"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
