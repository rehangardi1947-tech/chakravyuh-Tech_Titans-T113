import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  ArrowRight, 
  Cpu, 
  Activity, 
  ShieldCheck, 
  Building2, 
  Zap, 
  Sparkles,
  Layers,
  GraduationCap,
  Play,
  CheckCircle2,
  Sliders,
  Compass
} from 'lucide-react';
import { ThreeElectronicsHero } from './ThreeElectronicsHero';
import { EQUIPMENT_ITEMS } from '../data/equipmentData';
import { EquipmentItem } from '../types';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  onExploreClick: () => void;
  onStartLearningClick: () => void;
  onSelectEquipment: (item: EquipmentItem) => void;
  onOpenVirtualLab: () => void;
  onOpenProjects?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreClick,
  onStartLearningClick,
  onSelectEquipment,
  onOpenVirtualLab,
  onOpenProjects = onExploreClick
}) => {
  const sectionRef = useRef<HTMLElement>(null);
  const textColRef = useRef<HTMLDivElement>(null);
  const threeColRef = useRef<HTMLDivElement>(null);
  const glowBackdropRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const descRef = useRef<HTMLParagraphElement>(null);
  const ctaGroupRef = useRef<HTMLDivElement>(null);
  const trustBarRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const ctx = gsap.context(() => {
      // 1. Initial Staggered Entrance
      const entranceTl = gsap.timeline({ defaults: { ease: 'power3.out', duration: 0.9 } });
      
      entranceTl
        .from(badgeRef.current, { y: 16, opacity: 0, duration: 0.6 })
        .from(headlineRef.current, { y: 24, opacity: 0, duration: 0.8 }, '-=0.4')
        .from(descRef.current, { y: 20, opacity: 0, duration: 0.7 }, '-=0.5')
        .from(ctaGroupRef.current, { y: 18, opacity: 0, duration: 0.6 }, '-=0.5')
        .from(trustBarRef.current, { y: 16, opacity: 0, duration: 0.6 }, '-=0.4')
        .from(threeColRef.current, { scale: 0.94, opacity: 0, y: 30, duration: 1.1, ease: 'expo.out' }, '-=0.8');

      // 2. Subtle Scroll Parallax
      if (sectionRef.current) {
        gsap.to(textColRef.current, {
          y: 65,
          opacity: 0.88,
          ease: 'power1.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top top',
            end: 'bottom top',
            scrub: 1.0,
            invalidateOnRefresh: true
          }
        });

        gsap.to(threeColRef.current, {
          y: -45,
          scale: 0.97,
          rotateX: 2.5,
          ease: 'power1.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top top',
            end: 'bottom top',
            scrub: 1.4,
            invalidateOnRefresh: true
          }
        });

        gsap.to(glowBackdropRef.current, {
          y: 110,
          opacity: 0.35,
          ease: 'none',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top top',
            end: 'bottom top',
            scrub: 1.8
          }
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="relative overflow-hidden pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-amber-500/20 bg-tech-grid"
    >
      {/* Soft warm gold ambient background glow accents */}
      <div ref={glowBackdropRef} className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-amber-500/10 blur-[130px] rounded-full" />
        <div className="absolute top-1/3 right-10 w-[500px] h-[400px] bg-yellow-500/5 blur-[140px] rounded-full" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          
          {/* Left Column: Headline, Description, CTAs, Trust indicators */}
          <div ref={textColRef} className="lg:col-span-6 space-y-6 text-left will-change-transform">
            
            {/* Small glowing label in Golden & Black */}
            <div 
              ref={badgeRef}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-neutral-950/90 border border-amber-500/40 text-xs font-mono font-semibold text-amber-300 shadow-[0_0_15px_rgba(212,175,55,0.15)]"
            >
              <span className="flex h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
              <span className="tracking-wide uppercase">THE FUTURE OF PRACTICAL ELECTRONICS</span>
            </div>

            {/* Main Headline */}
            <h1 
              ref={headlineRef}
              className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-extrabold text-white tracking-tight leading-[1.12]" 
              style={{ textWrap: 'balance' }}
            >
              Your Electronics Lab.{' '}
              <span className="bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500 bg-clip-text text-transparent font-extrabold">
                Without the Expensive Setup.
              </span>
            </h1>

            {/* Supporting Description */}
            <p 
              ref={descRef}
              className="text-base sm:text-lg text-neutral-300 leading-relaxed max-w-xl font-normal"
            >
              Why spend ₹40,000–₹1,50,000 on an oscilloscope, RF analyzer, or function generator for a two-week project? 
              <strong className="text-amber-200 font-semibold"> ENTCverse Hub</strong> connects interactive virtual circuit simulations with physical showroom equipment rentals, guided engineering tutorials, and real-world capstone blueprints.
            </p>

            {/* Primary & Secondary Action CTAs (Golden & Black) */}
            <div ref={ctaGroupRef} className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onExploreClick}
                className="px-6 py-3.5 text-sm font-extrabold text-black bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:brightness-110 rounded-xl shadow-lg shadow-amber-500/20 hover:shadow-amber-500/35 hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center gap-2 cursor-pointer group"
              >
                <span>Explore Equipment</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onOpenVirtualLab}
                className="px-6 py-3.5 text-sm font-bold text-amber-300 bg-neutral-950/90 hover:bg-neutral-900 border border-amber-500/40 hover:border-amber-400 rounded-xl transition-all hover:-translate-y-0.5 flex items-center gap-2 shadow-sm cursor-pointer group"
              >
                <Activity className="w-4 h-4 text-amber-400 group-hover:rotate-12 transition-transform" />
                <span>Enter Virtual Lab</span>
              </button>

              <button
                onClick={onStartLearningClick}
                className="px-4 py-3.5 text-sm font-medium text-amber-400/80 hover:text-amber-300 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <GraduationCap className="w-4 h-4 text-amber-400" />
                <span>Learning Academy</span>
              </button>
            </div>

            {/* Genuine Trust & Value Indicators (Obsidian & Gold Border Cards) */}
            <div 
              ref={trustBarRef}
              className="pt-6 border-t border-amber-500/20 grid grid-cols-1 sm:grid-cols-3 gap-3.5 text-xs text-neutral-300"
            >
              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-neutral-950/80 border border-amber-500/25 shadow-sm">
                <Building2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-medium">Showrooms in Pune & Bengaluru</span>
              </div>
              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-neutral-950/80 border border-amber-500/25 shadow-sm">
                <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-medium">Calibrated Bench Test Gear</span>
              </div>
              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-neutral-950/80 border border-amber-500/25 shadow-sm">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-medium">Subsidized Student Protection</span>
              </div>
            </div>
          </div>

          {/* Right Column: 3D Electronics Laboratory Scene */}
          <div ref={threeColRef} className="lg:col-span-6 relative will-change-transform">
            <ThreeElectronicsHero
              onExploreEquipment={onExploreClick}
              onOpenVirtualLab={onOpenVirtualLab}
              onOpenProjects={onOpenProjects}
            />
          </div>

        </div>
      </div>
    </section>
  );
};
