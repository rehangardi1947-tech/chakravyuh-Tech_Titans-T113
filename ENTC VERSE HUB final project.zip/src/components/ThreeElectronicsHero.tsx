import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { 
  Cpu, 
  Zap, 
  Activity, 
  Radio, 
  Layers, 
  ExternalLink, 
  Sparkles, 
  Info, 
  CheckCircle2, 
  Maximize2, 
  RotateCcw, 
  Sliders, 
  Play, 
  Pause, 
  Box, 
  Compass,
  AlertCircle
} from 'lucide-react';

interface HotspotData {
  id: string;
  name: string;
  category: string;
  description: string;
  specs: string;
  relatedActionLabel: string;
  position3D: [number, number, number];
  fallbackPosition: { left: string; top: string };
  color: string;
}

const MAINBOARD_HOTSPOTS: HotspotData[] = [
  {
    id: 'esp32',
    name: 'ESP32-WROOM-32E Dual-Core MCU',
    category: 'Compute Core',
    description: 'Tensilica Xtensa LX6 @ 240MHz with integrated 2.4GHz Wi-Fi 802.11 b/g/n and Bluetooth 4.2 BR/EDR & BLE.',
    specs: '520KB SRAM · 4MB SPI Flash · 34 Programmable GPIOs',
    relatedActionLabel: 'Inspect in Catalogue',
    position3D: [-0.9, 0.28, -0.2],
    fallbackPosition: { left: '38%', top: '48%' },
    color: '#09090b'
  },
  {
    id: 'ultravision',
    name: 'Rigol UltraVision Acquisition Core',
    category: 'Signal Processing',
    description: 'Hardware FPGA engine providing real-time 1 GSa/s sampling, 24 Mpts memory depth, and 30,000 wfms/s capture.',
    specs: '100MHz Analog Bandwidth · 4 Channels · Hardware Zoom',
    relatedActionLabel: 'Rent Rigol 100MHz DSO',
    position3D: [1.2, 0.25, 0.6],
    fallbackPosition: { left: '68%', top: '48%' },
    color: '#2563eb'
  },
  {
    id: 'resistors',
    name: '1% Metal Film Precision Array',
    category: 'Passive Regulation',
    description: 'High-stability 330Ω & 10kΩ current limiting and pull-up arrays preventing pin damage and thermal runaway.',
    specs: '±1% Tolerance · Low Thermal Drift (50ppm/°C)',
    relatedActionLabel: 'Simulate in Virtual Lab',
    position3D: [-1.8, 0.2, 0.9],
    fallbackPosition: { left: '22%', top: '65%' },
    color: '#15803d'
  },
  {
    id: 'capacitors',
    name: 'Low-ESR Decoupling Filter Bank',
    category: 'Power Conditioning',
    description: 'Nichicon aluminum electrolytic and multilayer ceramic capacitors suppressing high-frequency switching ripple.',
    specs: '470μF 25V + 100nF SMD 0805 Bypass Rail',
    relatedActionLabel: 'Test in Virtual Lab',
    position3D: [1.8, 0.4, -0.8],
    fallbackPosition: { left: '78%', top: '28%' },
    color: '#7c3aed'
  },
  {
    id: 'rf_transceiver',
    name: 'Sub-GHz LoRa RF Front-End',
    category: 'Telecommunication',
    description: 'SX1276 telemetry node offering +20dBm output power and ultra-long range spread spectrum link budget up to 15km.',
    specs: '868MHz / 915MHz · -148dBm Sensitivity · SPI Interface',
    relatedActionLabel: 'View LoRa Capstone Project',
    position3D: [-1.7, 0.22, -1.2],
    fallbackPosition: { left: '22%', top: '28%' },
    color: '#b45309'
  }
];

const DSO_HOTSPOTS: HotspotData[] = [
  {
    id: 'dso_screen',
    name: '7.0-inch WVGA Color TFT Display',
    category: 'Display & Waveforms',
    description: '800x480 resolution with 64 intensity grading levels for catching transient runt pulses and jitter anomalies.',
    specs: '30,000 wfms/s Real-Time Capture · 8x14 Div Graticule',
    relatedActionLabel: 'View Oscilloscope Specs',
    position3D: [-0.6, 0.9, 0.95],
    fallbackPosition: { left: '38%', top: '45%' },
    color: '#09090b'
  },
  {
    id: 'dso_bnc',
    name: '4x Gold-Plated BNC Analog Inputs',
    category: 'Signal Channels',
    description: 'High-impedance (1MΩ || 15pF) analog front-ends with independent vertical attenuators from 1mV/div to 10V/div.',
    specs: '100MHz Bandwidth · CAT I 300Vrms Safety Isolation',
    relatedActionLabel: 'Rent DSO Bundle',
    position3D: [0.85, 0.45, 0.95],
    fallbackPosition: { left: '68%', top: '68%' },
    color: '#2563eb'
  },
  {
    id: 'dso_knobs',
    name: 'Rotary Timebase & Volts/Div Controls',
    category: 'Ergonomic Control',
    description: 'Precision mechanical rotary optical encoders for instant timebase scaling from 5ns/div to 50s/div.',
    specs: 'Smooth Continuous Scaling · Push-to-Zero Reset',
    relatedActionLabel: 'Explore Lab Guides',
    position3D: [1.2, 1.1, 0.95],
    fallbackPosition: { left: '78%', top: '40%' },
    color: '#15803d'
  }
];

const IOT_HOTSPOTS: HotspotData[] = [
  {
    id: 'iot_oled',
    name: '0.96-inch I2C Monochrome OLED',
    category: 'Telemetry Interface',
    description: '128x64 SSD1306 high-contrast display showing real-time temperature, humidity, and Wi-Fi link RSSI.',
    specs: 'I2C 400kHz · 0.04W Ultra-low consumption',
    relatedActionLabel: 'Test in Virtual Lab',
    position3D: [0, 0.45, 0.3],
    fallbackPosition: { left: '48%', top: '42%' },
    color: '#09090b'
  },
  {
    id: 'iot_sensor',
    name: 'Digital DHT22 Environmental Sensor',
    category: 'Sensing Element',
    description: 'Capacitive humidity sensing element and thermistor providing ±0.5°C temperature precision.',
    specs: '-40°C to +80°C · 0-100% RH · 1-Wire Protocol',
    relatedActionLabel: 'View IoT Weather Project',
    position3D: [1.1, 0.35, -0.3],
    fallbackPosition: { left: '72%', top: '48%' },
    color: '#b45309'
  }
];

type ModelType = 'mainboard' | 'oscilloscope' | 'iot_node';

interface ThreeElectronicsHeroProps {
  onExploreEquipment: () => void;
  onOpenVirtualLab: () => void;
  onOpenProjects: () => void;
}

export const ThreeElectronicsHero: React.FC<ThreeElectronicsHeroProps> = ({
  onExploreEquipment,
  onOpenVirtualLab,
  onOpenProjects
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [activeModel, setActiveModel] = useState<ModelType>('mainboard');
  const [activeHotspot, setActiveHotspot] = useState<HotspotData | null>(null);
  const [isRotating, setIsRotating] = useState(true);
  const [isWireframe, setIsWireframe] = useState(false);
  const [webglSupported, setWebglSupported] = useState(true);
  const [hotspotPositions, setHotspotPositions] = useState<{ [id: string]: { x: number; y: number; visible: boolean } }>({});
  
  const activeModelRef = useRef<ModelType>(activeModel);
  activeModelRef.current = activeModel;

  const isRotatingRef = useRef(isRotating);
  isRotatingRef.current = isRotating;

  const isWireframeRef = useRef(isWireframe);
  isWireframeRef.current = isWireframe;

  const mouseRef = useRef<{ x: number; y: number; targetX: number; targetY: number }>({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const animFrameRef = useRef<number | null>(null);

  const currentHotspots = activeModel === 'mainboard' 
    ? MAINBOARD_HOTSPOTS 
    : activeModel === 'oscilloscope' 
    ? DSO_HOTSPOTS 
    : IOT_HOTSPOTS;

  const handleHotspotAction = (hotspot: HotspotData) => {
    if (hotspot.id.includes('esp32') || hotspot.id.includes('dso') || hotspot.id.includes('ultravision')) {
      onExploreEquipment();
    } else if (hotspot.id.includes('resistor') || hotspot.id.includes('cap') || hotspot.id.includes('oled')) {
      onOpenVirtualLab();
    } else {
      onOpenProjects();
    }
  };

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const container = containerRef.current;
    const canvas = canvasRef.current;
    let width = container.clientWidth;
    let height = container.clientHeight || 560;

    const probeGl = () => {
      try {
        if (!window.WebGLRenderingContext) return false;
        const testCanvas = document.createElement('canvas');
        const ctx = testCanvas.getContext('webgl2') || testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
        return !!ctx;
      } catch {
        return false;
      }
    };

    if (!probeGl()) {
      setWebglSupported(false);
      return;
    }

    // 1. Scene Setup & Atmosphere (Obsidian Black & Golden Glow Fog)
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x09090b, 0.045);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 4.2, 6.2);
    camera.lookAt(0, 0, 0);

    // 2. High-Performance Studio PBR Renderer
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        alpha: true,
        powerPreference: 'default'
      });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.25;
    } catch (err) {
      console.warn('WebGLRenderer context creation disabled in browser/sandbox:', err);
      setWebglSupported(false);
      return;
    }

    try {
      const pmremGenerator = new THREE.PMREMGenerator(renderer);
      scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
      pmremGenerator.dispose();
    } catch (e) {
      console.warn('PMREMGenerator RoomEnvironment skipped:', e);
    }

    // 3. Studio PBR Lighting Rig with Golden Accents
    const hemiLight = new THREE.HemisphereLight(0xfffaed, 0x09090b, 2.4);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 3.4);
    keyLight.position.set(6, 9, 5);
    scene.add(keyLight);

    const goldRimLight = new THREE.DirectionalLight(0xfbbf24, 2.8);
    goldRimLight.position.set(-6, 3, -5);
    scene.add(goldRimLight);

    const ledPointLight = new THREE.PointLight(0xf59e0b, 3.0, 5.0);
    ledPointLight.position.set(0, 0.8, 0);
    scene.add(ledPointLight);

    // 4. Soft Contact Shadow
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 256;
    shadowCanvas.height = 256;
    const sCtx = shadowCanvas.getContext('2d');
    if (sCtx) {
      const grad = sCtx.createRadialGradient(128, 128, 10, 128, 128, 128);
      grad.addColorStop(0, 'rgba(0, 0, 0, 0.35)');
      grad.addColorStop(0.5, 'rgba(0, 0, 0, 0.12)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      sCtx.fillStyle = grad;
      sCtx.fillRect(0, 0, 256, 256);
    }
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    const contactShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(6.2, 4.8),
      new THREE.MeshBasicMaterial({
        map: shadowTexture,
        transparent: true,
        depthWrite: false
      })
    );
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.y = -0.05;
    scene.add(contactShadow);

    const masterGroup = new THREE.Group();
    scene.add(masterGroup);

    // MODEL 1: PROCEDURAL ENTC MAINBOARD (Matte Black / Cream Gold)
    const mainboardGroup = new THREE.Group();
    masterGroup.add(mainboardGroup);

    const pcbCanvas = document.createElement('canvas');
    pcbCanvas.width = 1024;
    pcbCanvas.height = 1024;
    const pCtx = pcbCanvas.getContext('2d');
    if (pCtx) {
      pCtx.fillStyle = '#18181b'; // Matte dark charcoal/black PCB substrate
      pCtx.fillRect(0, 0, 1024, 1024);
      pCtx.strokeStyle = '#d4af37'; // Gold copper traces
      pCtx.lineWidth = 3;
      for (let i = 80; i < 960; i += 120) {
        pCtx.beginPath();
        pCtx.moveTo(i, 80);
        pCtx.lineTo(i + 60, 200);
        pCtx.lineTo(920, 200);
        pCtx.stroke();
      }
      pCtx.fillStyle = '#faf8f5';
      pCtx.font = 'bold 22px monospace';
      pCtx.fillText('ENTCVERSE HUB · CRAFTED IN PUNE & BENGALURU', 180, 940);
    }
    const pcbTexture = new THREE.CanvasTexture(pcbCanvas);
    const pcbBase = new THREE.Mesh(
      new THREE.BoxGeometry(5.4, 0.12, 3.8),
      new THREE.MeshStandardMaterial({ map: pcbTexture, roughness: 0.5, metalness: 0.15 })
    );
    pcbBase.position.y = 0.06;
    mainboardGroup.add(pcbBase);

    const goldMat = new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.9, roughness: 0.2 });
    for (let f = -2.2; f <= 2.2; f += 0.22) {
      const finger = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.13, 0.45), goldMat);
      finger.position.set(f, 0.06, 1.85);
      mainboardGroup.add(finger);
    }

    const espGroup = new THREE.Group();
    espGroup.position.set(-0.9, 0.12, -0.2);
    mainboardGroup.add(espGroup);
    const espSub = new THREE.Mesh(
      new THREE.BoxGeometry(1.6, 0.08, 2.2),
      new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.5, metalness: 0.1 })
    );
    espGroup.add(espSub);
    const espCan = new THREE.Mesh(
      new THREE.BoxGeometry(1.3, 0.22, 1.4),
      new THREE.MeshStandardMaterial({ color: 0xf5f5f4, metalness: 0.9, roughness: 0.2 })
    );
    espCan.position.set(0, 0.14, 0.2);
    espGroup.add(espCan);
    const espAntenna = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.03, 0.45), goldMat);
    espAntenna.position.set(0, 0.05, -0.75);
    espGroup.add(espAntenna);

    const fpgaGroup = new THREE.Group();
    fpgaGroup.position.set(1.2, 0.12, 0.6);
    mainboardGroup.add(fpgaGroup);
    const fpgaBody = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 0.18, 1.2),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.6, metalness: 0.2 })
    );
    fpgaGroup.add(fpgaBody);
    const fpgaCore = new THREE.Mesh(
      new THREE.BoxGeometry(0.7, 0.02, 0.7),
      new THREE.MeshStandardMaterial({ color: 0xd4af37, emissive: 0x92400e, emissiveIntensity: 0.5, metalness: 0.9, roughness: 0.2 })
    );
    fpgaCore.position.set(0, 0.1, 0);
    fpgaGroup.add(fpgaCore);

    const capMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.35, metalness: 0.3 });
    const capTopMat = new THREE.MeshStandardMaterial({ color: 0xe5e5e5, metalness: 0.9, roughness: 0.2 });
    [[1.8, -0.8, 0.65, 0.3], [2.2, -0.5, 0.5, 0.24], [1.9, -1.2, 0.45, 0.2]].forEach(([cx, cz, ch, cr]) => {
      const can = new THREE.Mesh(new THREE.CylinderGeometry(cr, cr, ch, 16), capMat);
      can.position.set(cx, ch / 2 + 0.12, cz);
      mainboardGroup.add(can);
      const top = new THREE.Mesh(new THREE.CylinderGeometry(cr * 0.95, cr * 0.95, 0.03, 16), capTopMat);
      top.position.set(cx, ch + 0.13, cz);
      mainboardGroup.add(top);
    });

    const resBodyMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.5, metalness: 0.1 });
    const resLeadMat = new THREE.MeshStandardMaterial({ color: 0x71717a, metalness: 0.9, roughness: 0.2 });
    [-1.8, -2.1].forEach(rx => {
      [0.7, 1.0, 1.3].forEach(rz => {
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.38, 12), resBodyMat);
        body.rotation.z = Math.PI / 2;
        body.position.set(rx, 0.18, rz);
        mainboardGroup.add(body);
        const lead = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.65, 8), resLeadMat);
        lead.rotation.z = Math.PI / 2;
        lead.position.set(rx, 0.18, rz);
        mainboardGroup.add(lead);
      });
    });

    const rfMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 0.14, 0.9),
      new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.4, metalness: 0.6 })
    );
    rfMesh.position.set(-1.7, 0.16, -1.2);
    mainboardGroup.add(rfMesh);
    const smaBarrel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.12, 0.12, 0.4, 12),
      goldMat
    );
    smaBarrel.rotation.x = Math.PI / 2;
    smaBarrel.position.set(-1.7, 0.2, -1.75);
    mainboardGroup.add(smaBarrel);

    const pulsePaths = [
      [new THREE.Vector3(-0.9, 0.22, -0.2), new THREE.Vector3(0, 0.22, -0.2), new THREE.Vector3(0.6, 0.22, 0.2), new THREE.Vector3(1.2, 0.22, 0.6)],
      [new THREE.Vector3(-1.7, 0.22, -1.2), new THREE.Vector3(-0.9, 0.22, -1.0), new THREE.Vector3(-0.9, 0.22, -0.2)]
    ];
    const pulseMeshes = pulsePaths.map((path, idx) => {
      const mesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.07, 8, 8),
        new THREE.MeshBasicMaterial({ color: idx === 0 ? 0xd97706 : 0x09090b })
      );
      mainboardGroup.add(mesh);
      return { mesh, path, progress: idx * 0.5, speed: 0.5 };
    });

    // MODEL 2: RIGOL DSO (Clean White & Matte Black)
    const dsoGroup = new THREE.Group();
    masterGroup.add(dsoGroup);
    dsoGroup.visible = false;

    const dsoBodyMat = new THREE.MeshStandardMaterial({ color: 0xf4f1e8, roughness: 0.5, metalness: 0.1 });
    const dsoChassis = new THREE.Mesh(new THREE.BoxGeometry(4.4, 2.6, 2.0), dsoBodyMat);
    dsoChassis.position.y = 1.35;
    dsoGroup.add(dsoChassis);

    const dsoBezel = new THREE.Mesh(
      new THREE.BoxGeometry(4.2, 2.4, 0.15),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.4, metalness: 0.2 })
    );
    dsoBezel.position.set(0, 1.35, 1.05);
    dsoGroup.add(dsoBezel);

    const dsoScreenCanvas = document.createElement('canvas');
    dsoScreenCanvas.width = 512;
    dsoScreenCanvas.height = 280;
    const sScreenCtx = dsoScreenCanvas.getContext('2d');
    if (sScreenCtx) {
      sScreenCtx.fillStyle = '#0a0a0a';
      sScreenCtx.fillRect(0, 0, 512, 280);
      sScreenCtx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      sScreenCtx.lineWidth = 1;
      for (let x = 0; x <= 512; x += 32) {
        sScreenCtx.beginPath(); sScreenCtx.moveTo(x, 0); sScreenCtx.lineTo(x, 280); sScreenCtx.stroke();
      }
      for (let y = 0; y <= 280; y += 28) {
        sScreenCtx.beginPath(); sScreenCtx.moveTo(0, y); sScreenCtx.lineTo(512, y); sScreenCtx.stroke();
      }
      sScreenCtx.strokeStyle = '#facc15';
      sScreenCtx.lineWidth = 3;
      sScreenCtx.beginPath();
      for (let x = 0; x <= 512; x++) {
        const y = 140 - Math.sin(x * 0.04) * 60;
        if (x === 0) sScreenCtx.moveTo(x, y); else sScreenCtx.lineTo(x, y);
      }
      sScreenCtx.stroke();
      sScreenCtx.fillStyle = '#facc15';
      sScreenCtx.font = 'bold 16px monospace';
      sScreenCtx.fillText('RIGOL 100MHz · CH1 ACTIVE', 20, 30);
    }
    const dsoScreenTexture = new THREE.CanvasTexture(dsoScreenCanvas);
    const dsoScreen = new THREE.Mesh(
      new THREE.BoxGeometry(2.3, 1.4, 0.04),
      new THREE.MeshStandardMaterial({
        map: dsoScreenTexture,
        roughness: 0.1,
        emissive: 0xffffff,
        emissiveIntensity: 0.25
      })
    );
    dsoScreen.position.set(-0.7, 1.45, 1.14);
    dsoGroup.add(dsoScreen);

    const bncMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, metalness: 0.95, roughness: 0.15 });
    const bncRingColors = [0xfacc15, 0x2563eb, 0x7c3aed, 0x16a34a];
    [0.6, 0.95, 1.3, 1.65].forEach((bx, idx) => {
      const bncBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.28, 16), bncMat);
      bncBarrel.rotation.x = Math.PI / 2;
      bncBarrel.position.set(bx, 0.65, 1.15);
      dsoGroup.add(bncBarrel);
      const ring = new THREE.Mesh(
        new THREE.CylinderGeometry(0.13, 0.13, 0.06, 16),
        new THREE.MeshBasicMaterial({ color: bncRingColors[idx] })
      );
      ring.rotation.x = Math.PI / 2;
      ring.position.set(bx, 0.65, 1.08);
      dsoGroup.add(ring);
    });

    const knobMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.3, metalness: 0.4 });
    [[1.1, 1.6], [1.5, 1.6], [1.1, 1.1], [1.5, 1.1]].forEach(([kx, ky]) => {
      const knob = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.2, 16), knobMat);
      knob.rotation.x = Math.PI / 2;
      knob.position.set(kx, ky, 1.15);
      dsoGroup.add(knob);
    });

    const handleMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8, roughness: 0.3 });
    const handle = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.12, 0.2), handleMat);
    handle.position.set(0, 2.75, 0);
    dsoGroup.add(handle);

    // MODEL 3: PROCEDURAL ESP32 IOT NODE
    const iotGroup = new THREE.Group();
    masterGroup.add(iotGroup);
    iotGroup.visible = false;

    const bbBase = new THREE.Mesh(
      new THREE.BoxGeometry(4.2, 0.3, 2.6),
      new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8, metalness: 0.05 })
    );
    bbBase.position.y = 0.15;
    iotGroup.add(bbBase);

    const espIotBoard = new THREE.Mesh(
      new THREE.BoxGeometry(2.0, 0.1, 1.2),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.4, metalness: 0.2 })
    );
    espIotBoard.position.set(-0.8, 0.35, 0);
    iotGroup.add(espIotBoard);

    const espIotCan = new THREE.Mesh(
      new THREE.BoxGeometry(1.0, 0.15, 1.0),
      new THREE.MeshStandardMaterial({ color: 0xe4e4e7, metalness: 0.9, roughness: 0.2 })
    );
    espIotCan.position.set(-0.8, 0.45, 0);
    iotGroup.add(espIotCan);

    const oledMod = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 0.12, 1.2),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.5, metalness: 0.2 })
    );
    oledMod.position.set(0.6, 0.36, 0);
    iotGroup.add(oledMod);

    const oledGlass = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 0.02, 0.7),
      new THREE.MeshStandardMaterial({ color: 0x09090b, emissive: 0xffffff, emissiveIntensity: 0.3, roughness: 0.1 })
    );
    oledGlass.position.set(0.6, 0.43, 0);
    iotGroup.add(oledGlass);

    const dht = new THREE.Mesh(
      new THREE.BoxGeometry(0.8, 0.6, 0.5),
      new THREE.MeshStandardMaterial({ color: 0xf5f5f4, roughness: 0.7, metalness: 0.05 })
    );
    dht.position.set(1.4, 0.6, 0);
    iotGroup.add(dht);

    masterGroup.rotation.x = 0.45;
    masterGroup.rotation.y = -0.35;

    const handlePointerMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;
      mouseRef.current.targetX = (clientX / width) * 2 - 1;
      mouseRef.current.targetY = -(clientY / height) * 2 + 1;
    };

    const handlePointerLeave = () => {
      mouseRef.current.targetX = 0;
      mouseRef.current.targetY = 0;
    };

    container.addEventListener('mousemove', handlePointerMove);
    container.addEventListener('mouseleave', handlePointerLeave);

    const clock = new THREE.Clock();
    let isVisible = true;
    const observer = new IntersectionObserver(([entry]) => {
      isVisible = entry.isIntersecting;
    }, { threshold: 0.1 });
    observer.observe(container);

    const tempVec = new THREE.Vector3();

    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate);
      if (!isVisible) return;

      const delta = clock.getDelta();
      const elapsedTime = clock.getElapsedTime();

      const dampK = 6.0;
      const dampFactor = 1 - Math.exp(-dampK * delta);
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * dampFactor;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * dampFactor;

      mainboardGroup.visible = activeModelRef.current === 'mainboard';
      dsoGroup.visible = activeModelRef.current === 'oscilloscope';
      iotGroup.visible = activeModelRef.current === 'iot_node';

      scene.traverse(obj => {
        if ((obj as THREE.Mesh).isMesh && (obj as THREE.Mesh).material) {
          const mat = (obj as THREE.Mesh).material;
          if (Array.isArray(mat)) {
            mat.forEach(m => {
              if ('wireframe' in m) (m as THREE.MeshStandardMaterial).wireframe = isWireframeRef.current;
            });
          } else {
            if ('wireframe' in mat) (mat as THREE.MeshStandardMaterial).wireframe = isWireframeRef.current;
          }
        }
      });

      if (isRotatingRef.current) {
        masterGroup.position.y = Math.sin(elapsedTime * 1.2) * 0.08;
      }

      const scrollOffset = typeof window !== 'undefined' ? window.scrollY : 0;
      const scrollFactor = Math.min(scrollOffset / 800, 1);
      const baseRotX = 0.52 + scrollFactor * 0.15;
      const baseRotY = -0.32 - scrollFactor * 0.12;

      masterGroup.rotation.x = baseRotX + mouseRef.current.y * 0.28;
      masterGroup.rotation.y = baseRotY + mouseRef.current.x * 0.42;

      camera.position.y = 4.2 + scrollFactor * 0.35;

      pulseMeshes.forEach(item => {
        item.progress += delta * item.speed;
        if (item.progress > 1) item.progress = 0;
        const totalSegs = item.path.length - 1;
        const pVal = item.progress * totalSegs;
        const idx = Math.min(Math.floor(pVal), totalSegs - 1);
        item.mesh.position.lerpVectors(item.path[idx], item.path[idx + 1], pVal - idx);
      });

      ledPointLight.intensity = 2.2 + Math.sin(elapsedTime * 2.0) * 0.8;

      const targetHotspots = activeModelRef.current === 'mainboard' 
        ? MAINBOARD_HOTSPOTS 
        : activeModelRef.current === 'oscilloscope' 
        ? DSO_HOTSPOTS 
        : IOT_HOTSPOTS;

      const newPos: { [id: string]: { x: number; y: number; visible: boolean } } = {};
      targetHotspots.forEach(h => {
        tempVec.set(h.position3D[0], h.position3D[1], h.position3D[2]);
        tempVec.applyMatrix4(masterGroup.matrixWorld);
        tempVec.project(camera);

        const isBehind = tempVec.z > 1;
        const sx = ((tempVec.x + 1) * width) / 2;
        const sy = ((-tempVec.y + 1) * height) / 2;

        newPos[h.id] = {
          x: sx,
          y: sy,
          visible: !isBehind && sx >= 0 && sx <= width && sy >= 0 && sy <= height
        };
      });
      setHotspotPositions(newPos);

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      width = container.clientWidth;
      height = container.clientHeight || 560;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      observer.disconnect();
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousemove', handlePointerMove);
      container.removeEventListener('mouseleave', handlePointerLeave);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      try {
        renderer.dispose();
      } catch (e) {
        // Safe disposal
      }
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-[480px] sm:h-[540px] lg:h-[600px] rounded-3xl overflow-hidden bg-gradient-to-b from-[#111113] via-[#09090b] to-[#040405] border border-amber-500/30 shadow-2xl shadow-black/80 select-none group"
    >
      <div className="absolute inset-0 bg-tech-grid opacity-50 pointer-events-none" />

      {/* Top Floating Telemetry Header in Obsidian Black & Gold */}
      <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-between pointer-events-auto">
        <div className="flex items-center gap-2 bg-neutral-950/90 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-amber-500/30 text-xs shadow-md">
          <span className="flex h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
          <span className="font-mono text-amber-300 font-bold uppercase tracking-wider">
            {activeModel === 'mainboard' ? 'ENTC Core Lab PCB' : activeModel === 'oscilloscope' ? 'Rigol 100MHz DSO' : 'ESP32 Telemetry Node'}
          </span>
          <span className="text-amber-500/40 hidden sm:inline">|</span>
          <span className="text-neutral-400 text-[11px] hidden sm:inline">
            {webglSupported ? 'PBR Studio Twin' : 'Interactive 2.5D Twin'}
          </span>
        </div>

        {/* 3D Model Switcher Dock */}
        <div className="flex items-center gap-1 bg-neutral-950/90 backdrop-blur-md p-1 rounded-full border border-amber-500/30 text-xs shadow-md">
          <button
            onClick={() => { setActiveModel('mainboard'); setActiveHotspot(null); }}
            className={`px-3 py-1 rounded-full font-bold transition-all cursor-pointer ${
              activeModel === 'mainboard' ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black shadow-md shadow-amber-500/20' : 'text-neutral-400 hover:text-amber-300'
            }`}
          >
            PCB Core
          </button>
          <button
            onClick={() => { setActiveModel('oscilloscope'); setActiveHotspot(null); }}
            className={`px-3 py-1 rounded-full font-bold transition-all cursor-pointer ${
              activeModel === 'oscilloscope' ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black shadow-md shadow-amber-500/20' : 'text-neutral-400 hover:text-amber-300'
            }`}
          >
            100MHz DSO
          </button>
          <button
            onClick={() => { setActiveModel('iot_node'); setActiveHotspot(null); }}
            className={`px-3 py-1 rounded-full font-bold transition-all cursor-pointer ${
              activeModel === 'iot_node' ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black shadow-md shadow-amber-500/20' : 'text-neutral-400 hover:text-amber-300'
            }`}
          >
            IoT Node
          </button>
        </div>
      </div>

      {/* Render WebGL Canvas if supported, or Interactive 2.5D Twin if WebGL context is disabled */}
      {webglSupported ? (
        <>
          <canvas
            ref={canvasRef}
            className="w-full h-full block cursor-grab active:cursor-grabbing"
          />

          {/* Interactive 3D Hotspot Pins Projected on Screen */}
          {currentHotspots.map(h => {
            const pos = hotspotPositions[h.id];
            if (!pos || !pos.visible) return null;
            const isSelected = activeHotspot?.id === h.id;

            return (
              <div
                key={h.id}
                style={{
                  position: 'absolute',
                  left: `${pos.x}px`,
                  top: `${pos.y}px`,
                  transform: 'translate(-50%, -50%)',
                  zIndex: isSelected ? 30 : 25
                }}
                className="pointer-events-auto"
              >
                <button
                  onClick={() => setActiveHotspot(isSelected ? null : h)}
                  onMouseEnter={() => setActiveHotspot(h)}
                  className="relative flex items-center justify-center cursor-pointer group/pin"
                  aria-label={`Inspect ${h.name}`}
                >
                  <span 
                    className="absolute w-7 h-7 rounded-full opacity-50 animate-ping pointer-events-none"
                    style={{ backgroundColor: '#f59e0b' }}
                  />
                  <span 
                    className="w-4 h-4 rounded-full flex items-center justify-center border-2 border-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.6)] transition-transform group-hover/pin:scale-125"
                    style={{ backgroundColor: '#d97706' }}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-white" />
                  </span>
                  <span className={`absolute left-5 top-1/2 -translate-y-1/2 px-2 py-0.5 rounded-md bg-neutral-950/95 border border-amber-500/40 text-[10px] font-mono text-amber-300 whitespace-nowrap shadow-lg transition-opacity duration-200 ${
                    isSelected ? 'opacity-100' : 'opacity-0 group-hover/pin:opacity-100'
                  }`}>
                    {h.category}
                  </span>
                </button>
              </div>
            );
          })}
        </>
      ) : (
        /* High-Definition Interactive 2.5D Hardware Twin in Obsidian Black & Gold */
        <div className="w-full h-full relative flex items-center justify-center p-8 bg-gradient-to-b from-[#111113] via-[#09090b] to-[#040405]">
          <div className="relative w-full max-w-md aspect-[16/11] rounded-2xl bg-neutral-950 border border-amber-500/30 p-6 flex flex-col justify-between shadow-2xl overflow-hidden group/board">
            
            <div className="absolute inset-0 bg-tech-grid opacity-40 pointer-events-none" />

            {activeModel === 'mainboard' && (
              <div className="relative z-10 space-y-4">
                <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
                  <span className="text-xs font-mono font-bold text-amber-300">PCB REV 4.2 · ESP32 + FPGA + LORA</span>
                  <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">ONLINE</span>
                </div>
                
                <div className="grid grid-cols-3 gap-3 py-4 text-center">
                  <div className="p-3 rounded-xl bg-neutral-900/80 border border-amber-500/20">
                    <Cpu className="w-6 h-6 text-amber-400 mx-auto mb-1 animate-pulse" />
                    <span className="text-[11px] font-bold text-white block">ESP32-WROOM</span>
                    <span className="text-[9px] text-neutral-400 font-mono">240MHz · BLE</span>
                  </div>

                  <div className="p-3 rounded-xl bg-neutral-900/80 border border-amber-500/20">
                    <Activity className="w-6 h-6 text-yellow-400 mx-auto mb-1" />
                    <span className="text-[11px] font-bold text-white block">UltraVision</span>
                    <span className="text-[9px] text-neutral-400 font-mono">1GSa/s Sampling</span>
                  </div>

                  <div className="p-3 rounded-xl bg-neutral-900/80 border border-amber-500/20">
                    <Radio className="w-6 h-6 text-amber-500 mx-auto mb-1" />
                    <span className="text-[11px] font-bold text-white block">SX1276 LoRa</span>
                    <span className="text-[9px] text-neutral-400 font-mono">868MHz Mesh</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400 border-t border-amber-500/20 pt-2">
                  <span>Gold Edge Fingers: 34 GPIOs</span>
                  <span className="text-amber-400 font-semibold">Tap pins to inspect</span>
                </div>
              </div>
            )}

            {activeModel === 'oscilloscope' && (
              <div className="relative z-10 space-y-4">
                <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
                  <span className="text-xs font-mono font-bold text-amber-300">RIGOL DS1054Z · 100MHz 4CH</span>
                  <span className="text-[10px] font-mono font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">CALIBRATED</span>
                </div>

                <div className="p-3 rounded-xl bg-black border border-amber-500/30 text-white space-y-1">
                  <div className="h-16 w-full rounded bg-neutral-950 flex items-center justify-center font-mono text-xs text-amber-400 relative overflow-hidden">
                    <span className="text-amber-300 font-bold animate-pulse">~ ~ ~ 100MHz Dual Waveform Active ~ ~ ~</span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] font-mono text-neutral-400 pt-1">
                    <span>CH1: 1.00V / 1kHz</span>
                    <span>CH2: 500mV Pulse</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400">
                  <span>4x BNC Inputs Isolated</span>
                  <span className="text-amber-400 font-semibold">CAT I 300Vrms</span>
                </div>
              </div>
            )}

            {activeModel === 'iot_node' && (
              <div className="relative z-10 space-y-4">
                <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
                  <span className="text-xs font-mono font-bold text-amber-300">ESP32 TELEMETRY SENSOR NODE</span>
                  <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">BROADCASTING</span>
                </div>

                <div className="p-3 rounded-xl bg-neutral-900/80 border border-amber-500/20 flex items-center justify-between gap-4">
                  <div className="p-2.5 rounded-lg bg-black border border-amber-500/20 text-white font-mono text-xs">
                    <p className="text-[10px] text-amber-400">0.96" I2C OLED</p>
                    <p className="font-bold text-white">TEMP: 26.4°C</p>
                    <p className="font-bold text-amber-300">HUMID: 58%</p>
                  </div>
                  <div className="text-left space-y-1 text-xs">
                    <p className="text-white font-bold">DHT22 Digital Probe</p>
                    <p className="text-[10px] text-neutral-400 font-mono">1-Wire Bus · GPIO 4</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400 border-t border-amber-500/20 pt-2">
                  <span>Low Quiescent Sleep: 15μA</span>
                  <span className="text-amber-400 font-semibold">Battery Ready</span>
                </div>
              </div>
            )}

            {currentHotspots.map(h => {
              const isSelected = activeHotspot?.id === h.id;
              return (
                <div
                  key={h.id}
                  style={{
                    position: 'absolute',
                    left: h.fallbackPosition.left,
                    top: h.fallbackPosition.top,
                    transform: 'translate(-50%, -50%)',
                    zIndex: isSelected ? 30 : 25
                  }}
                >
                  <button
                    onClick={() => setActiveHotspot(isSelected ? null : h)}
                    onMouseEnter={() => setActiveHotspot(h)}
                    className="relative flex items-center justify-center cursor-pointer group/pin"
                    aria-label={`Inspect ${h.name}`}
                  >
                    <span 
                      className="absolute w-7 h-7 rounded-full opacity-50 animate-ping pointer-events-none"
                      style={{ backgroundColor: '#f59e0b' }}
                    />
                    <span 
                      className="w-4 h-4 rounded-full flex items-center justify-center border-2 border-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.6)] transition-transform group-hover/pin:scale-125"
                      style={{ backgroundColor: '#d97706' }}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-white" />
                    </span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Bottom Collapsible Control Dock in Golden & Black */}
      <div className="absolute bottom-4 left-4 z-20 flex items-center gap-2 bg-neutral-950/90 backdrop-blur-md px-3 py-1.5 rounded-2xl border border-amber-500/30 shadow-md pointer-events-auto text-xs text-neutral-300">
        {webglSupported ? (
          <>
            <button
              onClick={() => setIsRotating(!isRotating)}
              className="flex items-center gap-1.5 text-neutral-300 hover:text-amber-300 transition-colors cursor-pointer"
              title={isRotating ? 'Pause Rotation' : 'Resume Rotation'}
            >
              {isRotating ? <Pause className="w-3.5 h-3.5 text-amber-400" /> : <Play className="w-3.5 h-3.5 text-emerald-400" />}
              <span className="font-mono text-[11px] hidden sm:inline">{isRotating ? 'Pause' : 'Play'}</span>
            </button>

            <span className="text-amber-500/30">|</span>

            <button
              onClick={() => setIsWireframe(!isWireframe)}
              className={`flex items-center gap-1.5 transition-colors cursor-pointer font-mono text-[11px] ${
                isWireframe ? 'text-amber-400 font-bold' : 'text-neutral-400 hover:text-amber-300'
              }`}
              title="Toggle Wireframe CAD Mode"
            >
              <Box className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Wireframe</span>
            </button>

            <span className="text-amber-500/30">|</span>

            <span className="font-mono text-[10px] text-neutral-400">
              Scroll tracks 3D perspective
            </span>
          </>
        ) : (
          <div className="flex items-center gap-1.5 font-mono text-[11px] text-amber-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
            <span>Interactive Hardware Twin Active</span>
          </div>
        )}
      </div>

      {/* Active Hotspot Technical Inspection Drawer in Golden & Black */}
      {activeHotspot && (
        <div className="absolute bottom-4 right-4 w-80 sm:w-96 z-30 p-4 rounded-2xl bg-neutral-950/95 backdrop-blur-md border border-amber-500/40 shadow-2xl shadow-black/80 animate-in fade-in slide-in-from-bottom-2 duration-300 text-left">
          <div className="flex items-start justify-between gap-2 border-b border-amber-500/20 pb-2">
            <div className="space-y-0.5">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                {activeHotspot.category}
              </span>
              <h4 className="text-sm font-bold text-white">{activeHotspot.name}</h4>
            </div>
            <button
              onClick={() => setActiveHotspot(null)}
              className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              ✕
            </button>
          </div>

          <p className="text-xs text-neutral-300 mt-2 leading-relaxed">
            {activeHotspot.description}
          </p>

          <div className="mt-2.5 p-2 rounded-xl bg-neutral-900 border border-amber-500/20 text-[11px] font-mono text-amber-300 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">{activeHotspot.specs}</span>
          </div>

          <div className="mt-3">
            <button
              onClick={() => handleHotspotAction(activeHotspot)}
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:brightness-110 text-black text-xs font-extrabold transition-all flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer"
            >
              <span>{activeHotspot.relatedActionLabel}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
