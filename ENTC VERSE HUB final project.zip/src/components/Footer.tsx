import React from 'react';
import { Cpu, ShieldCheck, Phone, Mail, Building, Clock } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="w-full bg-[#060608] border-t border-amber-500/20 text-neutral-400 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 text-left">
          {/* Brand & Purpose */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center text-black shadow-md shadow-amber-500/20">
                <Cpu className="w-4 h-4 text-black" />
              </div>
              <span className="text-base font-bold text-white tracking-tight">
                ENTCverse<span className="text-amber-400 ml-1">Hub</span>
              </span>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed max-w-sm">
              The hybrid electronics learning and equipment rental platform. Bridging the gap between theory and hands-on laboratory practice with affordable short-term bench equipment rentals and interactive online lab simulations.
            </p>
            <div className="text-xs text-neutral-400 space-y-1">
              <p>Tagline: <span className="text-amber-300 font-bold">Learn. Rent. Build. Innovate.</span></p>
              <p className="text-neutral-500">Physical Showroom & Dispatch Center: Pune Tech Hub, Maharashtra</p>
            </div>
          </div>

          {/* Platform Navigation */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider font-mono">Platform</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setActiveTab('catalogue')} className="hover:text-amber-300 transition-colors text-left cursor-pointer">
                  Equipment Catalogue
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('rentals')} className="hover:text-amber-300 transition-colors text-left cursor-pointer">
                  Rental Calculator
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('virtual-lab')} className="hover:text-amber-300 transition-colors text-left cursor-pointer">
                  Virtual Circuit Simulator
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('learn')} className="hover:text-amber-300 transition-colors text-left cursor-pointer">
                  Learning Academy & Pinouts
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('projects')} className="hover:text-amber-300 transition-colors text-left cursor-pointer">
                  Student Project Showcase
                </button>
              </li>
            </ul>
          </div>

          {/* Showroom & Business */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider font-mono">Physical Hubs</h4>
            <ul className="space-y-2 text-xs">
              <li className="flex items-start gap-2">
                <Building className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>Pune Showroom (Main): JM Road, Shivaji Nagar</span>
              </li>
              <li className="flex items-start gap-2">
                <Building className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>Bengaluru Hub: Koramangala 4th Block</span>
              </li>
              <li className="flex items-start gap-2">
                <Clock className="w-3.5 h-3.5 text-amber-500/70 shrink-0 mt-0.5" />
                <span>Counter Hours: 09:00 - 20:00 Daily</span>
              </li>
              <li>
                <button onClick={() => setActiveTab('business')} className="text-amber-400 font-bold hover:underline transition-colors text-left cursor-pointer">
                  List Your Idle Lab Equipment →
                </button>
              </li>
            </ul>
          </div>

          {/* Safety & Compliance */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider font-mono">Lab Trust & Support</h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-1.5 text-neutral-200 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>100% Calibrated Gear</span>
              </div>
              <p className="text-neutral-400">Every rented oscilloscope & meter passes bench verification before handover.</p>
              <div className="pt-2 text-neutral-400 space-y-1">
                <div className="flex items-center gap-1.5">
                  <Phone className="w-3 h-3 text-amber-400" />
                  <span>+91 20 2550 4900 (Lab Helpline)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Mail className="w-3 h-3 text-amber-400" />
                  <span>lab@entcverse.org</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-amber-500/20 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 gap-4">
          <p>© 2026 ENTCverse Hub. All rights reserved. Subsidized hardware access for engineering students.</p>
          <div className="flex items-center gap-4">
            <button onClick={() => setActiveTab('home')} className="hover:text-amber-300 transition-colors cursor-pointer">Home</button>
            <span>·</span>
            <button onClick={() => setActiveTab('business-model')} className="hover:text-amber-300 transition-colors cursor-pointer">Business Model</button>
            <span>·</span>
            <button onClick={() => setActiveTab('catalogue')} className="hover:text-amber-300 transition-colors cursor-pointer">Catalogue</button>
          </div>
        </div>
      </div>
    </footer>
  );
};
