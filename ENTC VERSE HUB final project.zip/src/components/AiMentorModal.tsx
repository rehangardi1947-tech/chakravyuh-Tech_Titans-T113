import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  X, 
  Sparkles, 
  Lightbulb, 
  AlertCircle, 
  Code, 
  HelpCircle, 
  Zap,
  ArrowRight,
  RotateCcw
} from 'lucide-react';
import { MentorMessage } from '../types';
import { storageService } from '../services/storageService';

interface AiMentorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: string) => void;
  onOpenEquipmentDetail?: (equipmentId: string) => void;
}

const PRESET_PROMPTS = [
  {
    icon: Lightbulb,
    label: "Why does my LED burn out without a resistor?",
    query: "Can you explain in simple beginner terms why an LED burns out if connected directly to a 5V or 9V battery without a resistor?"
  },
  {
    icon: AlertCircle,
    label: "Common breadboard wiring mistakes",
    query: "What are the top 5 mistakes beginner ENTC students make when wiring circuits on a breadboard?"
  },
  {
    icon: Code,
    label: "Explain ESP32 PWM code",
    query: "How does pulse width modulation (PWM) work on an ESP32 to dim an LED, and what are ledcSetup and ledcAttachPin?"
  },
  {
    icon: HelpCircle,
    label: "What gear do I need for a LoRa project?",
    query: "I want to build a long-range wireless sensor node. What lab equipment should I rent to test and calibrate it?"
  }
];

export const AiMentorModal: React.FC<AiMentorModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab,
  onOpenEquipmentDetail
}) => {
  const [messages, setMessages] = useState<MentorMessage[]>([
    {
      id: 'm-welcome',
      role: 'assistant',
      content: "Hello! I'm Dr. Silicon, your ENTCverse AI Lab Mentor. I'm here to explain tricky electronics concepts, troubleshoot breadboard wiring mistakes, explain microcontroller code, or suggest which lab instruments to rent for your capstone project. What circuit are you working on today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      setTimeout(scrollToBottom, 100);
    }
  }, [isOpen, messages]);

  if (!isOpen) return null;

  const generateOfflineResponse = (query: string): { reply: string; action?: { label: string; actionType: 'open_experiment' | 'open_lesson' | 'open_equipment'; targetId: string } } => {
    const q = query.toLowerCase();

    if (q.includes('led') && (q.includes('resistor') || q.includes('burn') || q.includes('fry') || q.includes('ohm'))) {
      return {
        reply: "Great question! Standard LEDs are semiconductor diodes, not linear resistors. Once voltage passes the diode's forward threshold (typically ~2.0V for Red, ~3.2V for Blue), its internal resistance drops exponentially to near zero. \n\nWithout a current-limiting resistor, the current surges uncontrollably until the microscopic gold wire or silicon junction overheats and vaporizes (thermal runaway) in milliseconds!\n\nTo calculate the safe resistor:\n• R = (Supply Voltage - LED Forward Voltage) / Desired Current\n• For 5V supply, 2V red LED, and 10mA (0.01A):\n• R = (5.0V - 2.0V) / 0.010A = 300Ω (standard 330Ω works perfectly).",
        action: {
          label: "Open LED Current Limiter Simulation",
          actionType: 'open_experiment',
          targetId: 'exp-led-resistor'
        }
      };
    }

    if (q.includes('breadboard') || q.includes('mistake') || q.includes('troubleshoot') || q.includes('short')) {
      return {
        reply: "Here are the top 5 mistakes that trip up ENTC students in the lab:\n\n1. Floating Microcontroller Inputs: Leaving a button pin unconnected without an internal or external pull-up/down resistor. Ambient electromagnetic fields will cause random ghost triggers!\n2. Connecting Multimeter in Ammeter Mode Across Power: Ammeters have near-zero resistance. Probing power rails in current mode shorts the supply and blows the meter fuse instantly.\n3. Confusing Breadboard Power Rails: The long red (+) and blue (-) lines along the edges are often split into two isolated halves at the center column on standard 830-point boards.\n4. Reversing Polarized Components: Electrolytic capacitors and diodes have strict polarity. Reversing an electrolytic capacitor can cause it to pop under reverse DC voltage.\n5. Omitting Flyback Diodes on Motors/Relays: Inductive coils generate massive negative voltage spikes (>100V) when turned off, instantly puncturing delicate microcontroller transistors.",
        action: {
          label: "View Lesson: Electronic Components & Symbols",
          actionType: 'open_lesson',
          targetId: 'lesson-circuit-symbols'
        }
      };
    }

    if (q.includes('pwm') || q.includes('esp32') || q.includes('arduino') || q.includes('code') || q.includes('dim')) {
      return {
        reply: "Microcontrollers cannot output pure variable analog voltages directly (unless they feature a built-in DAC). Instead, they use Pulse Width Modulation (PWM):\n\nInstead of varying the voltage height, PWM pulses a constant 3.3V digital signal ON and OFF rapidly (e.g. 5,000 times a second). The human eye or motor smooths this out into perceived average power:\n\n• V_perceived = 3.3V × (Duty Cycle % / 100)\n• 25% Duty Cycle = ~0.82V equivalent\n• 50% Duty Cycle = ~1.65V equivalent\n\nOn ESP32 Arduino framework:\n```cpp\n// 1. Configure channel 0, 5kHz frequency, 8-bit resolution (0-255)\nledcSetup(0, 5000, 8);\n// 2. Attach channel to GPIO pin 18\nledcAttachPin(18, 0);\n// 3. Set brightness to 50% (128 / 255)\nledcWrite(0, 128);\n```",
        action: {
          label: "Open Virtual Lab: Microcontroller I/O & PWM",
          actionType: 'open_experiment',
          targetId: 'exp-mcu-io'
        }
      };
    }

    if (q.includes('lora') || q.includes('wireless') || q.includes('equipment') || q.includes('rent') || q.includes('gear')) {
      return {
        reply: "For building and testing a reliable sub-GHz LoRa telemetry node (e.g. SX1276 at 868MHz):\n\n1. Digital Storage Oscilloscope (e.g. Rigol DS1054Z 100MHz): Inspect the high-speed SPI clock (MOSI, MISO, SCK) and verify that chip select (NSS) timing aligns cleanly without digital overshoot.\n2. RF Spectrum Analyzer / Power Meter: Measure actual radiated transmission power (dBm) and verify that spurious harmonic emissions at 1.73GHz and 2.6GHz are well suppressed.\n3. Bench Regulated DC Power Supply: LoRa modules draw 120mA during TX bursts. Bench supplies let you verify that the 3.3V LDO regulator does not suffer transient voltage sag.\n\nYou can rent all three from the ENTCverse showroom at student rates with instant pickup in Pune or Bengaluru!",
        action: {
          label: "View Rigol DS1054Z DSO Rental Specs",
          actionType: 'open_equipment',
          targetId: 'eq-dso-1054'
        }
      };
    }

    if (q.includes('quiz') || q.includes('question') || q.includes('test me')) {
      return {
        reply: "Here is a quick pop-quiz to test your intuition:\n\n**Question:** You have a 12V DC power source connected to a voltage divider consisting of R1 = 10kΩ and R2 = 20kΩ. What is the unloaded output voltage measured across R2?\n\n• Formula: V_out = V_in × (R2 / (R1 + R2))\n• Answer: V_out = 12V × (20kΩ / 30kΩ) = **8.0 Volts**!\n\nWould you like to test this live with different resistances in our interactive circuit lab?",
        action: {
          label: "Open Voltage Divider Lab",
          actionType: 'open_experiment',
          targetId: 'exp-voltage-divider'
        }
      };
    }

    // Default intelligent guidance
    return {
      reply: `Regarding "${query}":\n\nIn ENTC systems, always begin by separating DC biasing conditions from dynamic AC signals. Verify that your ground planes are solid and common across all modules. If you're encountering intermittent resets or erratic readings, check for missing 100nF decoupling capacitors near the power pins of your chips.\n\nWould you like to walk through a specific schematic, test this in the Virtual Lab, or find the right test equipment from our showroom inventory?`,
      action: {
        label: "Open ENTC Academy Lessons",
        actionType: 'open_lesson',
        targetId: 'lesson-basic-electricity'
      }
    };
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;

    const userMsg: MentorMessage = {
      id: `m-usr-${Date.now()}`,
      role: 'user',
      content: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    // Simulate smart thinking and award XP for learning exploration
    setTimeout(() => {
      const generated = generateOfflineResponse(text);
      const assistantMsg: MentorMessage = {
        id: `m-ast-${Date.now()}`,
        role: 'assistant',
        content: generated.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedAction: generated.action
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setIsTyping(false);
      storageService.awardXP(15, 'Consulted Dr. Silicon AI Mentor');
    }, 700);
  };

  const handleActionClick = (action: NonNullable<MentorMessage['suggestedAction']>) => {
    onClose();
    if (action.actionType === 'open_experiment') {
      onNavigateTab('virtual-lab');
    } else if (action.actionType === 'open_lesson') {
      onNavigateTab('learn');
    } else if (action.actionType === 'open_equipment') {
      if (onOpenEquipmentDetail) {
        onOpenEquipmentDetail(action.targetId);
      } else {
        onNavigateTab('catalogue');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col h-[85vh] max-h-[700px] overflow-hidden text-left">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-bold text-white tracking-tight">
                  Dr. Silicon · ENTC AI Lab Mentor
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                  Hardware Specialist
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Circuit theory, troubleshooting, firmware debugging & showroom gear advice
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 font-sans text-xs sm:text-sm">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.role === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-4 ${
                  msg.role === 'user'
                    ? 'bg-cyan-600 text-white rounded-tr-sm shadow-sm'
                    : 'bg-slate-800/90 text-slate-200 border border-slate-700 rounded-tl-sm shadow-sm'
                }`}
              >
                <div className="whitespace-pre-line leading-relaxed">
                  {msg.content}
                </div>

                {msg.suggestedAction && (
                  <div className="mt-3 pt-3 border-t border-slate-700/80">
                    <button
                      onClick={() => handleActionClick(msg.suggestedAction!)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-semibold transition-colors cursor-pointer"
                    >
                      <span>{msg.suggestedAction.label}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
              <span className="text-[10px] text-slate-300 mt-1 px-1 font-mono">
                {msg.timestamp}
              </span>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-2 text-xs text-cyan-400 p-2">
              <Sparkles className="w-4 h-4 animate-spin text-cyan-400" />
              <span>Dr. Silicon is analyzing circuit parameters...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Preset Suggestions */}
        <div className="px-4 py-2 bg-slate-950/60 border-t border-slate-800/80 overflow-x-auto flex items-center gap-2 no-scrollbar">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-cyan-400" />
            Quick Prompts:
          </span>
          {PRESET_PROMPTS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(p.query)}
              className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-750 text-[11px] text-slate-300 hover:text-cyan-300 border border-slate-700 hover:border-cyan-500/40 whitespace-nowrap transition-colors cursor-pointer shrink-0"
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-slate-950 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask Dr. Silicon about Ohm's law, oscilloscope probes, Arduino code..."
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || isTyping}
              className="px-4 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 disabled:cursor-not-allowed text-slate-950 font-bold rounded-xl flex items-center justify-center transition-colors cursor-pointer shrink-0"
              aria-label="Send"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          <div className="mt-2 text-center text-[11px] text-slate-400">
            ENTCverse AI Mentor runs real-time hardware physics calculations and offline engineering heuristics.
          </div>
        </div>
      </div>
    </div>
  );
};
