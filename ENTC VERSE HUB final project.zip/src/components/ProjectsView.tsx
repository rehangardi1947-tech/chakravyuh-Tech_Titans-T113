import React, { useState } from 'react';
import { 
  FolderGit2, 
  Heart, 
  ExternalLink, 
  FileCode, 
  Cpu, 
  Plus, 
  X, 
  CheckCircle,
  Building,
  Sparkles,
  BookOpen,
  Bookmark,
  CheckCircle2,
  Clock,
  Layers,
  Wrench,
  Trash2
} from 'lucide-react';
import { STUDENT_PROJECTS } from '../data/projectsData';
import { StudentProject, PortfolioProjectItem, EquipmentItem } from '../types';
import { storageService } from '../services/storageService';

interface ProjectsViewProps {
  onRentEquipment?: (item: EquipmentItem) => void;
  onViewEquipmentDetail?: (item: EquipmentItem) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  onRentEquipment,
  onViewEquipmentDetail
}) => {
  const [activeTab, setActiveTab] = useState<'featured' | 'my_portfolio'>('featured');
  const [projects, setProjects] = useState<StudentProject[]>(STUDENT_PROJECTS);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [inspectedProject, setInspectedProject] = useState<StudentProject | null>(null);

  // Student Portfolio State
  const [portfolio, setPortfolio] = useState<PortfolioProjectItem[]>(() => storageService.getPortfolioProjects());
  const [savedBannerMsg, setSavedBannerMsg] = useState<string | null>(null);

  // New project submission form
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newAuthor, setNewAuthor] = useState('');
  const [newCollege, setNewCollege] = useState('');
  const [newCategory, setNewCategory] = useState<'IoT' | 'Telecommunication' | 'Embedded Systems' | 'DSP' | 'Robotics'>('IoT');
  const [newSummary, setNewSummary] = useState('');
  const [newComponents, setNewComponents] = useState('ESP32, DHT22, Solderless Breadboard');
  const [submittedSuccessfully, setSubmittedSuccessfully] = useState(false);

  const categories = ['All', 'Telecommunication', 'Robotics', 'IoT', 'DSP', 'Embedded Systems'];

  const filteredProjects = projects.filter((p) => {
    if (selectedCategory === 'All') return true;
    return p.category === selectedCategory;
  });

  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setProjects(projects.map((p) => p.id === id ? { ...p, likes: p.likes + 1 } : p));
  };

  const handleSaveToPortfolio = (proj: StudentProject) => {
    const exists = portfolio.some(p => p.templateId === proj.id || p.title === proj.title);
    if (exists) {
      setSavedBannerMsg(`"${proj.title}" is already in your portfolio!`);
      setTimeout(() => setSavedBannerMsg(null), 3000);
      return;
    }

    const newItem: PortfolioProjectItem = {
      id: `port-${Date.now()}`,
      templateId: proj.id,
      title: proj.title,
      status: 'Planned',
      progressPercent: 0,
      notes: `Started from community project by ${proj.author} (${proj.college}).`,
      components: proj.componentsUsed,
      rentedEquipmentIds: proj.suggestedEquipmentIds || []
    };

    storageService.savePortfolioProject(newItem);
    setPortfolio(storageService.getPortfolioProjects());
    setSavedBannerMsg(`Saved "${proj.title}" to your Project Portfolio! (+50 XP)`);
    setTimeout(() => setSavedBannerMsg(null), 3500);
  };

  const handleUpdateStatus = (id: string, status: 'Planned' | 'In Progress' | 'Completed') => {
    const proj = portfolio.find(p => p.id === id);
    if (!proj) return;
    const progress = status === 'Completed' ? 100 : status === 'In Progress' ? Math.max(25, proj.progressPercent) : 0;
    storageService.updatePortfolioProjectStatus(id, status, progress);
    setPortfolio(storageService.getPortfolioProjects());
  };

  const handleUpdateProgress = (id: string, progress: number) => {
    const status = progress === 100 ? 'Completed' : progress > 0 ? 'In Progress' : 'Planned';
    storageService.updatePortfolioProjectStatus(id, status, progress);
    setPortfolio(storageService.getPortfolioProjects());
  };

  const handleDeletePortfolioItem = (id: string) => {
    storageService.deletePortfolioProject(id);
    setPortfolio(storageService.getPortfolioProjects());
  };

  const handleSubmitProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newAuthor || !newCollege) return;

    const newProj: StudentProject = {
      id: `proj-${Date.now()}`,
      title: newTitle,
      author: newAuthor,
      college: newCollege,
      category: newCategory,
      summary: newSummary || 'Innovative hardware project built with rented showroom lab gear.',
      description: newSummary || 'Full student engineering capstone documentation.',
      componentsUsed: newComponents.split(',').map((c) => c.trim()),
      schematicSummary: 'Hardware schematic verified with ENTCverse equipment.',
      githubUrl: 'https://github.com/entcverse-student-showcase/community-project',
      likes: 1
    };

    setProjects([newProj, ...projects]);
    setSubmittedSuccessfully(true);
    setTimeout(() => {
      setSubmittedSuccessfully(false);
      setShowSubmitModal(false);
      setNewTitle('');
      setNewAuthor('');
      setNewCollege('');
      setNewSummary('');
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-left">
      {/* Title & Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono mb-1">
            <FolderGit2 className="w-4 h-4" />
            <span>STUDENT HARDWARE INNOVATION SHOWCASE & PORTFOLIO</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Build & Track Practical ENTC Projects
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
            Explore 10 curated hardware capstone projects, follow step-by-step implementation guides, save them to your personal portfolio, and rent the exact laboratory instruments required.
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start md:self-auto">
          <button
            onClick={() => setShowSubmitModal(true)}
            className="px-4 py-2.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm shadow-cyan-400/20"
          >
            <Plus className="w-4 h-4" />
            <span>Submit Your Project</span>
          </button>
        </div>
      </div>

      {/* Notification Toast */}
      {savedBannerMsg && (
        <div className="p-3 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{savedBannerMsg}</span>
        </div>
      )}

      {/* View Switcher: Featured Showcase vs My Portfolio */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('featured')}
            className={`py-2 px-4 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'featured'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FolderGit2 className="w-4 h-4" />
            <span>Curated Projects ({projects.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('my_portfolio')}
            className={`py-2 px-4 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'my_portfolio'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>My Lab Portfolio ({portfolio.length})</span>
          </button>
        </div>

        {activeTab === 'featured' && (
          <div className="hidden sm:flex items-center gap-1">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 text-xs rounded-lg transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-slate-800 text-white font-bold border border-slate-700'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* TAB 1: FEATURED PROJECTS */}
      {activeTab === 'featured' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              onClick={() => setInspectedProject(project)}
              className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-2xl p-6 transition-all cursor-pointer flex flex-col justify-between hover:shadow-lg hover:shadow-cyan-500/5 group"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-400">
                    {project.category}
                  </span>
                  <div className="flex items-center gap-2">
                    {project.difficulty && (
                      <span className="text-[10px] font-mono text-slate-300">
                        {project.difficulty}
                      </span>
                    )}
                    <button
                      onClick={(e) => handleLike(project.id, e)}
                      className="flex items-center gap-1 text-xs text-slate-400 hover:text-rose-400 transition-colors"
                    >
                      <Heart className="w-3.5 h-3.5" />
                      <span>{project.likes}</span>
                    </button>
                  </div>
                </div>

                <div>
                  <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-1">
                    {project.title}
                  </h3>
                  <div className="flex items-center gap-1.5 text-xs text-slate-300 mt-1">
                    <Building className="w-3 h-3 text-slate-300" />
                    <span className="line-clamp-1">{project.college}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 line-clamp-3 leading-relaxed">
                  {project.summary}
                </p>

                {/* Components Badges */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-mono text-slate-300 uppercase block">Components:</span>
                  <div className="flex flex-wrap gap-1">
                    {project.componentsUsed.slice(0, 3).map((comp, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300"
                      >
                        {comp}
                      </span>
                    ))}
                    {project.componentsUsed.length > 3 && (
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-950 text-slate-300">
                        +{project.componentsUsed.length - 3} more
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="pt-4 border-t border-slate-800/80 mt-5 flex items-center justify-between text-xs">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleSaveToPortfolio(project);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Bookmark className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Save to Portfolio</span>
                </button>

                <span className="text-cyan-400 font-semibold group-hover:underline flex items-center gap-1">
                  <span>View Details</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 2: MY PORTFOLIO */}
      {activeTab === 'my_portfolio' && (
        <div className="space-y-6">
          {portfolio.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-slate-900/50 border border-slate-800 space-y-3">
              <FolderGit2 className="w-10 h-10 text-slate-400 mx-auto" />
              <h3 className="text-base font-bold text-white">Your Project Portfolio is Empty</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Save projects from the Curated Projects tab to track your progress, build notes, and see which lab instruments you need to rent.
              </p>
              <button
                onClick={() => setActiveTab('featured')}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs cursor-pointer"
              >
                Browse Featured Projects
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {portfolio.map((item) => (
                <div
                  key={item.id}
                  className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-bold text-white">{item.title}</h3>
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                          item.status === 'Completed'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : item.status === 'In Progress'
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                            : 'bg-slate-800 text-slate-400'
                        }`}>
                          {item.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{item.notes}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <select
                        value={item.status}
                        onChange={(e) => handleUpdateStatus(item.id, e.target.value as any)}
                        className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white"
                      >
                        <option value="Planned">Planned</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                      </select>

                      <button
                        onClick={() => handleDeletePortfolioItem(item.id)}
                        className="p-2 text-slate-400 hover:text-red-400 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Progress Slider */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs text-slate-400 font-mono">
                      <span>Implementation Progress:</span>
                      <span className="text-cyan-400 font-bold">{item.progressPercent}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={item.progressPercent}
                      onChange={(e) => handleUpdateProgress(item.id, parseInt(e.target.value))}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                  </div>

                  {/* Components */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {item.components.map((c, idx) => (
                      <span key={idx} className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-800">
                        {c}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Inspected Project Modal */}
      {inspectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl max-h-[85vh] overflow-y-auto p-6 sm:p-8 space-y-6 text-left">
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                  {inspectedProject.category} · {inspectedProject.difficulty}
                </span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-white mt-1">
                  {inspectedProject.title}
                </h2>
                <div className="text-xs text-slate-400 mt-1">
                  Built by {inspectedProject.author} · {inspectedProject.college}
                </div>
              </div>

              <button
                onClick={() => setInspectedProject(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs text-slate-300">
              <div>
                <span className="font-bold text-white block mb-1">Project Description:</span>
                <p className="leading-relaxed text-slate-200">{inspectedProject.description}</p>
              </div>

              {inspectedProject.learningOutcomes && (
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="font-bold text-white block">Key Learning Outcomes:</span>
                  <ul className="space-y-1">
                    {inspectedProject.learningOutcomes.map((out, idx) => (
                      <li key={idx} className="text-slate-300">• {out}</li>
                    ))}
                  </ul>
                </div>
              )}

              {inspectedProject.implementationSteps && (
                <div className="space-y-2">
                  <span className="font-bold text-white block">Step-by-Step Implementation:</span>
                  <ol className="list-decimal list-inside space-y-1.5 text-slate-300 pl-1">
                    {inspectedProject.implementationSteps.map((step, idx) => (
                      <li key={idx} className="leading-relaxed">{step}</li>
                    ))}
                  </ol>
                </div>
              )}

              {inspectedProject.testingGuidance && (
                <div className="p-3.5 rounded-xl bg-cyan-950/20 border border-cyan-500/30 text-cyan-200">
                  <span className="font-bold text-cyan-300 block mb-0.5">Laboratory Testing Guidance:</span>
                  <span>{inspectedProject.testingGuidance}</span>
                </div>
              )}

              <div>
                <span className="font-bold text-white block mb-1">Bill of Materials (BOM):</span>
                <div className="flex flex-wrap gap-1.5">
                  {inspectedProject.componentsUsed.map((comp, idx) => (
                    <span key={idx} className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono text-[11px]">
                      {comp}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <button
                onClick={() => {
                  handleSaveToPortfolio(inspectedProject);
                  setInspectedProject(null);
                }}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Bookmark className="w-4 h-4" />
                <span>Save to My Portfolio</span>
              </button>

              <a
                href={inspectedProject.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1.5 transition-colors"
              >
                <FileCode className="w-4 h-4" />
                <span>View Schematic & Code Repo</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Submit Project Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl p-6 space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Submit Your Student Project</h3>
              <button onClick={() => setShowSubmitModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {submittedSuccessfully ? (
              <div className="py-8 text-center text-emerald-400 space-y-2">
                <CheckCircle2 className="w-10 h-10 mx-auto" />
                <h4 className="font-bold">Project Submitted for Review!</h4>
                <p className="text-xs text-slate-300">Your project has been added to the ENTCverse Showcase.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmitProject} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Project Title:</label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g. Dual-Axis Solar Photovoltaic Tracker"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Author Name(s):</label>
                    <input
                      type="text"
                      required
                      value={newAuthor}
                      onChange={(e) => setNewAuthor(e.target.value)}
                      placeholder="e.g. Priya Sharma"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">College / University:</label>
                    <input
                      type="text"
                      required
                      value={newCollege}
                      onChange={(e) => setNewCollege(e.target.value)}
                      placeholder="e.g. COEP Pune"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Category:</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  >
                    <option value="IoT">IoT</option>
                    <option value="Telecommunication">Telecommunication</option>
                    <option value="Embedded Systems">Embedded Systems</option>
                    <option value="DSP">DSP</option>
                    <option value="Robotics">Robotics</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Summary & Test Description:</label>
                  <textarea
                    rows={3}
                    value={newSummary}
                    onChange={(e) => setNewSummary(e.target.value)}
                    placeholder="Describe what was built and which lab instruments were used..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Components Used (comma-separated):</label>
                  <input
                    type="text"
                    value={newComponents}
                    onChange={(e) => setNewComponents(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowSubmitModal(false)}
                    className="px-3 py-2 text-slate-400 hover:text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl cursor-pointer"
                  >
                    Publish Project (+100 XP)
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
