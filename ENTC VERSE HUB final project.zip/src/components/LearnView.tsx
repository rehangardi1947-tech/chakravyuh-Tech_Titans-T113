import React, { useState } from 'react';
import { 
  GraduationCap, 
  BookOpen, 
  Calculator, 
  Cpu, 
  CheckCircle, 
  AlertCircle, 
  Layers, 
  Zap,
  ArrowRight,
  Search,
  Award,
  Flame,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  Activity,
  HelpCircle,
  RotateCcw
} from 'lucide-react';
import { ACADEMY_LESSONS } from '../data/academyLessonsData';
import { GLOSSARY_TERMS } from '../data/glossaryData';
import { Lesson, GlossaryTerm, EquipmentItem } from '../types';
import { storageService } from '../services/storageService';

interface LearnViewProps {
  onRentEquipment?: (item: EquipmentItem) => void;
  onOpenVirtualLab?: () => void;
}

export const LearnView: React.FC<LearnViewProps> = ({
  onRentEquipment,
  onOpenVirtualLab
}) => {
  const [activeTab, setActiveTab] = useState<'academy' | 'glossary' | 'pinouts' | 'calculators'>('academy');
  const [selectedLesson, setSelectedLesson] = useState<Lesson>(ACADEMY_LESSONS[0]);

  // Quiz state for the selected lesson
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizFeedback, setQuizFeedback] = useState<{ score: number; total: number } | null>(null);

  // Glossary search & category filters
  const [glossaryQuery, setGlossaryQuery] = useState('');
  const [selectedGlossaryCategory, setSelectedGlossaryCategory] = useState<string>('All');

  // Gamification state
  const [gamification, setGamification] = useState(() => storageService.getGamificationState());

  // Resistor Color Code Calculator State
  const [band1, setBand1] = useState<number>(4); // Yellow (4)
  const [band2, setBand2] = useState<number>(7); // Violet (7)
  const [multiplier, setMultiplier] = useState<number>(2); // Red (x100)
  const [tolerance, setTolerance] = useState<number>(5); // Gold (5%)

  // ESP32 Pin Explorer
  const [inspectedPin, setInspectedPin] = useState<string>('GPIO 2');

  const colorBands = [
    { name: 'Black', value: 0, mult: 1, hex: '#000000', text: '#ffffff' },
    { name: 'Brown', value: 1, mult: 10, hex: '#8B4513', text: '#ffffff' },
    { name: 'Red', value: 2, mult: 100, hex: '#DC2626', text: '#ffffff' },
    { name: 'Orange', value: 3, mult: 1000, hex: '#EA580C', text: '#ffffff' },
    { name: 'Yellow', value: 4, mult: 10000, hex: '#CA8A04', text: '#000000' },
    { name: 'Green', value: 5, mult: 100000, hex: '#16A34A', text: '#ffffff' },
    { name: 'Blue', value: 6, mult: 1000000, hex: '#2563EB', text: '#ffffff' },
    { name: 'Violet', value: 7, mult: 10000000, hex: '#9333EA', text: '#ffffff' },
    { name: 'Grey', value: 8, mult: 100000000, hex: '#6B7280', text: '#ffffff' },
    { name: 'White', value: 9, mult: 1000000000, hex: '#F3F4F6', text: '#000000' },
  ];

  const calculatedResistance = (band1 * 10 + band2) * Math.pow(10, multiplier);
  const formattedResistance = calculatedResistance >= 1000000 
    ? `${(calculatedResistance / 1000000).toFixed(2)} MΩ` 
    : calculatedResistance >= 1000 
    ? `${(calculatedResistance / 1000).toFixed(1)} kΩ` 
    : `${calculatedResistance} Ω`;

  const esp32Pins: Record<string, { role: string; voltage: string; notes: string; safe: boolean }> = {
    'GPIO 2': { role: 'General I/O & Onboard Blue LED', voltage: '3.3V Max', notes: 'Connected to internal pull-down; must be floating or low during flashing.', safe: true },
    'GPIO 4': { role: 'General I/O, ADC2_CH0, Touch 0', voltage: '3.3V Max', notes: 'General purpose pin, fully safe for external sensors.', safe: true },
    'GPIO 18': { role: 'VSPI CLK (Serial Clock)', voltage: '3.3V Max', notes: 'Standard hardware SPI clock line for SD cards and LoRa radios.', safe: true },
    'GPIO 19': { role: 'VSPI MISO (Master In Slave Out)', voltage: '3.3V Max', notes: 'Data receive line for SPI peripherals.', safe: true },
    'GPIO 21': { role: 'I2C SDA (Serial Data)', voltage: '3.3V Max', notes: 'Default hardware I2C data bus line. Connect 4.7k pull-up to 3.3V.', safe: true },
    'GPIO 22': { role: 'I2C SCL (Serial Clock)', voltage: '3.3V Max', notes: 'Default hardware I2C clock bus line.', safe: true },
    'GPIO 23': { role: 'VSPI MOSI (Master Out Slave In)', voltage: '3.3V Max', notes: 'Data transmit line for SPI peripherals.', safe: true },
    'GPIO 34': { role: 'Input Only (ADC1_CH6)', voltage: '3.3V Max', notes: 'Cannot output digital high/low! Ideal for analog sensor readings.', safe: true },
    'GPIO 36 (VP)': { role: 'Input Only (ADC1_CH0)', voltage: '3.3V Max', notes: 'Low noise pre-amplifier input. Input only; no internal pull-up.', safe: true },
    'VIN (5V)': { role: 'External Power Input', voltage: '5.0V Input', notes: 'Powers onboard AMS1117 3.3V LDO. Do not short to 3.3V pin!', safe: true },
    '3V3': { role: 'Regulated 3.3V Power Output', voltage: '3.3V (600mA)', notes: 'Main power supply rail for low-power sensors.', safe: true },
    'GND': { role: 'System Ground', voltage: '0V Reference', notes: 'Common ground reference for all connected circuits.', safe: true }
  };

  const handleSelectLesson = (lesson: Lesson) => {
    setSelectedLesson(lesson);
    setSelectedAnswers({});
    setQuizSubmitted(false);
    setQuizFeedback(null);
  };

  const handleSelectAnswer = (qId: string, optIdx: number) => {
    if (quizSubmitted) return;
    setSelectedAnswers(prev => ({ ...prev, [qId]: optIdx }));
  };

  const handleQuizSubmit = () => {
    let score = 0;
    selectedLesson.quiz.forEach(q => {
      if (selectedAnswers[q.id] === q.correctIndex) {
        score++;
      }
    });
    setQuizSubmitted(true);
    setQuizFeedback({ score, total: selectedLesson.quiz.length });

    // Persist completion and award XP
    storageService.completeLesson(selectedLesson.id, score);
    setGamification(storageService.getGamificationState());
  };

  // Glossary filter
  const filteredGlossary = GLOSSARY_TERMS.filter(item => {
    const matchesCat = selectedGlossaryCategory === 'All' || item.category === selectedGlossaryCategory;
    const matchesSearch = item.term.toLowerCase().includes(glossaryQuery.toLowerCase()) ||
                          item.definition.toLowerCase().includes(glossaryQuery.toLowerCase()) ||
                          item.practicalContext.toLowerCase().includes(glossaryQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const glossaryCategories = ['All', 'Fundamentals', 'Instruments', 'Semiconductors', 'Protocols', 'RF & Wireless', 'Fabrication'];

  // Check if current lesson is completed
  const isLessonCompleted = gamification.completedLessonIds.includes(selectedLesson.id);
  const relatedEquip = storageService.getEquipmentById(selectedLesson.relatedEquipmentId);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-left">
      {/* Title & Gamification Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono mb-1">
            <GraduationCap className="w-4 h-4" />
            <span>ENTC LEARNING ACADEMY & KNOWLEDGE REPOSITORY</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Learn Practical Electronics & Telecommunications
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
            15 structured lessons designed for beginners who cannot afford a personal laboratory. Master circuit fundamentals, troubleshooting, and instruments before renting physical hardware.
          </p>
        </div>

        {/* Gamification Stats */}
        <div className="flex items-center gap-3 self-start md:self-auto font-mono text-xs">
          <div className="px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400" />
            <span className="text-slate-300">Streak:</span>
            <span className="text-amber-400 font-bold">{gamification.streakDays} Days</span>
          </div>

          <div className="px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
            <Award className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-300">Lvl {gamification.level}</span>
            <span className="text-cyan-400 font-bold">{gamification.xp} XP</span>
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'academy', label: '15-Lesson Academy', icon: BookOpen },
          { id: 'glossary', label: 'ENTC Glossary (40+ Terms)', icon: Layers },
          { id: 'pinouts', label: 'MCU Pinout Guide', icon: Cpu },
          { id: 'calculators', label: 'Resistor Calculator', icon: Calculator }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-2 px-3.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ---------------------------------------------------- */}
      {/* TAB 1: ACADEMY (15 LESSONS) */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'academy' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Lesson Directory */}
          <div className="lg:col-span-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
              <span>LEARNING MODULES (15 TOTAL)</span>
              <span>{gamification.completedLessonIds.length} / 15 DONE</span>
            </div>

            <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
              {ACADEMY_LESSONS.map((lesson) => {
                const isSel = lesson.id === selectedLesson.id;
                const isDone = gamification.completedLessonIds.includes(lesson.id);

                return (
                  <button
                    key={lesson.id}
                    onClick={() => handleSelectLesson(lesson)}
                    className={`w-full p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-start justify-between gap-3 ${
                      isSel
                        ? 'bg-cyan-500/15 border-cyan-500 text-white shadow-sm'
                        : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-mono text-cyan-400">
                          LESSON 0{lesson.order}
                        </span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                          {lesson.difficulty}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-white line-clamp-1">
                        {lesson.title}
                      </h4>
                      <p className="text-[11px] text-slate-300 line-clamp-1 mt-0.5">
                        {lesson.category} · {lesson.readTime}
                      </p>
                    </div>

                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-1" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-slate-300 shrink-0 mt-1" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Column: Full Lesson Reader */}
          <div className="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
            {/* Lesson Header */}
            <div className="border-b border-slate-800 pb-5">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                  {selectedLesson.category} · {selectedLesson.readTime}
                </span>
                {isLessonCompleted && (
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    COMPLETED (+150 XP)
                  </span>
                )}
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                {selectedLesson.title}
              </h2>
            </div>

            {/* Learning Objectives */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider block">
                Learning Objectives:
              </span>
              <ul className="space-y-1 text-xs text-slate-300">
                {selectedLesson.objectives.map((obj, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-cyan-400 mt-0.5">•</span>
                    <span>{obj}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Core Explanation */}
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono text-cyan-300">
                Core Engineering Explanation
              </h3>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                {selectedLesson.explanation}
              </p>
            </div>

            {/* Practical Examples */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono text-slate-400">
                Practical Real-World Context:
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {selectedLesson.practicalExamples.map((ex, idx) => (
                  <div key={idx} className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 text-xs text-slate-300">
                    {ex}
                  </div>
                ))}
              </div>
            </div>

            {/* Step-by-Step Practical Lab Experiment */}
            <div className="p-5 rounded-2xl bg-slate-950/80 border border-cyan-500/30 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <h4 className="text-xs sm:text-sm font-bold text-white">
                    Step-by-Step Bench Experiment
                  </h4>
                </div>
                {onOpenVirtualLab && (
                  <button
                    onClick={onOpenVirtualLab}
                    className="text-xs text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>Test in Virtual Lab</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>

              <div className="text-xs text-slate-300 space-y-1">
                <span className="font-semibold text-white block">Required Components:</span>
                <p className="text-slate-300">{selectedLesson.requiredComponents.join(' · ')}</p>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-semibold text-white block">Wiring & Test Instructions:</span>
                <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-300">
                  {selectedLesson.stepByStepInstructions.map((step, idx) => (
                    <li key={idx} className="leading-relaxed pl-1">{step}</li>
                  ))}
                </ol>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
                <span className="text-emerald-400 font-bold block mb-1">Expected Observations:</span>
                <ul className="space-y-1">
                  {selectedLesson.expectedObservations.map((obs, idx) => (
                    <li key={idx}>• {obs}</li>
                  ))}
                </ul>
              </div>

              {/* Common Mistakes & Troubleshooting */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/30 text-[11px] text-amber-200/90">
                  <span className="font-bold text-amber-300 block mb-1">Common Mistakes:</span>
                  <ul className="space-y-1">
                    {selectedLesson.commonMistakes.map((m, idx) => (
                      <li key={idx}>• {m}</li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 rounded-xl bg-blue-950/20 border border-blue-500/30 text-[11px] text-blue-200/90">
                  <span className="font-bold text-blue-300 block mb-1">Troubleshooting Tips:</span>
                  <ul className="space-y-1">
                    {selectedLesson.troubleshooting.map((t, idx) => (
                      <li key={idx}>• {t}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Interactive Concept Quiz */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-cyan-400" />
                  <h4 className="text-xs sm:text-sm font-bold text-white">
                    Knowledge Check Quiz (Earn 25 XP per correct answer)
                  </h4>
                </div>
                {quizSubmitted && quizFeedback && (
                  <span className="text-xs font-mono font-bold text-cyan-400">
                    Score: {quizFeedback.score} / {quizFeedback.total}
                  </span>
                )}
              </div>

              <div className="space-y-4">
                {selectedLesson.quiz.map((q, qIdx) => {
                  const userAns = selectedAnswers[q.id];
                  return (
                    <div key={q.id} className="space-y-2 text-xs">
                      <p className="font-semibold text-white">
                        {qIdx + 1}. {q.question}
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {q.options.map((opt, optIdx) => {
                          const isSelected = userAns === optIdx;
                          const isCorrect = q.correctIndex === optIdx;
                          let btnStyle = 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700';

                          if (quizSubmitted) {
                            if (isCorrect) {
                              btnStyle = 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold';
                            } else if (isSelected && !isCorrect) {
                              btnStyle = 'bg-red-500/20 border-red-500 text-red-300';
                            }
                          } else if (isSelected) {
                            btnStyle = 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold';
                          }

                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleSelectAnswer(q.id, optIdx)}
                              className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${btnStyle}`}
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>

                      {quizSubmitted && (
                        <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 text-[11px] text-slate-300 font-mono">
                          <span className="text-cyan-400 font-bold">Explanation: </span>
                          {q.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="pt-2 flex justify-end">
                {!quizSubmitted ? (
                  <button
                    onClick={handleQuizSubmit}
                    disabled={Object.keys(selectedAnswers).length < selectedLesson.quiz.length}
                    className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
                  >
                    Submit Quiz & Claim XP
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      setQuizSubmitted(false);
                      setSelectedAnswers({});
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Retake Quiz</span>
                  </button>
                )}
              </div>
            </div>

            {/* Related Equipment Rental Callout */}
            {relatedEquip && (
              <div className="p-4 rounded-xl bg-gradient-to-r from-slate-950 to-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 uppercase">Recommended Physical Showroom Gear</span>
                  <div className="text-sm font-bold text-white mt-0.5">{relatedEquip.name}</div>
                  <div className="text-slate-400 text-xs">Available for student rental at ₹{relatedEquip.dailyRate}/day with showroom pickup.</div>
                </div>

                <button
                  onClick={() => onRentEquipment ? onRentEquipment(relatedEquip) : null}
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shrink-0 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Rent This Lab Kit</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* TAB 2: GLOSSARY (40+ ENTC TERMS) */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'glossary' && (
        <div className="space-y-6">
          {/* Search & Filter Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={glossaryQuery}
                onChange={(e) => setGlossaryQuery(e.target.value)}
                placeholder="Search ENTC terms (e.g. Nyquist, True-RMS, KVL, I2C, VSWR)..."
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Category pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
              {glossaryCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedGlossaryCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                    selectedGlossaryCategory === cat
                      ? 'bg-cyan-500 text-slate-950 font-bold'
                      : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Terms Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredGlossary.map((term, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-400">
                      {term.category}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white tracking-tight">
                    {term.term}
                  </h3>
                  <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                    {term.definition}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] font-mono text-slate-400">
                  <span className="text-cyan-400 font-semibold block mb-0.5">Practical Context:</span>
                  <span className="text-slate-300">{term.practicalContext}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* TAB 3: MCU PINOUTS */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'pinouts' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white">ESP32 DevKit v1 Pin Selector</h3>
            </div>
            <p className="text-xs text-slate-400">
              Click any pin to inspect electrical ratings, strapping warnings, and safe peripheral usage.
            </p>

            <div className="grid grid-cols-2 gap-1.5 max-h-[500px] overflow-y-auto pr-1">
              {Object.keys(esp32Pins).map((pinName) => (
                <button
                  key={pinName}
                  onClick={() => setInspectedPin(pinName)}
                  className={`p-2 rounded-lg text-xs font-mono text-left border transition-all cursor-pointer ${
                    inspectedPin === pinName
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500 font-bold'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  {pinName}
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
            {esp32Pins[inspectedPin] && (
              <div className="space-y-4 text-xs">
                <div className="border-b border-slate-800 pb-4">
                  <span className="text-xs font-mono text-cyan-400 uppercase">Hardware Pin Profile</span>
                  <h3 className="text-xl font-bold text-white mt-0.5">{inspectedPin}</h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Primary Role</span>
                    <span className="text-sm font-bold text-white mt-1 block">
                      {esp32Pins[inspectedPin].role}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-mono block">Safe Operating Limit</span>
                    <span className="text-sm font-bold text-emerald-400 mt-1 block">
                      {esp32Pins[inspectedPin].voltage}
                    </span>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
                  <span className="font-bold text-white block">Engineering Lab Notes:</span>
                  <p className="leading-relaxed">{esp32Pins[inspectedPin].notes}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* TAB 4: RESISTOR CALCULATOR */}
      {/* ---------------------------------------------------- */}
      {activeTab === 'calculators' && (
        <div className="max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
          <div className="border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-mono mb-1">
              <Calculator className="w-4 h-4" />
              <span>PASSIVE COMPONENT METROLOGY</span>
            </div>
            <h3 className="text-xl font-bold text-white">4-Band Resistor Color Code Calculator</h3>
          </div>

          {/* Visual Resistor Body */}
          <div className="p-6 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-center">
            <div className="w-64 h-16 bg-[#d2b48c] rounded-full border-4 border-[#b59a72] relative flex items-center justify-around px-8 shadow-inner">
              <div className="w-3 h-full" style={{ backgroundColor: colorBands[band1].hex }}></div>
              <div className="w-3 h-full" style={{ backgroundColor: colorBands[band2].hex }}></div>
              <div className="w-3 h-full" style={{ backgroundColor: colorBands[multiplier].hex }}></div>
              <div className="w-3 h-full bg-[#d4af37]"></div>
            </div>
          </div>

          <div className="text-center font-mono">
            <span className="text-xs text-slate-400 block">Computed Resistance:</span>
            <span className="text-3xl font-extrabold text-cyan-400">{formattedResistance} ±{tolerance}%</span>
          </div>

          {/* Band Selectors */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Band 1 (1st Digit):</label>
              <select
                value={band1}
                onChange={(e) => setBand1(parseInt(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
              >
                {colorBands.slice(1).map((b) => (
                  <option key={b.value} value={b.value}>
                    {b.value} - {b.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Band 2 (2nd Digit):</label>
              <select
                value={band2}
                onChange={(e) => setBand2(parseInt(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
              >
                {colorBands.map((b) => (
                  <option key={b.value} value={b.value}>
                    {b.value} - {b.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Band 3 (Multiplier):</label>
              <select
                value={multiplier}
                onChange={(e) => setMultiplier(parseInt(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
              >
                {colorBands.slice(0, 8).map((b) => (
                  <option key={b.value} value={b.value}>
                    10^{b.value} ({b.name})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
