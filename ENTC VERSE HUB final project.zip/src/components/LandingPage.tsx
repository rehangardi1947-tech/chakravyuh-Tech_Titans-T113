import React, { useState, useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  ArrowRight, 
  ChevronRight, 
  Sparkles, 
  ShieldCheck, 
  Cpu, 
  GraduationCap, 
  Building2, 
  Zap, 
  Activity, 
  CheckCircle2, 
  Clock, 
  DollarSign, 
  HelpCircle,
  Layers,
  Heart,
  Sliders,
  ExternalLink,
  Flame,
  Radio,
  Compass,
  ArrowUpRight,
  TrendingUp,
  RefreshCw,
  Eye,
  ShoppingCart,
  Award,
  ChevronDown,
  ChevronUp,
  Box
} from 'lucide-react';
import { HeroSection } from './HeroSection';
import { Tilt3DCard } from './Tilt3DCard';
import { EQUIPMENT_ITEMS } from '../data/equipmentData';
import { STUDENT_PROJECTS } from '../data/projectsData';
import { LEARNING_GUIDES } from '../data/learningData';
import { EquipmentItem, Category } from '../types';

gsap.registerPlugin(ScrollTrigger);

interface LandingPageProps {
  onExploreEquipment: () => void;
  onStartLearning: () => void;
  onOpenVirtualLab: () => void;
  onSelectEquipment: (item: EquipmentItem) => void;
  onBookEquipment: (item: EquipmentItem) => void;
  onOpenBusinessHub: () => void;
  onOpenProjects?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onExploreEquipment,
  onStartLearning,
  onOpenVirtualLab,
  onSelectEquipment,
  onBookEquipment,
  onOpenBusinessHub,
  onOpenProjects = onExploreEquipment
}) => {
  const pageContainerRef = useRef<HTMLDivElement>(null);

  const [activeCategory, setActiveCategory] = useState<string>('All');
  
  // Section D State
  const [previewVSupply, setPreviewVSupply] = useState<number>(5.0);
  const [previewResistor, setPreviewResistor] = useState<number>(330);
  const [previewLedColor, setPreviewLedColor] = useState<'amber' | 'red' | 'emerald'>('amber');
  const [previewWaveType, setPreviewWaveType] = useState<'sine' | 'square' | 'triangle'>('sine');
  const [previewFreq, setPreviewFreq] = useState<number>(1000);

  const [scrollProgress, setScrollProgress] = useState(0);

  const vfMap = { amber: 2.1, red: 1.9, emerald: 2.2 };
  const currentVf = vfMap[previewLedColor];
  const previewCurrentMa = previewVSupply > currentVf 
    ? Math.max(0, ((previewVSupply - currentVf) / previewResistor) * 1000) 
    : 0;
  const isBurnedOut = previewCurrentMa > 35;
  const isOverdriven = previewCurrentMa > 22 && !isBurnedOut;

  // Waveform canvas ref
  const waveCanvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = waveCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let offset = 0;

    const renderWave = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Grid lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.lineWidth = 1;
      for (let x = 0; x < canvas.width; x += 20) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += 20) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
      }

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.beginPath();
      ctx.moveTo(0, canvas.height / 2);
      ctx.lineTo(canvas.width, canvas.height / 2);
      ctx.stroke();

      ctx.strokeStyle = isBurnedOut ? '#ef4444' : '#f59e0b';
      ctx.lineWidth = 2.5;
      ctx.beginPath();

      const centerY = canvas.height / 2;
      const amp = isBurnedOut ? 0 : Math.min(canvas.height * 0.38, (previewCurrentMa / 25) * (canvas.height * 0.35));
      const freqFactor = (previewFreq / 1000) * 0.06;

      for (let x = 0; x < canvas.width; x++) {
        let y = centerY;
        const angle = (x + offset) * freqFactor;

        if (previewWaveType === 'sine') {
          y = centerY - Math.sin(angle) * amp;
        } else if (previewWaveType === 'square') {
          y = centerY - (Math.sin(angle) >= 0 ? amp : -amp);
        } else if (previewWaveType === 'triangle') {
          y = centerY - ((Math.asin(Math.sin(angle)) / (Math.PI / 2)) * amp);
        }

        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }

      ctx.stroke();
      offset += 1.8;
      animId = requestAnimationFrame(renderWave);
    };

    renderWave();
    return () => cancelAnimationFrame(animId);
  }, [previewVSupply, previewResistor, previewLedColor, previewWaveType, previewFreq, isBurnedOut, previewCurrentMa]);

  // GSAP Scroll Animations
  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) return;

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        start: 'top top',
        end: 'bottom bottom',
        onUpdate: (self) => {
          setScrollProgress(Math.round(self.progress * 100));
        }
      });

      gsap.from('.universe-card', {
        scrollTrigger: {
          trigger: '#section-universe',
          start: 'top 80%',
          toggleActions: 'play none none none'
        },
        y: 45,
        opacity: 0,
        stagger: 0.12,
        duration: 0.8,
        ease: 'power3.out'
      });

      gsap.from('.workflow-step', {
        scrollTrigger: {
          trigger: '#section-workflow',
          start: 'top 75%',
          toggleActions: 'play none none none'
        },
        y: 40,
        opacity: 0,
        stagger: 0.14,
        duration: 0.8,
        ease: 'back.out(1.2)'
      });

      gsap.from('.showcase-card', {
        scrollTrigger: {
          trigger: '#section-showcase',
          start: 'top 80%',
          toggleActions: 'play none none none'
        },
        y: 40,
        opacity: 0,
        stagger: 0.1,
        duration: 0.7,
        ease: 'power2.out'
      });

      gsap.from('#lab-preview-box', {
        scrollTrigger: {
          trigger: '#section-virtual-lab',
          start: 'top 75%',
          toggleActions: 'play none none none'
        },
        scale: 0.95,
        opacity: 0,
        duration: 0.85,
        ease: 'power3.out'
      });

      gsap.from('.academy-card', {
        scrollTrigger: {
          trigger: '#section-academy',
          start: 'top 80%',
          toggleActions: 'play none none none'
        },
        y: 35,
        opacity: 0,
        stagger: 0.12,
        duration: 0.7,
        ease: 'power2.out'
      });

      gsap.from('.project-card', {
        scrollTrigger: {
          trigger: '#section-projects',
          start: 'top 80%',
          toggleActions: 'play none none none'
        },
        y: 40,
        opacity: 0,
        stagger: 0.15,
        duration: 0.8,
        ease: 'power3.out'
      });

      gsap.from('.business-stage', {
        scrollTrigger: {
          trigger: '#section-business',
          start: 'top 80%',
          toggleActions: 'play none none none'
        },
        y: 35,
        opacity: 0,
        stagger: 0.12,
        duration: 0.7,
        ease: 'power2.out'
      });

      gsap.from('#section-cta-box', {
        scrollTrigger: {
          trigger: '#section-cta',
          start: 'top 80%',
          toggleActions: 'play none none none'
        },
        scale: 0.94,
        opacity: 0,
        duration: 0.9,
        ease: 'power3.out'
      });

    }, pageContainerRef);

    return () => ctx.revert();
  }, [activeCategory]);

  const showcaseCategories = ['All', 'Oscilloscopes', 'Microcontrollers', 'RF & Communication', 'Complete Lab Kits'];
  const filteredEquipment = EQUIPMENT_ITEMS.filter(item => {
    if (activeCategory === 'All') return item.popular;
    return item.category === activeCategory;
  }).slice(0, 6);

  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const faqs = [
    {
      q: 'How does equipment rental work for university students?',
      a: 'Browse our equipment catalogue, pick your rental duration (1 day to semester-long), and select either free 1-hour counter pickup at our physical showroom (Pune or Bengaluru) or express campus courier. Present your verified student ID at checkout to receive 15% off standard rates.'
    },
    {
      q: 'How are security deposits managed and refunded?',
      a: 'A refundable security deposit is held during the rental period. When you return the device to our showroom counter or courier partner, our automated bench test checks channel calibration and probe integrity. Once verified (usually under 15 minutes), the 100% deposit is immediately released to your original payment method.'
    },
    {
      q: 'What if a component or probe is accidentally damaged?',
      a: 'We understand that electronics experimentation involves learning! Passive components like resistors and jumpers are consumable. Probes and multimeters are covered under our subsidized lab insurance pool. You only pay nominal repair costs for major silicon damage.'
    },
    {
      q: 'Can equipment owners monetize their idle lab gear?',
      a: 'Yes! Senior engineers, private makers, and university research labs can consign idle oscilloscopes, RF analyzers, and power supplies to our showroom. We calibrate, insure, and rent them out, remitting 65% of all rental proceeds directly to your bank account.'
    },
    {
      q: 'Do the virtual lab simulations accurately reflect physical hardware?',
      a: 'Yes. Our virtual lab models follow real differential equations for RC cutoffs, 555 astable timing constants, and TTL 74xx logic propagation delays. You can simulate circuits in the browser first, then test identical physical values on rented bench hardware.'
    }
  ];

  const waypoints = [
    { id: 'hero', label: 'Hero', targetId: 'section-hero' },
    { id: 'universe', label: '3D Universe', targetId: 'section-universe' },
    { id: 'workflow', label: '5-Stage Flow', targetId: 'section-workflow' },
    { id: 'showcase', label: 'Inventory', targetId: 'section-showcase' },
    { id: 'virtual-lab', label: 'Virtual Lab', targetId: 'section-virtual-lab' },
    { id: 'academy', label: 'Academy', targetId: 'section-academy' },
    { id: 'projects', label: 'Projects', targetId: 'section-projects' },
    { id: 'business', label: 'Consignment', targetId: 'section-business' },
    { id: 'cta', label: 'Launch', targetId: 'section-cta' }
  ];

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div ref={pageContainerRef} className="space-y-24 sm:space-y-32 pb-24 relative bg-[#09090b] text-neutral-100">
      
      {/* FLOATING SPATIAL HUD (Right Dock in Obsidian Black & Gold) */}
      <div className="hidden xl:flex fixed right-4 top-1/2 -translate-y-1/2 z-40 flex-col items-end gap-2 pointer-events-auto select-none">
        <div className="p-2.5 rounded-2xl bg-neutral-950/95 border border-amber-500/30 shadow-2xl flex flex-col gap-1.5 backdrop-blur-md">
          <div className="px-2 py-1 flex items-center justify-between text-[10px] font-mono font-bold text-amber-300 border-b border-amber-500/20 pb-1 mb-1">
            <span>INDEX</span>
            <span className="font-extrabold text-amber-400">{scrollProgress}%</span>
          </div>

          {waypoints.map((wp) => (
            <button
              key={wp.id}
              onClick={() => scrollToSection(wp.targetId)}
              className="flex items-center gap-2 group text-left px-2 py-1 rounded-lg hover:bg-neutral-900 transition-colors cursor-pointer"
            >
              <span className="text-[11px] font-mono text-neutral-400 group-hover:text-amber-300 font-medium transition-colors">
                {wp.label}
              </span>
              <span className="w-2 h-2 rounded-full bg-neutral-700 group-hover:bg-amber-400 group-hover:scale-125 transition-all" />
            </button>
          ))}
        </div>
      </div>

      {/* HERO SECTION */}
      <div id="section-hero">
        <HeroSection
          onExploreClick={onExploreEquipment}
          onStartLearningClick={onStartLearning}
          onSelectEquipment={onSelectEquipment}
          onOpenVirtualLab={onOpenVirtualLab}
          onOpenProjects={onOpenProjects}
        />
      </div>

      {/* SECTION A — ENTER THE ELECTRONICS UNIVERSE (Obsidian & Gold 3D Cards) */}
      <section id="section-universe" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-amber-400">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>CORE INSTRUMENT SUITES · 3D INTERFACE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
            Enter the Electronics Universe
          </h2>
          <p className="text-sm sm:text-base text-neutral-400">
            Industrial-grade test instruments and microelectronics available on-demand. Move your cursor over any card to experience dimensional physical tilt.
          </p>
        </div>

        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              title: 'Digital Storage Oscilloscopes',
              badge: 'Signal Integrity',
              desc: '4-channel 100MHz DSOs with 1GSa/s sampling, I2C/SPI decoding, and 24Mpts deep memory.',
              specs: '100MHz · 1GSa/s · 4 Channels',
              rate: 'From ₹290 / day',
              icon: Activity,
              filterKey: 'Oscilloscopes'
            },
            {
              title: 'Microcontroller Systems',
              badge: 'Embedded Compute',
              desc: 'Dual-core 240MHz ESP32, STM32 ARM Cortex, and Arduino Mega IoT suites with OLED displays.',
              specs: 'Wi-Fi · BLE · 34 GPIOs · Free RTOS',
              rate: 'From ₹65 / day',
              icon: Cpu,
              filterKey: 'Microcontrollers'
            },
            {
              title: 'RF & Sub-GHz LoRa Kits',
              badge: 'Telecommunication',
              desc: 'Long-range 868MHz transceiver nodes, directional antennas, and spectrum analyzer testing modules.',
              specs: 'SX1276 · +20dBm · 15km Range',
              rate: 'From ₹120 / day',
              icon: Radio,
              filterKey: 'RF & Communication'
            },
            {
              title: 'Complete Practical Lab Kits',
              badge: 'Full Workbenches',
              desc: 'Turnkey bundles including Hakko ESD soldering iron, variable DC power supply, DMM, and components.',
              specs: '0-30V 5A PSU · Hakko Station · DMM',
              rate: 'From ₹350 / day',
              icon: Layers,
              filterKey: 'Complete Lab Kits'
            }
          ].map((cat, idx) => (
            <Tilt3DCard
              key={idx}
              tiltMax={8}
              className="universe-card h-full"
              onClick={() => {
                setActiveCategory(cat.filterKey);
                onExploreEquipment();
              }}
            >
              <div
                className="p-6 rounded-2xl bg-neutral-950/90 border border-amber-500/25 hover:border-amber-400 transition-all duration-300 shadow-xl shadow-black/40 hover:shadow-amber-500/10 cursor-pointer flex flex-col justify-between h-full group"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="p-3 rounded-xl bg-neutral-900 border border-amber-500/30 text-amber-400 group-hover:scale-110 transition-transform shadow-sm">
                      <cat.icon className="w-5 h-5 text-amber-400" />
                    </span>
                    <span className="text-[11px] font-mono font-medium px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                      {cat.badge}
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    <h3 className="text-lg font-bold text-white group-hover:text-amber-300 transition-colors">
                      {cat.title}
                    </h3>
                    <p className="text-xs text-neutral-400 leading-relaxed">
                      {cat.desc}
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-neutral-900/80 border border-amber-500/20 text-[11px] font-mono text-neutral-300">
                    {cat.specs}
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-amber-500/20 flex items-center justify-between text-xs">
                  <span className="font-extrabold text-amber-400">{cat.rate}</span>
                  <span className="text-amber-300 font-semibold group-hover:translate-x-1 transition-transform flex items-center gap-1">
                    <span>Browse Gear</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </Tilt3DCard>
          ))}
        </div>
      </section>

      {/* SECTION B — HOW IT WORKS (ANIMATED 5-STAGE WORKFLOW) */}
      <section id="section-workflow" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-amber-400">
            <Compass className="w-3.5 h-3.5 text-amber-400" />
            <span>THE 5-STAGE WORKFLOW</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
            A Frictionless Bridge from Concept to Silicon
          </h2>
          <p className="text-sm sm:text-base text-neutral-400">
            Never let high instrument purchase costs derail your engineering curiosity. Build, test, and graduate with certified confidence.
          </p>
        </div>

        <div className="mt-12 relative">
          <div className="hidden lg:block absolute top-1/2 left-8 right-8 h-0.5 bg-amber-500/20 -translate-y-12 pointer-events-none" />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 relative z-10">
            {[
              {
                step: '01',
                title: 'DISCOVER',
                badge: 'Catalogue',
                desc: 'Browse calibrated oscilloscopes, microcontrollers, and complete practical kits available across Pune & Bengaluru showrooms.'
              },
              {
                step: '02',
                title: 'LEARN',
                badge: 'Virtual Lab',
                desc: 'Simulate differential equations, probe attenuation, and component limits in our interactive circuit simulator before touching physical gear.'
              },
              {
                step: '03',
                title: 'RENT',
                badge: 'Subsidized',
                desc: 'Book for daily or weekly periods. Enjoy 15% student discounts, subsidized deposit pools, and free 1-hour counter pickup.'
              },
              {
                step: '04',
                title: 'EXPERIMENT',
                badge: 'Real Bench Gear',
                desc: 'Wire circuits on physical breadboards, probe high-frequency clock signals, and capture real-time waveforms on 100MHz DSOs.'
              },
              {
                step: '05',
                title: 'BUILD',
                badge: 'Capstone Ready',
                desc: 'Complete your engineering capstone project, verify specs with Dr. Silicon AI Mentor, and return equipment for automatic deposit release.'
              }
            ].map((item, idx) => (
              <Tilt3DCard key={idx} tiltMax={6} className="workflow-step">
                <div className="p-5 rounded-2xl bg-neutral-950/90 border border-amber-500/25 hover:border-amber-400 transition-all duration-300 space-y-3 relative group h-full flex flex-col justify-between shadow-xl shadow-black/40">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-mono font-extrabold bg-gradient-to-r from-amber-300 to-yellow-500 bg-clip-text text-transparent">
                        {item.step}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                        {item.badge}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors">
                      {item.title}
                    </h3>
                  </div>

                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </Tilt3DCard>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION C — INTERACTIVE EQUIPMENT SHOWCASE (Obsidian & Gold Cards) */}
      <section id="section-showcase" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-amber-500/20 pb-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-amber-400">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>SHOWROOM INVENTORY HIGHLIGHTS</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Calibrated Test Benches & Prototyping Gear
            </h2>
            <p className="text-sm text-neutral-400">
              Every instrument undergoes electrical safety verification, probe trimmer compensation, and firmware calibration before dispatch.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {showcaseCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-extrabold shadow-md shadow-amber-500/20'
                    : 'bg-neutral-950 text-neutral-400 hover:text-amber-300 border border-amber-500/25'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEquipment.map((item) => (
            <Tilt3DCard key={item.id} tiltMax={6} className="showcase-card h-full">
              <div className="rounded-2xl bg-neutral-950/90 border border-amber-500/25 hover:border-amber-400 overflow-hidden shadow-xl shadow-black/40 hover:shadow-amber-500/10 transition-all duration-300 flex flex-col justify-between h-full group">
                <div>
                  <div className="relative aspect-[16/10] bg-neutral-900 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-90 group-hover:opacity-100"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-neutral-950/90 backdrop-blur-md border border-amber-500/30 text-[11px] font-semibold text-neutral-200 flex items-center gap-1.5 shadow-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      <span>{item.availability}</span>
                    </div>

                    <div className="absolute top-3 right-3 px-2 py-0.5 rounded-md bg-black/90 border border-amber-500/30 text-[10px] font-mono text-amber-300">
                      {item.model}
                    </div>
                  </div>

                  <div className="p-5 space-y-3">
                    <div className="flex items-center justify-between text-xs text-neutral-400">
                      <span className="font-mono text-amber-300 font-bold">{item.brand}</span>
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                        {item.skillLevel}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-1">
                      {item.name}
                    </h3>

                    <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                      {item.shortDescription}
                    </p>

                    <div className="pt-2 flex flex-wrap gap-1.5">
                      {item.specs.slice(0, 3).map((spec, sIdx) => (
                        <span key={sIdx} className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-900/80 border border-amber-500/20 text-neutral-300">
                          {spec.label}: <strong className="text-amber-300">{spec.value}</strong>
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="p-5 pt-3 border-t border-amber-500/20 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-lg font-extrabold text-amber-400">₹{item.dailyRate}</span>
                        <span className="text-xs text-neutral-400">/ day</span>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono font-medium">
                        ₹{item.weeklyRate} / week · Subsidized deposit
                      </span>
                    </div>

                    <button
                      onClick={() => onSelectEquipment(item)}
                      className="p-2 rounded-xl text-neutral-400 hover:text-amber-300 hover:bg-neutral-900 transition-colors cursor-pointer"
                      title="View Technical Specs"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onSelectEquipment(item)}
                      className="py-2.5 px-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-amber-300 text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer border border-amber-500/30"
                    >
                      <span>View Specs</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => onBookEquipment(item)}
                      className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:brightness-110 text-black text-xs font-extrabold transition-all flex items-center justify-center gap-1 shadow-md shadow-amber-500/20 cursor-pointer"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>Rent Now</span>
                    </button>
                  </div>
                </div>
              </div>
            </Tilt3DCard>
          ))}
        </div>

        <div className="mt-8 text-center">
          <button
            onClick={onExploreEquipment}
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-neutral-950 border border-amber-500/40 hover:bg-gradient-to-r hover:from-amber-400 hover:to-yellow-500 hover:text-black text-sm font-bold text-amber-300 transition-all cursor-pointer shadow-md"
          >
            <span>Explore All 12 Equipment Categories & 40+ Calibrated Items</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* SECTION D — VIRTUAL ELECTRONICS LAB LIVE PREVIEW (Obsidian & Gold Theme) */}
      <section id="section-virtual-lab" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        <div id="lab-preview-box" className="rounded-3xl bg-gradient-to-br from-neutral-950 via-[#121008] to-black border border-amber-500/30 p-6 sm:p-10 shadow-2xl shadow-black/80 relative overflow-hidden">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-5 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-neutral-900 border border-amber-500/30 text-xs font-mono font-bold text-amber-300 shadow-sm">
                <Activity className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                <span>INTERACTIVE CIRCUIT LAB PREVIEW</span>
              </div>

              <div className="space-y-2">
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Simulate Differential Circuit Physics in Real Time
                </h2>
                <p className="text-sm text-neutral-400 leading-relaxed">
                  Before powering physical bench hardware, test Ohm's Law, diode thresholds, and waveform generators directly in your browser.
                </p>
              </div>

              <div className="space-y-2.5 text-xs text-neutral-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Real semiconductor diode forward voltage ($V_f$) curves</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Component burnout detection at &gt;35mA current threshold</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Interactive oscilloscope waveform monitor with frequency tuning</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={onOpenVirtualLab}
                  className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:brightness-110 text-black font-extrabold text-sm shadow-lg shadow-amber-500/20 hover:-translate-y-0.5 transition-all flex items-center gap-2 cursor-pointer group"
                >
                  <Activity className="w-4 h-4 text-black" />
                  <span>Enter Full Virtual Lab (6 Complete Experiments)</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-7 p-6 rounded-2xl bg-neutral-950/90 border border-amber-500/30 shadow-xl space-y-6">
              <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
                  <span className="text-xs font-mono font-bold text-amber-300 uppercase tracking-wider">
                    Interactive Mini Testbench · Live Circuit
                  </span>
                </div>
                <span className="text-[11px] font-mono font-bold text-amber-300 bg-amber-500/10 px-2.5 py-0.5 rounded border border-amber-500/30">
                  Ohm's Law: I = (V - Vf) / R
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span className="font-mono text-amber-300 font-bold">LIVE OSCILLOSCOPE MONITOR</span>
                  <div className="flex items-center gap-2">
                    {(['sine', 'square', 'triangle'] as const).map(w => (
                      <button
                        key={w}
                        onClick={() => setPreviewWaveType(w)}
                        className={`text-[10px] font-mono px-2 py-0.5 rounded uppercase cursor-pointer ${
                          previewWaveType === w ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-extrabold' : 'bg-neutral-900 text-neutral-400 hover:text-amber-300 border border-amber-500/20'
                        }`}
                      >
                        {w}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="relative rounded-xl overflow-hidden bg-black border border-amber-500/30">
                  <canvas
                    ref={waveCanvasRef}
                    width={560}
                    height={120}
                    className="w-full h-28 block"
                  />
                  <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-black/90 text-[10px] font-mono text-amber-300 border border-amber-500/30">
                    Freq: {previewFreq} Hz
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div className="space-y-2">
                  <label className="text-xs font-mono text-neutral-300 flex justify-between">
                    <span>V_Supply:</span>
                    <strong className="text-amber-300 font-bold">{previewVSupply.toFixed(1)} V</strong>
                  </label>
                  <div className="grid grid-cols-4 gap-1">
                    {[3.3, 5.0, 9.0, 12.0].map(v => (
                      <button
                        key={v}
                        onClick={() => setPreviewVSupply(v)}
                        className={`py-1 rounded text-[11px] font-mono cursor-pointer ${
                          previewVSupply === v 
                            ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-black font-extrabold' 
                            : 'bg-neutral-900 text-neutral-400 hover:text-amber-300 border border-amber-500/20'
                        }`}
                      >
                        {v}V
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-mono text-neutral-300 flex justify-between">
                    <span>Resistor (R):</span>
                    <strong className="text-amber-400 font-bold">{previewResistor} Ω</strong>
                  </label>
                  <input
                    type="range"
                    min={100}
                    max={1000}
                    step={10}
                    value={previewResistor}
                    onChange={(e) => setPreviewResistor(Number(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-mono text-neutral-300 flex justify-between">
                    <span>Signal Freq:</span>
                    <strong className="text-amber-300 font-bold">{previewFreq} Hz</strong>
                  </label>
                  <input
                    type="range"
                    min={200}
                    max={5000}
                    step={100}
                    value={previewFreq}
                    onChange={(e) => setPreviewFreq(Number(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer"
                  />
                </div>
              </div>

              <div className={`p-4 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-4 transition-colors ${
                isBurnedOut
                  ? 'bg-red-950/40 border-red-500/50 text-red-300'
                  : isOverdriven
                  ? 'bg-amber-950/40 border-amber-500/50 text-amber-300'
                  : 'bg-neutral-900/80 border-amber-500/30 text-neutral-200'
              }`}>
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl border ${
                    isBurnedOut
                      ? 'bg-red-900/40 border-red-500 text-red-400 animate-bounce'
                      : isOverdriven
                      ? 'bg-amber-900/40 border-amber-500 text-amber-400'
                      : 'bg-neutral-950 border-amber-500/30 text-amber-400'
                  }`}>
                    {isBurnedOut ? <Flame className="w-5 h-5" /> : <Zap className="w-5 h-5" />}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold">
                        {isBurnedOut 
                          ? 'CRITICAL: LED BURNED OUT!' 
                          : isOverdriven 
                          ? 'WARNING: Excessive Current Strain' 
                          : 'SAFE: Circuit Nominal & Protected'}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-950 text-amber-300 border border-amber-500/30">
                        I = {previewCurrentMa.toFixed(1)} mA
                      </span>
                    </div>
                    <p className="text-[11px] text-neutral-400 mt-0.5">
                      {isBurnedOut 
                        ? 'Current exceeded 35mA thermal threshold. Increase resistor above 330Ω.'
                        : isOverdriven
                        ? 'Thermal junction heating up. Safe continuous limit is 20-25mA.'
                        : 'LED operating in optimal high-efficiency lumen band.'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={onOpenVirtualLab}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:brightness-110 text-xs font-extrabold text-black transition-colors whitespace-nowrap cursor-pointer shadow-md shadow-amber-500/20"
                >
                  Open Full Lab →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION E — LEARN ENTC (THEORY GUIDES IN OBSIDIAN & GOLD) */}
      <section id="section-academy" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-amber-500/20 pb-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-amber-400">
              <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
              <span>PRACTICAL ENGINEERING ACADEMY</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Learn ENTC Electronics Fundamentals
            </h2>
          </div>
          <button
            onClick={onStartLearning}
            className="text-xs font-bold text-amber-300 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>View All Academy Lessons</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              id: 'g1',
              title: 'Oscilloscope Probe 1X vs 10X Attenuation & Ground Clip Safety',
              category: 'Instrument Invariants',
              readTime: '6 min read',
              summary: 'Why plugging a probe in 1X distorts 10MHz signals, and how connecting a grounded alligator clip to mains creates an explosive short circuit.',
              keyPoints: [
                '1X probe adds ~100pF capacitive loading to your circuit',
                '10X probe multiplies impedance to 10MΩ and drops capacitance to ~15pF',
                'Oscilloscope grounds are tied directly to mains earth'
              ]
            },
            {
              id: 'g2',
              title: 'I2C vs SPI Serial Bus Timing & Clock Jitter Debugging',
              category: 'Serial Protocols',
              readTime: '8 min read',
              summary: 'Learn how to trigger on start conditions, inspect pull-up resistor rise times on SDA/SCL, and decode SPI packet byte framing.',
              keyPoints: [
                'I2C requires open-drain 4.7kΩ pull-up resistors on bus lines',
                'SPI runs up to 50MHz+ full-duplex with dedicated chip select (CS)',
                'Observe edge ringing and ground bounce during high-speed transitions'
              ]
            },
            {
              id: 'g3',
              title: 'Flyback Diodes & Inductive Kick Protection in Motor Drivers',
              category: 'Power Circuits',
              readTime: '5 min read',
              summary: 'Inductive coils resist instantaneous current changes ($V = L \\frac{di}{dt}$). When switched off, they generate massive >100V voltage spikes that puncture MCU pins.',
              keyPoints: [
                'Reverse-biased 1N4007 or Schottky diode placed in parallel with coil',
                'Safely recirculates collapsing magnetic flux current',
                'Protects sensitive ESP32 / MOSFET driver silicon from dielectric puncture'
              ]
            }
          ].map((guide, idx) => (
            <Tilt3DCard key={idx} tiltMax={8} className="academy-card h-full" onClick={onStartLearning}>
              <div className="p-6 rounded-2xl bg-neutral-950/90 border border-amber-500/25 hover:border-amber-400 transition-all duration-300 flex flex-col justify-between h-full group cursor-pointer shadow-xl shadow-black/40 hover:shadow-amber-500/10">
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-amber-300 font-bold">{guide.category}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                      {guide.readTime}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors leading-snug">
                    {guide.title}
                  </h3>

                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {guide.summary}
                  </p>

                  <div className="pt-2 space-y-1.5 border-t border-amber-500/20">
                    {guide.keyPoints.map((pt, pIdx) => (
                      <div key={pIdx} className="text-[11px] text-neutral-300 flex items-start gap-1.5">
                        <span className="text-amber-400 font-bold shrink-0">•</span>
                        <span>{pt}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-amber-500/20 flex items-center justify-between text-xs text-amber-300 font-bold">
                  <span>Read Interactive Guide</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Tilt3DCard>
          ))}
        </div>
      </section>

      {/* SECTION F — BUILT FOR INNOVATORS (CAPSTONE PROJECTS) */}
      <section id="section-projects" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-amber-500/20 pb-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-amber-400">
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>CAPSTONE PROJECT SHOWCASE</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Built by Engineering Students Across India
            </h2>
            <p className="text-sm text-neutral-400">
              Verified final-year projects built using calibrated equipment rented from ENTCverse Hub showrooms.
            </p>
          </div>
          <button
            onClick={onOpenProjects}
            className="text-xs font-bold text-amber-300 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Explore All Projects</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          {STUDENT_PROJECTS.slice(0, 2).map((proj) => (
            <Tilt3DCard key={proj.id} tiltMax={6} className="project-card h-full">
              <div className="p-6 rounded-2xl bg-neutral-950/90 border border-amber-500/25 hover:border-amber-400 transition-all duration-300 shadow-xl shadow-black/40 hover:shadow-amber-500/10 flex flex-col justify-between h-full group">
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono px-2.5 py-1 rounded bg-amber-500/10 text-amber-300 font-bold border border-amber-500/30">
                      {proj.category}
                    </span>
                    <span className="text-amber-500/70 font-mono text-[11px]">{proj.college}</span>
                  </div>

                  <div className="space-y-1.5">
                    <h3 className="text-lg font-bold text-white group-hover:text-amber-300 transition-colors">
                      {proj.title}
                    </h3>
                    <p className="text-xs text-neutral-400">By {proj.author}</p>
                  </div>

                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {proj.summary}
                  </p>

                  <div className="space-y-1.5 pt-2 border-t border-amber-500/20">
                    <span className="text-[10px] font-mono font-bold text-amber-300 uppercase tracking-wider">
                      Key Components & Tested Instruments:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {proj.componentsUsed.slice(0, 4).map((comp, cIdx) => (
                        <span key={cIdx} className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-900 border border-amber-500/20 text-neutral-300">
                          {comp}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-amber-500/20 flex items-center justify-between">
                  <button
                    onClick={onOpenProjects}
                    className="text-xs font-bold text-amber-300 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>View Schematics & BOM</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={onExploreEquipment}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:brightness-110 text-xs font-extrabold text-black transition-colors cursor-pointer shadow-md shadow-amber-500/20"
                  >
                    Rent Required Gear
                  </button>
                </div>
              </div>
            </Tilt3DCard>
          ))}
        </div>
      </section>

      {/* SECTION G — THE BUSINESS OPPORTUNITY & LAB CONSIGNMENT (Obsidian & Gold) */}
      <section id="section-business" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        <div className="rounded-3xl bg-gradient-to-br from-neutral-950 via-[#131109] to-black border border-amber-500/30 p-8 sm:p-12 shadow-2xl shadow-black/80 relative overflow-hidden">
          <div className="max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-mono font-bold text-amber-400">
              <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
              <span>COLLABORATIVE LAB CONSIGNMENT</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Monetize Idle Bench Gear. Empower Aspiring Engineers.
            </h2>
            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
              Research labs, university departments, and senior engineers hold millions of rupees in dormant test equipment. 
              ENTCverse Hub provides automated calibration, damage insurance, and custody tracking—remitting <strong className="text-amber-300 font-bold">65% of rental revenue</strong> directly to equipment owners.
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                step: 'A',
                title: 'Consign Gear',
                desc: 'List your idle oscilloscope, RF kit, or power supply with serial verification.'
              },
              {
                step: 'B',
                title: 'Bench Calibration',
                desc: 'Showroom technicians test input impedance, probe trimmers, and issue calibration seal.'
              },
              {
                step: 'C',
                title: 'Insured Rentals',
                desc: 'Students rent with verified IDs and security deposits. Gear is 100% insured against damage.'
              },
              {
                step: 'D',
                title: '65% Monthly Payout',
                desc: 'Earn recurring passive revenue remitted straight to your bank account with complete transparency.'
              }
            ].map((b, idx) => (
              <div key={idx} className="business-stage p-4 rounded-xl bg-neutral-900/90 border border-amber-500/20 space-y-2 shadow-sm">
                <span className="text-xs font-mono font-bold text-amber-400">STAGE {b.step}</span>
                <h4 className="text-sm font-bold text-white">{b.title}</h4>
                <p className="text-xs text-neutral-400 leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <button
              onClick={onOpenBusinessHub}
              className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:brightness-110 text-black font-extrabold text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>Explore Business Model & Revenue Streams</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* FREQUENTLY ASKED QUESTIONS (FAQ) */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        <div className="space-y-2 text-center">
          <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">HAVE QUESTIONS?</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="mt-8 space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl bg-neutral-950/90 border border-amber-500/25 hover:border-amber-400/60 overflow-hidden shadow-xl shadow-black/40 transition-colors"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-neutral-900/50 transition-colors"
                >
                  <span className={`text-sm sm:text-base font-bold transition-colors ${isOpen ? 'text-amber-300' : 'text-white'}`}>{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-amber-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-neutral-400 shrink-0" />
                  )}
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-neutral-300 leading-relaxed border-t border-amber-500/20 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* SECTION H — FINAL CALL TO ACTION (Obsidian Black & Gold Glow Core) */}
      <section id="section-cta" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
        <div id="section-cta-box" className="relative rounded-3xl overflow-hidden bg-gradient-to-b from-neutral-950 via-[#141209] to-black border border-amber-500/40 p-10 sm:p-16 shadow-2xl shadow-amber-500/10">
          <div className="absolute inset-0 bg-tech-grid opacity-35 pointer-events-none" />

          <div className="relative z-10 max-w-2xl mx-auto space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-neutral-900 border border-amber-500/30 text-xs font-mono font-bold text-amber-300 shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>READY FOR YOUR NEXT SEMESTER BREAKTHROUGH?</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
              Your Next Big Idea Starts Here.
            </h2>

            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
              Don't let missing test gear hold you back. Simulate circuits online for free, pick up calibrated bench instruments at our Pune or Bengaluru showrooms, and turn your capstone ideas into reality.
            </p>

            <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
              <button
                onClick={onExploreEquipment}
                className="px-8 py-4 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:brightness-110 text-black font-extrabold text-sm shadow-xl shadow-amber-500/25 hover:-translate-y-0.5 transition-all flex items-center gap-2 cursor-pointer group"
              >
                <span>Explore Equipment</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onOpenVirtualLab}
                className="px-8 py-4 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-amber-500/40 text-amber-300 font-bold text-sm shadow-sm transition-all hover:-translate-y-0.5 flex items-center gap-2 cursor-pointer"
              >
                <Activity className="w-4 h-4 text-amber-400" />
                <span>Launch Virtual Lab</span>
              </button>
            </div>

            <div className="pt-6 border-t border-amber-500/20 flex flex-wrap items-center justify-center gap-6 text-xs text-neutral-400 font-mono font-medium">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                Zero purchase lock-in
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-amber-400" />
                1-Hour Showroom Pickup
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-amber-400" />
                15% Subsidized Student Discount
              </span>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
