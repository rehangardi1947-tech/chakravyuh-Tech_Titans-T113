import React, { useState } from 'react';
import { 
  Cpu, 
  Menu, 
  X, 
  Search, 
  BookmarkCheck, 
  Bookmark, 
  User, 
  SlidersHorizontal,
  MapPin,
  ShieldAlert,
  DollarSign,
  Bot,
  Play
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  bookingCount: number;
  savedCount: number;
  openBookingHistory: () => void;
  openSavedItems: () => void;
  openAuthModal: () => void;
  openAiMentor?: () => void;
  openJudgeTour?: () => void;
  currentUser: { name: string; role: 'student' | 'owner' | 'admin' } | null;
  setCurrentUser: React.Dispatch<React.SetStateAction<{ name: string; role: 'student' | 'owner' | 'admin' } | null>>;
  onSearchClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  bookingCount,
  savedCount,
  openBookingHistory,
  openSavedItems,
  openAuthModal,
  openAiMentor,
  openJudgeTour,
  currentUser,
  setCurrentUser,
  onSearchClick
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'catalogue', label: 'Equipment Catalogue' },
    { id: 'rentals', label: 'Rent Equipment' },
    { id: 'learn', label: 'Learn ENTC' },
    { id: 'virtual-lab', label: 'Virtual Lab' },
    { id: 'projects', label: 'Projects' },
    { id: 'business-model', label: 'Business Model' },
    { id: 'business', label: 'Owner Hub' },
    { id: 'login', label: 'Login & Database' },
  ];

  if (currentUser?.role === 'admin') {
    navLinks.push({ id: 'admin', label: 'Admin Console' });
  }

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-amber-500/20 bg-[#09090b]/90 backdrop-blur-xl">
      {/* Top micro showroom locator strip in Golden & Black */}
      <div className="hidden lg:flex items-center justify-between px-6 py-1.5 bg-neutral-950 border-b border-amber-500/15 text-[12px] text-neutral-400">
        <div className="flex items-center gap-2">
          <MapPin className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-medium text-neutral-200">Physical Electronics Showroom: Pune Tech Hub, JM Road · Mon-Sun 9AM-8PM</span>
          <span className="text-neutral-700">|</span>
          <span className="text-neutral-400">Bengaluru & Delhi Pickup Counters Active</span>
        </div>
        <div className="flex items-center gap-4 text-neutral-400">
          {openJudgeTour && (
            <button
              onClick={openJudgeTour}
              className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-neutral-900 border border-amber-500/40 text-amber-300 hover:text-white text-[11px] font-bold cursor-pointer transition-all shadow-sm"
            >
              <Play className="w-3 h-3 fill-current text-amber-400" />
              <span>Live Hackathon Demo (10 Steps)</span>
            </button>
          )}
          <span className="text-neutral-700">|</span>
          <span className="font-medium text-amber-200">Student Verification: Flat 15% Off Rentals</span>
          <span className="text-neutral-700">|</span>
          <button 
            onClick={() => setActiveTab('business-model')} 
            className="text-amber-400 font-semibold hover:text-amber-300 transition-colors cursor-pointer"
          >
            Explore 8 Revenue Streams →
          </button>
        </div>
      </div>

      {/* Main Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        {/* Zone 1: Brand Wordmark */}
        <button 
          onClick={() => setActiveTab('home')} 
          className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 group cursor-pointer focus:outline-none"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 flex items-center justify-center text-black shadow-md shadow-amber-500/20 group-hover:scale-105 transition-all">
            <Cpu className="w-5 h-5 text-black" />
          </div>
          <div>
            <span className="text-lg font-extrabold tracking-tight text-white">
              ENTCverse<span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500 font-black ml-1">Hub</span>
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden xl:flex items-center gap-6 text-sm font-medium text-neutral-300">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`whitespace-nowrap shrink-0 transition-colors py-1 relative cursor-pointer ${
                  isActive 
                    ? 'text-amber-400 font-bold' 
                    : 'text-neutral-400 hover:text-amber-200'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-amber-400 to-yellow-500 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onSearchClick}
            title="Search equipment"
            className="p-2 text-neutral-400 hover:text-amber-400 hover:bg-neutral-900 rounded-xl transition-colors cursor-pointer border border-transparent hover:border-amber-500/20"
            aria-label="Search equipment"
          >
            <Search className="w-4 h-4" />
          </button>

          {openJudgeTour && (
            <button
              onClick={openJudgeTour}
              title="Launch Guided Hackathon Demo"
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-amber-300 bg-neutral-900 hover:bg-neutral-800 border border-amber-500/40 rounded-xl transition-all cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
            >
              <Play className="w-3.5 h-3.5 fill-current text-amber-400" />
              <span className="hidden sm:inline">Demo Tour</span>
            </button>
          )}

          {openAiMentor && (
            <button
              onClick={openAiMentor}
              title="Dr. Silicon AI Lab Mentor"
              className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-300 bg-neutral-900/90 hover:bg-neutral-800 border border-amber-500/40 rounded-xl transition-all cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
            >
              <Bot className="w-3.5 h-3.5 text-amber-400" />
              <span>AI Mentor</span>
            </button>
          )}

          {savedCount > 0 && (
            <button
              onClick={openSavedItems}
              title="Saved items"
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-amber-300 bg-neutral-900 border border-amber-500/40 rounded-xl hover:bg-neutral-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-sm"
            >
              <Bookmark className="w-3.5 h-3.5 text-amber-400" />
              <span>{savedCount}</span>
            </button>
          )}

          {bookingCount > 0 && (
            <button
              onClick={openBookingHistory}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-200 bg-neutral-900 border border-amber-500/40 rounded-xl hover:bg-neutral-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-sm"
            >
              <BookmarkCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>{bookingCount} {bookingCount === 1 ? 'Booking' : 'Bookings'}</span>
            </button>
          )}

          {currentUser ? (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  setActiveTab('login');
                }}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-neutral-200 bg-neutral-900 hover:bg-neutral-800 border border-amber-500/30 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-sm"
                title="View Database Profile & Session"
              >
                <User className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden md:inline font-semibold">{currentUser.name}</span>
                <span className="text-[10px] text-amber-400 font-mono uppercase tracking-wider">({currentUser.role})</span>
              </button>

              <button
                onClick={openAuthModal}
                className="text-xs text-neutral-400 hover:text-amber-300 px-2 py-1 rounded-lg bg-neutral-900 border border-neutral-800 transition-colors cursor-pointer"
                title="Switch User Role or Sign In"
              >
                Switch
              </button>
            </div>
          ) : (
            <button
              onClick={() => setActiveTab('login')}
              className="px-3.5 py-1.5 text-xs font-bold text-neutral-950 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 rounded-xl transition-all whitespace-nowrap shrink-0 cursor-pointer shadow-md shadow-amber-500/20"
            >
              Sign In
            </button>
          )}

          {/* Primary Action Button in Metallic Gold */}
          <button
            onClick={() => setActiveTab('catalogue')}
            className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 text-xs font-extrabold text-black bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-400 rounded-xl shadow-md shadow-amber-500/25 transition-all whitespace-nowrap shrink-0 cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Explore Equipment</span>
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 text-neutral-400 hover:text-white hover:bg-neutral-900 rounded-xl cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-amber-500/20 bg-[#09090b] px-4 py-4 space-y-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`block w-full text-left px-3 py-2 rounded-xl text-sm font-medium ${
                activeTab === link.id
                  ? 'bg-amber-500 text-black font-bold'
                  : 'text-neutral-300 hover:bg-neutral-900'
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
};
