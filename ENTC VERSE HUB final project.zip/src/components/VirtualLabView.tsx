import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, 
  RotateCcw, 
  Zap, 
  Cpu, 
  Sliders, 
  CheckCircle2, 
  AlertTriangle,
  Info,
  BookOpen,
  Save,
  Download,
  Trash2,
  ExternalLink,
  Flame,
  Award,
  Layers,
  Thermometer,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { VIRTUAL_EXPERIMENTS } from '../data/virtualExperimentsData';
import { VirtualExperiment, EquipmentItem } from '../types';
import { storageService } from '../services/storageService';

interface VirtualLabViewProps {
  onRentEquipment?: (item: EquipmentItem) => void;
  onViewEquipmentDetail?: (item: EquipmentItem) => void;
}

export const VirtualLabView: React.FC<VirtualLabViewProps> = ({
  onRentEquipment,
  onViewEquipmentDetail
}) => {
  const [selectedExpId, setSelectedExpId] = useState<string>('exp-led-resistor');
  const [activeTab, setActiveTab] = useState<'simulation' | 'schematic' | 'checklist'>('simulation');

  // Gamification & Completion state
  const [gamification, setGamification] = useState(() => storageService.getGamificationState());
  const [savedConfigs, setSavedConfigs] = useState(() => storageService.getSavedExperimentConfigs());
  const [configName, setConfigName] = useState('');
  const [showSaveModal, setShowSaveModal] = useState(false);

  // Active experiment entity
  const currentExperiment = VIRTUAL_EXPERIMENTS.find(e => e.id === selectedExpId) || VIRTUAL_EXPERIMENTS[0];
  const isCompleted = gamification.completedExperimentIds.includes(currentExperiment.id);

  // ----------------------------------------------------
  // CIRCUIT 1: LED & Resistor
  // ----------------------------------------------------
  const [c1_vSupply, setC1_VSupply] = useState<number>(5.0);
  const [c1_resistor, setC1_Resistor] = useState<number>(330);
  const [c1_ledType, setC1_LedType] = useState<'red' | 'green' | 'blue'>('red');
  const ledVfMap = { red: 2.0, green: 2.2, blue: 3.2 };
  const c1_vf = ledVfMap[c1_ledType];
  const c1_current_mA = c1_vSupply > c1_vf ? ((c1_vSupply - c1_vf) / c1_resistor) * 1000 : 0;
  const c1_power_mW = Math.pow(c1_current_mA / 1000, 2) * c1_resistor * 1000;
  const c1_isBurnedOut = c1_current_mA > 35; // Standard 5mm LED max is 25-30mA
  const c1_isWarning = c1_current_mA > 25 && !c1_isBurnedOut;

  // ----------------------------------------------------
  // CIRCUIT 2: Series & Parallel Networks
  // ----------------------------------------------------
  const [c2_mode, setC2_Mode] = useState<'series' | 'parallel'>('series');
  const [c2_vin, setC2_Vin] = useState<number>(12);
  const [c2_r1, setC2_R1] = useState<number>(1000);
  const [c2_r2, setC2_R2] = useState<number>(2000);

  const c2_req = c2_mode === 'series' ? c2_r1 + c2_r2 : (c2_r1 * c2_r2) / (c2_r1 + c2_r2);
  const c2_iTotal_mA = c2_req > 0 ? (c2_vin / c2_req) * 1000 : 0;
  const c2_v1 = c2_mode === 'series' ? c2_vin * (c2_r1 / (c2_r1 + c2_r2)) : c2_vin;
  const c2_v2 = c2_mode === 'series' ? c2_vin * (c2_r2 / (c2_r1 + c2_r2)) : c2_vin;
  const c2_i1_mA = (c2_v1 / c2_r1) * 1000;
  const c2_i2_mA = (c2_v2 / c2_r2) * 1000;

  // ----------------------------------------------------
  // CIRCUIT 3: Ohm's Law Verification
  // ----------------------------------------------------
  const [c3_voltage, setC3_Voltage] = useState<number>(10);
  const [c3_resistance, setC3_Resistance] = useState<number>(500);
  const c3_current_mA = (c3_voltage / c3_resistance) * 1000;
  const c3_power_W = (c3_voltage * c3_current_mA) / 1000;

  // ----------------------------------------------------
  // CIRCUIT 4: Voltage Divider
  // ----------------------------------------------------
  const [c4_vin, setC4_Vin] = useState<number>(10);
  const [c4_r1, setC4_R1] = useState<number>(10000); // 10k
  const [c4_r2, setC4_R2] = useState<number>(10000); // 10k
  const [c4_isLoaded, setC4_IsLoaded] = useState<boolean>(false);
  const [c4_rLoad, setC4_RLoad] = useState<number>(10000); // 10k load

  const c4_r2_effective = c4_isLoaded ? (c4_r2 * c4_rLoad) / (c4_r2 + c4_rLoad) : c4_r2;
  const c4_vout = c4_vin * (c4_r2_effective / (c4_r1 + c4_r2_effective));
  const c4_unloaded_vout = c4_vin * (c4_r2 / (c4_r1 + c4_r2));
  const c4_loading_error = Math.abs(c4_unloaded_vout - c4_vout);

  // ----------------------------------------------------
  // CIRCUIT 5: Transistor Switch (BJT NPN)
  // ----------------------------------------------------
  const [c5_baseInput, setC5_BaseInput] = useState<boolean>(true); // 5V vs 0V
  const [c5_rb, setC5_Rb] = useState<number>(4700); // 4.7k
  const [c5_vcc, setC5_Vcc] = useState<number>(12);
  const [c5_rLoad, setC5_RLoad] = useState<number>(100); // 100 ohm load (lamp)
  const c5_vbe = 0.7;
  const c5_ib_mA = c5_baseInput ? Math.max(0, ((5.0 - c5_vbe) / c5_rb) * 1000) : 0;
  const c5_beta = 100;
  const c5_ic_max_mA = (c5_vcc - 0.2) / c5_rLoad * 1000;
  const c5_ic_active_mA = c5_ib_mA * c5_beta;
  const c5_isSaturated = c5_ic_active_mA >= c5_ic_max_mA;
  const c5_ic_actual_mA = c5_baseInput ? (c5_isSaturated ? c5_ic_max_mA : c5_ic_active_mA) : 0;
  const c5_vce = c5_baseInput ? (c5_isSaturated ? 0.2 : c5_vcc - (c5_ic_actual_mA / 1000 * c5_rLoad)) : c5_vcc;

  // ----------------------------------------------------
  // CIRCUIT 6: Logic Gates
  // ----------------------------------------------------
  const [c6_gate, setC6_Gate] = useState<'AND' | 'OR' | 'NOT' | 'NAND' | 'NOR' | 'XOR'>('AND');
  const [c6_inA, setC6_InA] = useState<boolean>(true);
  const [c6_inB, setC6_InB] = useState<boolean>(false);

  const c6_out = (() => {
    switch (c6_gate) {
      case 'AND': return c6_inA && c6_inB;
      case 'OR': return c6_inA || c6_inB;
      case 'NOT': return !c6_inA;
      case 'NAND': return !(c6_inA && c6_inB);
      case 'NOR': return !(c6_inA || c6_inB);
      case 'XOR': return c6_inA !== c6_inB;
    }
  })();

  // ----------------------------------------------------
  // CIRCUIT 7: Temperature Sensor & Fan Controller
  // ----------------------------------------------------
  const [c7_ambientTemp, setC7_AmbientTemp] = useState<number>(35); // 35°C
  const [c7_setpoint, setC7_Setpoint] = useState<number>(40); // 40°C
  const [c7_hysteresis, setC7_Hysteresis] = useState<boolean>(true);
  const c7_sensorMv = c7_ambientTemp * 10; // 10mV / °C for LM35
  const c7_thresholdMv = c7_setpoint * 10;
  const c7_fanActive = c7_hysteresis 
    ? c7_ambientTemp >= c7_setpoint 
    : c7_sensorMv > c7_thresholdMv;
  const c7_fanRpm = c7_fanActive ? Math.min(3200, 1800 + (c7_ambientTemp - c7_setpoint) * 80) : 0;

  // ----------------------------------------------------
  // CIRCUIT 8: MCU I/O & PWM
  // ----------------------------------------------------
  const [c8_buttonPressed, setC8_ButtonPressed] = useState<boolean>(false);
  const [c8_usePullup, setC8_UsePullup] = useState<boolean>(true);
  const [c8_pwmDuty, setC8_PwmDuty] = useState<number>(50); // 50%
  const [c8_pwmFreq, setC8_PwmFreq] = useState<number>(1000); // 1kHz
  const c8_pinReading = c8_usePullup ? (c8_buttonPressed ? 0 : 1) : (c8_buttonPressed ? 1 : 0);
  const c8_avgVout = (3.3 * (c8_pwmDuty / 100));

  // Canvas waveform ref for PWM & Ohm's law
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear background
    ctx.fillStyle = '#060a12';
    ctx.fillRect(0, 0, width, height);

    // Draw Grid
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 30) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    if (currentExperiment.circuitType === 'mcu_io') {
      // Draw PWM Square wave
      ctx.strokeStyle = '#22d3ee';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      const periodPx = 80;
      const highPx = periodPx * (c8_pwmDuty / 100);
      const lowY = height - 25;
      const highY = 25;

      for (let x = 10; x < width - 10; x += periodPx) {
        ctx.moveTo(x, lowY);
        ctx.lineTo(x, highY);
        ctx.lineTo(Math.min(x + highPx, width - 10), highY);
        ctx.lineTo(Math.min(x + highPx, width - 10), lowY);
        ctx.lineTo(Math.min(x + periodPx, width - 10), lowY);
      }
      ctx.stroke();

      // Label
      ctx.fillStyle = '#38bdf8';
      ctx.font = '10px monospace';
      ctx.fillText(`Duty: ${c8_pwmDuty}% | Freq: ${c8_pwmFreq}Hz | Avg V: ${c8_avgVout.toFixed(2)}V`, 12, 16);
    } else if (currentExperiment.circuitType === 'ohms_law') {
      // Draw V-I Line
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(30, height - 25);
      // Slope: I = V / R
      const maxV = 30;
      const maxI = (maxV / c3_resistance) * 1000;
      const currentX = 30 + (c3_voltage / maxV) * (width - 60);
      const currentY = (height - 25) - ((c3_current_mA / (maxI || 1)) * (height - 50));
      
      ctx.lineTo(width - 30, 25);
      ctx.stroke();

      // Operating point dot
      ctx.fillStyle = '#34d399';
      ctx.beginPath();
      ctx.arc(currentX, currentY, 6, 0, 2 * Math.PI);
      ctx.fill();

      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.fillText(`V = ${c3_voltage}V | I = ${c3_current_mA.toFixed(1)} mA | R = ${c3_resistance} Ω`, 12, 16);
    }
  }, [currentExperiment.circuitType, c8_pwmDuty, c8_pwmFreq, c8_avgVout, c3_voltage, c3_resistance, c3_current_mA]);

  const handleMarkComplete = () => {
    storageService.completeExperiment(currentExperiment.id);
    setGamification(storageService.getGamificationState());
  };

  const handleSaveConfig = () => {
    if (!configName.trim()) return;
    const stateObj = {
      c1: { c1_vSupply, c1_resistor, c1_ledType },
      c2: { c2_mode, c2_vin, c2_r1, c2_r2 },
      c3: { c3_voltage, c3_resistance },
      c4: { c4_vin, c4_r1, c4_r2, c4_isLoaded, c4_rLoad },
      c5: { c5_baseInput, c5_rb, c5_vcc, c5_rLoad },
      c6: { c6_gate, c6_inA, c6_inB },
      c7: { c7_ambientTemp, c7_setpoint, c7_hysteresis },
      c8: { c8_buttonPressed, c8_usePullup, c8_pwmDuty, c8_pwmFreq }
    };

    storageService.saveExperimentConfig({
      id: `cfg-${Date.now()}`,
      name: configName.trim(),
      experimentId: currentExperiment.id,
      date: new Date().toLocaleDateString(),
      state: stateObj
    });

    setSavedConfigs(storageService.getSavedExperimentConfigs());
    setConfigName('');
    setShowSaveModal(false);
  };

  const handleLoadConfig = (cfg: (typeof savedConfigs)[0]) => {
    setSelectedExpId(cfg.experimentId);
    const s = cfg.state as any;
    if (s.c1) {
      setC1_VSupply(s.c1.c1_vSupply);
      setC1_Resistor(s.c1.c1_resistor);
      setC1_LedType(s.c1.c1_ledType);
    }
    if (s.c2) {
      setC2_Mode(s.c2.c2_mode);
      setC2_Vin(s.c2.c2_vin);
      setC2_R1(s.c2.c2_r1);
      setC2_R2(s.c2.c2_r2);
    }
    if (s.c3) {
      setC3_Voltage(s.c3.c3_voltage);
      setC3_Resistance(s.c3.c3_resistance);
    }
    if (s.c4) {
      setC4_Vin(s.c4.c4_vin);
      setC4_R1(s.c4.c4_r1);
      setC4_R2(s.c4.c4_r2);
      setC4_IsLoaded(s.c4.c4_isLoaded);
      setC4_RLoad(s.c4.c4_rLoad);
    }
    if (s.c5) {
      setC5_BaseInput(s.c5.c5_baseInput);
      setC5_Rb(s.c5.c5_rb);
      setC5_Vcc(s.c5.c5_vcc);
      setC5_RLoad(s.c5.c5_rLoad);
    }
    if (s.c6) {
      setC6_Gate(s.c6.c6_gate);
      setC6_InA(s.c6.c6_inA);
      setC6_InB(s.c6.c6_inB);
    }
    if (s.c7) {
      setC7_AmbientTemp(s.c7.c7_ambientTemp);
      setC7_Setpoint(s.c7.c7_setpoint);
      setC7_Hysteresis(s.c7.c7_hysteresis);
    }
    if (s.c8) {
      setC8_ButtonPressed(s.c8.c8_buttonPressed);
      setC8_UsePullup(s.c8.c8_usePullup);
      setC8_PwmDuty(s.c8.c8_pwmDuty);
      setC8_PwmFreq(s.c8.c8_pwmFreq);
    }
  };

  const handleResetCurrent = () => {
    if (currentExperiment.circuitType === 'led_resistor') {
      setC1_VSupply(5.0);
      setC1_Resistor(330);
      setC1_LedType('red');
    } else if (currentExperiment.circuitType === 'series_parallel') {
      setC2_Mode('series');
      setC2_Vin(12);
      setC2_R1(1000);
      setC2_R2(2000);
    } else if (currentExperiment.circuitType === 'ohms_law') {
      setC3_Voltage(10);
      setC3_Resistance(500);
    } else if (currentExperiment.circuitType === 'voltage_divider') {
      setC4_Vin(10);
      setC4_R1(10000);
      setC4_R2(10000);
      setC4_IsLoaded(false);
    } else if (currentExperiment.circuitType === 'transistor_switch') {
      setC5_BaseInput(true);
      setC5_Rb(4700);
      setC5_Vcc(12);
      setC5_RLoad(100);
    } else if (currentExperiment.circuitType === 'logic_gates') {
      setC6_Gate('AND');
      setC6_InA(true);
      setC6_InB(false);
    } else if (currentExperiment.circuitType === 'temp_fan') {
      setC7_AmbientTemp(35);
      setC7_Setpoint(40);
      setC7_Hysteresis(true);
    } else if (currentExperiment.circuitType === 'mcu_io') {
      setC8_ButtonPressed(false);
      setC8_UsePullup(true);
      setC8_PwmDuty(50);
      setC8_PwmFreq(1000);
    }
  };

  // Find related equipment item for rental linking
  const relatedItem = storageService.getEquipmentById(currentExperiment.relatedEquipmentId);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-left">
      {/* Title & Gamification Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono mb-1">
            <Activity className="w-4 h-4" />
            <span>INTERACTIVE VIRTUAL ELECTRONICS LAB</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Safe Circuit Sandbox & Measurement Engine
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
            Simulate real circuit physics before wiring physical hardware. Practice experiments, observe mathematical readouts, and identify wiring errors without damaging components.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start md:self-auto">
          {/* XP Badge */}
          <div className="px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 flex items-center gap-2 text-xs font-mono">
            <Award className="w-4 h-4 text-amber-400" />
            <span className="text-slate-300">Level {gamification.level}</span>
            <span className="text-cyan-400 font-bold">{gamification.xp} XP</span>
          </div>

          <button
            onClick={() => setShowSaveModal(true)}
            className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save State</span>
          </button>
        </div>
      </div>

      {/* Software Simulation vs Real Lab Disclaimer Banner */}
      <div className="p-4 rounded-xl bg-slate-900/90 border border-cyan-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-300">
        <div className="flex items-start gap-2.5">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-white">Software Calculation vs. Physical Bench Measurements: </span>
            This simulator applies theoretical formulas (ideal diodes, lossless wires, nominal resistor values). Real physical components feature ±5% manufacturing tolerances, temperature coefficient drift, and parasitics. Verify with physical showroom instruments!
          </div>
        </div>

        {relatedItem && (
          <button
            onClick={() => onRentEquipment ? onRentEquipment(relatedItem) : null}
            className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shrink-0 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Rent Real {relatedItem.name.split(' ')[0]} Kit</span>
          </button>
        )}
      </div>

      {/* 8 Experiment Selector Carousel */}
      <div>
        <div className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">
          Select an ENTC Lab Experiment:
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          {VIRTUAL_EXPERIMENTS.map((exp, idx) => {
            const isSel = exp.id === selectedExpId;
            const isDone = gamification.completedExperimentIds.includes(exp.id);
            return (
              <button
                key={exp.id}
                onClick={() => setSelectedExpId(exp.id)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between h-24 ${
                  isSel
                    ? 'bg-cyan-500/15 border-cyan-500 text-white shadow-sm shadow-cyan-500/20'
                    : 'bg-slate-900/70 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-cyan-400">EXP 0{idx + 1}</span>
                  {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                </div>
                <div className="text-xs font-semibold line-clamp-2 mt-1">
                  {exp.title.replace(/^\d+\.\s*/, '')}
                </div>
                <span className="text-[9px] text-slate-300 font-mono">{exp.difficulty}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Experiment Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Interactive Controls & Parameters */}
        <div className="lg:col-span-1 bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Circuit Parameters</span>
            </div>
            <button
              onClick={handleResetCurrent}
              className="text-xs text-slate-400 hover:text-cyan-400 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>

          {/* DYNAMIC CONTROLS PER CIRCUIT */}
          {currentExperiment.circuitType === 'led_resistor' && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>DC Supply Voltage (V):</span>
                  <span className="font-mono text-cyan-300">{c1_vSupply.toFixed(1)} V</span>
                </label>
                <input
                  type="range"
                  min="1"
                  max="12"
                  step="0.5"
                  value={c1_vSupply}
                  onChange={(e) => setC1_VSupply(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Current-Limiting Resistor:</span>
                  <span className="font-mono text-cyan-300">{c1_resistor} Ω</span>
                </label>
                <input
                  type="range"
                  min="20"
                  max="1000"
                  step="10"
                  value={c1_resistor}
                  onChange={(e) => setC1_Resistor(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-300 mt-1">
                  <span>20Ω (Dangerous)</span>
                  <span>330Ω (Standard)</span>
                  <span>1kΩ (Dim)</span>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">LED Color & Forward Drop:</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['red', 'green', 'blue'] as const).map((color) => (
                    <button
                      key={color}
                      onClick={() => setC1_LedType(color)}
                      className={`py-1.5 text-xs font-semibold rounded-lg capitalize border transition-all cursor-pointer ${
                        c1_ledType === color
                          ? 'bg-slate-800 text-white border-cyan-400'
                          : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      {color} ({ledVfMap[color]}V)
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {currentExperiment.circuitType === 'series_parallel' && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Network Topology:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setC2_Mode('series')}
                    className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      c2_mode === 'series'
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    Series (R1 + R2)
                  </button>
                  <button
                    onClick={() => setC2_Mode('parallel')}
                    className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      c2_mode === 'parallel'
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    Parallel (R1 || R2)
                  </button>
                </div>
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Supply Voltage (Vin):</span>
                  <span className="font-mono text-cyan-300">{c2_vin} V</span>
                </label>
                <input
                  type="range"
                  min="2"
                  max="24"
                  step="1"
                  value={c2_vin}
                  onChange={(e) => setC2_Vin(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Resistor R1:</span>
                  <span className="font-mono text-cyan-300">{c2_r1} Ω</span>
                </label>
                <input
                  type="range"
                  min="100"
                  max="5000"
                  step="100"
                  value={c2_r1}
                  onChange={(e) => setC2_R1(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Resistor R2:</span>
                  <span className="font-mono text-cyan-300">{c2_r2} Ω</span>
                </label>
                <input
                  type="range"
                  min="100"
                  max="5000"
                  step="100"
                  value={c2_r2}
                  onChange={(e) => setC2_R2(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>
          )}

          {currentExperiment.circuitType === 'ohms_law' && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Adjustable Bench Voltage:</span>
                  <span className="font-mono text-cyan-300">{c3_voltage} V</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="30"
                  step="1"
                  value={c3_voltage}
                  onChange={(e) => setC3_Voltage(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Select Test Resistor Value:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[100, 220, 500, 1000, 2200, 4700].map((val) => (
                    <button
                      key={val}
                      onClick={() => setC3_Resistance(val)}
                      className={`py-1.5 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                        c3_resistance === val
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                          : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      {val >= 1000 ? `${val / 1000}kΩ` : `${val}Ω`}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {currentExperiment.circuitType === 'voltage_divider' && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Input Rail Voltage (Vin):</span>
                  <span className="font-mono text-cyan-300">{c4_vin} V</span>
                </label>
                <input
                  type="range"
                  min="1"
                  max="24"
                  step="1"
                  value={c4_vin}
                  onChange={(e) => setC4_Vin(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>R1 (Upper Divider Arm):</span>
                  <span className="font-mono text-cyan-300">{(c4_r1 / 1000).toFixed(1)} kΩ</span>
                </label>
                <input
                  type="range"
                  min="1000"
                  max="50000"
                  step="1000"
                  value={c4_r1}
                  onChange={(e) => setC4_R1(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>R2 (Lower Divider Arm):</span>
                  <span className="font-mono text-cyan-300">{(c4_r2 / 1000).toFixed(1)} kΩ</span>
                </label>
                <input
                  type="range"
                  min="1000"
                  max="50000"
                  step="1000"
                  value={c4_r2}
                  onChange={(e) => setC4_R2(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="pt-2 border-t border-slate-800">
                <label className="flex items-center justify-between text-slate-300 mb-2 cursor-pointer">
                  <span>Attach External Load (R_L):</span>
                  <input
                    type="checkbox"
                    checked={c4_isLoaded}
                    onChange={(e) => setC4_IsLoaded(e.target.checked)}
                    className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
                  />
                </label>
                {c4_isLoaded && (
                  <div>
                    <label className="flex justify-between text-slate-400 mb-1">
                      <span>Load Resistance R_L:</span>
                      <span className="font-mono text-amber-300">{(c4_rLoad / 1000).toFixed(1)} kΩ</span>
                    </label>
                    <input
                      type="range"
                      min="1000"
                      max="50000"
                      step="1000"
                      value={c4_rLoad}
                      onChange={(e) => setC4_RLoad(parseInt(e.target.value))}
                      className="w-full accent-amber-400 cursor-pointer"
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {currentExperiment.circuitType === 'transistor_switch' && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Digital Base Logic Control:</label>
                <button
                  onClick={() => setC5_BaseInput(!c5_baseInput)}
                  className={`w-full py-2.5 rounded-xl font-bold border flex items-center justify-center gap-2 cursor-pointer transition-all ${
                    c5_baseInput
                      ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  {c5_baseInput ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
                  <span>{c5_baseInput ? 'LOGIC HIGH (+5.0V ON)' : 'LOGIC LOW (0.0V OFF)'}</span>
                </button>
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Base Resistor (Rb):</span>
                  <span className="font-mono text-cyan-300">{(c5_rb / 1000).toFixed(1)} kΩ</span>
                </label>
                <input
                  type="range"
                  min="1000"
                  max="20000"
                  step="500"
                  value={c5_rb}
                  onChange={(e) => setC5_Rb(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Collector Load Supply (Vcc):</span>
                  <span className="font-mono text-cyan-300">{c5_vcc} V</span>
                </label>
                <input
                  type="range"
                  min="5"
                  max="24"
                  step="1"
                  value={c5_vcc}
                  onChange={(e) => setC5_Vcc(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>
          )}

          {currentExperiment.circuitType === 'logic_gates' && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Select Logic Function:</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['AND', 'OR', 'NOT', 'NAND', 'NOR', 'XOR'] as const).map((g) => (
                    <button
                      key={g}
                      onClick={() => setC6_Gate(g)}
                      className={`py-1.5 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                        c6_gate === g
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500'
                          : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      {g} Gate
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <div>
                  <span className="block text-slate-400 mb-1 font-mono">Input Switch A:</span>
                  <button
                    onClick={() => setC6_InA(!c6_inA)}
                    className={`w-full py-2 rounded-xl font-bold border transition-all cursor-pointer ${
                      c6_inA
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    State: {c6_inA ? '1 (HIGH)' : '0 (LOW)'}
                  </button>
                </div>

                {c6_gate !== 'NOT' && (
                  <div>
                    <span className="block text-slate-400 mb-1 font-mono">Input Switch B:</span>
                    <button
                      onClick={() => setC6_InB(!c6_inB)}
                      className={`w-full py-2 rounded-xl font-bold border transition-all cursor-pointer ${
                        c6_inB
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                          : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      State: {c6_inB ? '1 (HIGH)' : '0 (LOW)'}
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {currentExperiment.circuitType === 'temp_fan' && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Ambient Chamber Temperature:</span>
                  <span className="font-mono text-amber-300">{c7_ambientTemp} °C</span>
                </label>
                <input
                  type="range"
                  min="15"
                  max="70"
                  step="1"
                  value={c7_ambientTemp}
                  onChange={(e) => setC7_AmbientTemp(parseInt(e.target.value))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>Comparator Trigger Setpoint (Potentiometer):</span>
                  <span className="font-mono text-cyan-300">{c7_setpoint} °C</span>
                </label>
                <input
                  type="range"
                  min="25"
                  max="55"
                  step="1"
                  value={c7_setpoint}
                  onChange={(e) => setC7_Setpoint(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div className="pt-2 border-t border-slate-800">
                <label className="flex items-center justify-between text-slate-300 cursor-pointer">
                  <span>Schmitt Trigger Hysteresis (Anti-Chatter):</span>
                  <input
                    type="checkbox"
                    checked={c7_hysteresis}
                    onChange={(e) => setC7_Hysteresis(e.target.checked)}
                    className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
                  />
                </label>
              </div>
            </div>
          )}

          {currentExperiment.circuitType === 'mcu_io' && (
            <div className="space-y-4 text-xs">
              <div>
                <span className="block text-slate-300 mb-1">Tactile Push Button Input:</span>
                <button
                  onMouseDown={() => setC8_ButtonPressed(true)}
                  onMouseUp={() => setC8_ButtonPressed(false)}
                  onTouchStart={() => setC8_ButtonPressed(true)}
                  onTouchEnd={() => setC8_ButtonPressed(false)}
                  className={`w-full py-3 rounded-xl font-bold border transition-all cursor-pointer active:scale-98 ${
                    c8_buttonPressed
                      ? 'bg-amber-400 text-slate-950 border-amber-300'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {c8_buttonPressed ? 'BUTTON PRESSED (CONNECTED TO GND)' : 'HOLD TO PRESS BUTTON'}
                </button>
              </div>

              <div>
                <label className="flex items-center justify-between text-slate-300 cursor-pointer">
                  <span>Enable Internal INPUT_PULLUP:</span>
                  <input
                    type="checkbox"
                    checked={c8_usePullup}
                    onChange={(e) => setC8_UsePullup(e.target.checked)}
                    className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
                  />
                </label>
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>PWM Duty Cycle (Dimmer):</span>
                  <span className="font-mono text-cyan-300">{c8_pwmDuty} %</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={c8_pwmDuty}
                  onChange={(e) => setC8_PwmDuty(parseInt(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <label className="flex justify-between text-slate-300 mb-1">
                  <span>PWM Frequency:</span>
                  <span className="font-mono text-cyan-300">{c8_pwmFreq} Hz</span>
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[500, 1000, 5000].map((f) => (
                    <button
                      key={f}
                      onClick={() => setC8_PwmFreq(f)}
                      className={`py-1 text-xs rounded-lg border transition-all cursor-pointer ${
                        c8_pwmFreq === f
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500'
                          : 'bg-slate-950 text-slate-400 border-slate-800'
                      }`}
                    >
                      {f >= 1000 ? `${f / 1000}kHz` : `${f}Hz`}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Mark Completed Button */}
          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={handleMarkComplete}
              disabled={isCompleted}
              className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                isCompleted
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default'
                  : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold shadow-md shadow-cyan-500/20'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isCompleted ? 'Experiment Completed (+150 XP)' : 'Mark Experiment Completed (+150 XP)'}</span>
            </button>
          </div>
        </div>

        {/* Center & Right Columns: Live Visualizer & Electrical Measurements */}
        <div className="lg:col-span-2 space-y-6">
          {/* Main Visualizer Stage */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-xs font-mono font-bold text-white tracking-wider uppercase">
                  Live Electrical Simulation · {currentExperiment.title}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                <span>Calc Engine: v3.2-Reactive</span>
              </div>
            </div>

            {/* CIRCUIT VISUALIZATIONS */}
            {currentExperiment.circuitType === 'led_resistor' && (
              <div className="py-6 flex flex-col items-center justify-center space-y-6">
                {/* Visual breadboard style circuit */}
                <div className="w-full max-w-md p-6 bg-slate-950 rounded-2xl border border-slate-800 relative flex items-center justify-around">
                  {/* Power Source */}
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] font-mono text-slate-400">DC SUPPLY</span>
                    <div className="w-12 h-14 rounded-lg bg-slate-800 border border-slate-700 flex flex-col items-center justify-center text-cyan-400 font-mono font-bold text-xs mt-1">
                      <span>+{c1_vSupply}V</span>
                      <span className="text-[9px] text-slate-400">0V</span>
                    </div>
                  </div>

                  {/* Wire */}
                  <div className="h-0.5 flex-1 bg-cyan-400/80 mx-2 relative">
                    <span className="absolute -top-4 left-1/2 -translate-x-1/2 text-[9px] font-mono text-slate-400">
                      {c1_current_mA.toFixed(1)} mA
                    </span>
                  </div>

                  {/* Resistor */}
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] font-mono text-slate-400">RESISTOR</span>
                    <div className="px-3 py-1.5 rounded bg-amber-900/40 border border-amber-600 text-amber-300 font-mono text-xs mt-1">
                      {c1_resistor} Ω
                    </div>
                  </div>

                  {/* Wire */}
                  <div className="h-0.5 flex-1 bg-cyan-400/80 mx-2"></div>

                  {/* LED Component */}
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] font-mono text-slate-400 uppercase">
                      {c1_ledType} LED
                    </span>
                    <div 
                      className={`w-10 h-10 rounded-full border flex items-center justify-center mt-1 transition-all ${
                        c1_isBurnedOut
                          ? 'bg-slate-900 border-red-500 text-red-500 shadow-lg shadow-red-500/50'
                          : c1_current_mA > 0.5
                          ? c1_ledType === 'red'
                            ? 'bg-red-500 border-red-300 text-white shadow-xl shadow-red-500/80'
                            : c1_ledType === 'green'
                            ? 'bg-emerald-500 border-emerald-300 text-white shadow-xl shadow-emerald-500/80'
                            : 'bg-blue-500 border-blue-300 text-white shadow-xl shadow-blue-500/80'
                          : 'bg-slate-900 border-slate-700 text-slate-400'
                      }`}
                      style={{
                        opacity: c1_isBurnedOut ? 1 : Math.min(1, Math.max(0.2, c1_current_mA / 15))
                      }}
                    >
                      {c1_isBurnedOut ? (
                        <Flame className="w-5 h-5 text-red-400 animate-bounce" />
                      ) : (
                        <Zap className="w-5 h-5" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Overload Warning Banner */}
                {c1_isBurnedOut ? (
                  <div className="w-full p-3 rounded-xl bg-red-950/80 border border-red-500/60 text-red-200 text-xs flex items-center gap-2">
                    <Flame className="w-5 h-5 text-red-400 shrink-0" />
                    <div>
                      <span className="font-bold">COMPONENT DESTROYED: </span>
                      Current reached {c1_current_mA.toFixed(1)} mA (maximum rating is 25 mA). In a real lab, this LED would smoke and pop! Increase resistance immediately.
                    </div>
                  </div>
                ) : c1_isWarning ? (
                  <div className="w-full p-3 rounded-xl bg-amber-950/80 border border-amber-500/60 text-amber-200 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Warning: Current is {c1_current_mA.toFixed(1)} mA, operating close to maximum thermal junction threshold.</span>
                  </div>
                ) : (
                  <div className="w-full p-3 rounded-xl bg-slate-950 text-slate-300 border border-slate-800 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Operating in safe continuous conduction region ({c1_current_mA.toFixed(1)} mA).</span>
                  </div>
                )}
              </div>
            )}

            {currentExperiment.circuitType === 'series_parallel' && (
              <div className="py-4 space-y-4">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300">
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-bold text-white uppercase">{c2_mode} Resistor Analysis:</span>
                    <span className="font-mono text-cyan-400">Equivalent R_eq = {c2_req.toFixed(1)} Ω</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Total Current (It)</span>
                      <span className="text-sm font-bold text-white">{c2_iTotal_mA.toFixed(1)} mA</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">V across R1</span>
                      <span className="text-sm font-bold text-cyan-300">{c2_v1.toFixed(2)} V</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">V across R2</span>
                      <span className="text-sm font-bold text-cyan-300">{c2_v2.toFixed(2)} V</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Branch 1 Current</span>
                      <span className="text-sm font-bold text-emerald-300">{c2_i1_mA.toFixed(1)} mA</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentExperiment.circuitType === 'ohms_law' && (
              <div className="py-2 space-y-3">
                <canvas
                  ref={canvasRef}
                  width={600}
                  height={180}
                  className="w-full h-44 rounded-xl border border-slate-800 bg-[#060a12]"
                />
                <div className="text-[11px] text-slate-400 text-center font-mono">
                  Real-Time I-V Characteristic Curve: Slope = Conductance (1/R) = {(1 / c3_resistance).toFixed(5)} S
                </div>
              </div>
            )}

            {currentExperiment.circuitType === 'voltage_divider' && (
              <div className="py-4 space-y-4">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono">
                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Unloaded Output (Ideal)</span>
                      <span className="text-base font-bold text-emerald-400">{c4_unloaded_vout.toFixed(2)} V</span>
                      <span className="text-[9px] text-slate-300 block mt-1">Vin × R2 / (R1 + R2)</span>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Actual Loaded Output</span>
                      <span className="text-base font-bold text-cyan-400">{c4_vout.toFixed(2)} V</span>
                      <span className="text-[9px] text-slate-300 block mt-1">
                        {c4_isLoaded ? `With ${c4_rLoad / 1000}kΩ load tap` : 'No load attached'}
                      </span>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Voltage Loading Sag</span>
                      <span className={`text-base font-bold ${c4_loading_error > 0.5 ? 'text-amber-400' : 'text-slate-300'}`}>
                        {c4_loading_error.toFixed(2)} V
                      </span>
                      <span className="text-[9px] text-slate-300 block mt-1">
                        {c4_isLoaded ? `${((c4_loading_error / c4_unloaded_vout) * 100).toFixed(1)}% drop` : '0% error'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentExperiment.circuitType === 'transistor_switch' && (
              <div className="py-4 space-y-4">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-bold text-white">BJT Operating State:</span>
                    <span className={`px-2.5 py-0.5 rounded-full font-mono font-bold text-[11px] ${
                      !c5_baseInput
                        ? 'bg-slate-800 text-slate-400'
                        : c5_isSaturated
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}>
                      {!c5_baseInput ? 'CUT-OFF (OPEN SWITCH)' : c5_isSaturated ? 'SATURATION (CLOSED SWITCH)' : 'ACTIVE LINEAR'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Base Current (Ib)</span>
                      <span className="text-sm font-bold text-white">{c5_ib_mA.toFixed(2)} mA</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Collector Current (Ic)</span>
                      <span className="text-sm font-bold text-cyan-300">{c5_ic_actual_mA.toFixed(1)} mA</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Vce Voltage Drop</span>
                      <span className="text-sm font-bold text-emerald-300">{c5_vce.toFixed(2)} V</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Load Lamp State</span>
                      <span className="text-sm font-bold text-amber-300">
                        {c5_ic_actual_mA > 10 ? 'ILLUMINATED' : 'OFF'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentExperiment.circuitType === 'logic_gates' && (
              <div className="py-4 space-y-4">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-bold text-white uppercase">{c6_gate} Truth Table Verification</span>
                    <span className={`px-3 py-1 rounded-lg font-mono font-bold text-xs ${
                      c6_out ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500' : 'bg-slate-800 text-slate-400'
                    }`}>
                      Output Y = {c6_out ? '1 (HIGH)' : '0 (LOW)'}
                    </span>
                  </div>

                  {/* Truth Table */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-center text-xs font-mono">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400">
                          <th className="py-1 px-3">Input A</th>
                          {c6_gate !== 'NOT' && <th className="py-1 px-3">Input B</th>}
                          <th className="py-1 px-3">Expected Output Y</th>
                          <th className="py-1 px-3">Live State</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          { a: false, b: false },
                          { a: false, b: true },
                          { a: true, b: false },
                          { a: true, b: true }
                        ].filter(row => c6_gate !== 'NOT' || !row.b).map((row, rIdx) => {
                          const rowOut = (() => {
                            switch (c6_gate) {
                              case 'AND': return row.a && row.b;
                              case 'OR': return row.a || row.b;
                              case 'NOT': return !row.a;
                              case 'NAND': return !(row.a && row.b);
                              case 'NOR': return !(row.a || row.b);
                              case 'XOR': return row.a !== row.b;
                            }
                          })();
                          const isCurrentActiveRow = row.a === c6_inA && (c6_gate === 'NOT' || row.b === c6_inB);

                          return (
                            <tr
                              key={rIdx}
                              className={`border-b border-slate-800/60 ${
                                isCurrentActiveRow ? 'bg-cyan-500/20 text-cyan-200 font-bold' : 'text-slate-400'
                              }`}
                            >
                              <td className="py-1.5">{row.a ? '1' : '0'}</td>
                              {c6_gate !== 'NOT' && <td className="py-1.5">{row.b ? '1' : '0'}</td>}
                              <td className="py-1.5">{rowOut ? '1' : '0'}</td>
                              <td className="py-1.5">
                                {isCurrentActiveRow ? (
                                  <span className="text-[10px] text-cyan-400">Active Test</span>
                                ) : (
                                  '—'
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {currentExperiment.circuitType === 'temp_fan' && (
              <div className="py-4 space-y-4">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono">
                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">LM35 Output Voltage</span>
                      <span className="text-base font-bold text-amber-300">{c7_sensorMv} mV</span>
                      <span className="text-[9px] text-slate-300 block mt-1">10 mV / °C linear</span>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Comparator Output</span>
                      <span className={`text-base font-bold ${c7_fanActive ? 'text-emerald-400' : 'text-slate-400'}`}>
                        {c7_fanActive ? '12.0 V (HIGH)' : '0.0 V (LOW)'}
                      </span>
                      <span className="text-[9px] text-slate-300 block mt-1">LM393 Op-Amp</span>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">12V Cooling Fan State</span>
                      <span className={`text-base font-bold ${c7_fanActive ? 'text-cyan-400 animate-pulse' : 'text-slate-400'}`}>
                        {c7_fanActive ? `${c7_fanRpm} RPM` : 'STOPPED'}
                      </span>
                      <span className="text-[9px] text-slate-300 block mt-1">
                        {c7_fanActive ? 'Cooling Active' : 'Chamber Normal'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentExperiment.circuitType === 'mcu_io' && (
              <div className="py-2 space-y-3">
                <canvas
                  ref={canvasRef}
                  width={600}
                  height={150}
                  className="w-full h-36 rounded-xl border border-slate-800 bg-[#060a12]"
                />
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs">
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">GPIO 4 Button State</span>
                    <span className="font-bold text-white">
                      {c8_pinReading === 0 ? '0 (LOW / GND)' : '1 (HIGH / 3.3V)'}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Pullup Mode</span>
                    <span className="font-bold text-cyan-300">{c8_usePullup ? 'INTERNAL_PULLUP' : 'FLOATING'}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">PWM LED V_avg</span>
                    <span className="font-bold text-emerald-300">{c8_avgVout.toFixed(2)} V</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Acoustic Tone</span>
                    <span className="font-bold text-amber-300">{c8_pwmDuty > 0 ? `${c8_pwmFreq} Hz` : 'Silent'}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Under the hood: Theory, Wiring Instructions & Safety */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <BookOpen className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white">
                Laboratory Guide & Procedure: {currentExperiment.title}
              </h3>
            </div>

            <div className="text-xs text-slate-300 space-y-3">
              <div>
                <span className="font-semibold text-white">Objective: </span>
                {currentExperiment.objective}
              </div>

              <div>
                <span className="font-semibold text-white">Required Components: </span>
                <span className="text-slate-300">{currentExperiment.requiredComponents.join(' · ')}</span>
              </div>

              <div>
                <span className="font-semibold text-white block mb-1">Step-by-Step Wiring:</span>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 pl-1">
                  {currentExperiment.wiringInstructions.map((step, idx) => (
                    <li key={idx}>{step}</li>
                  ))}
                </ol>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono">
                <span className="text-cyan-400 font-bold block mb-0.5">Physical Principle:</span>
                <p className="text-slate-300 leading-relaxed">{currentExperiment.underlyingConcept}</p>
              </div>

              {/* Safety Warning */}
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-[11px] text-amber-300/90 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-amber-300">Physical Lab Safety Warning: </span>
                  {currentExperiment.safetyWarnings[0]}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Save Experiment Modal */}
      {showSaveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-5 space-y-4 text-left">
            <h3 className="text-sm font-bold text-white">Save Current Circuit Configuration</h3>
            <p className="text-xs text-slate-400">
              Save your slider values, component choices, and electrical calculations to your browser storage to reopen later.
            </p>
            <input
              type="text"
              value={configName}
              onChange={(e) => setConfigName(e.target.value)}
              placeholder="e.g. 5V Red LED 330 Ohm test"
              className="w-full px-3.5 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowSaveModal(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveConfig}
                disabled={!configName.trim()}
                className="px-4 py-1.5 text-xs font-bold bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 rounded-xl cursor-pointer"
              >
                Save Configuration
              </button>
            </div>

            {savedConfigs.length > 0 && (
              <div className="pt-3 border-t border-slate-800">
                <span className="text-[11px] font-mono text-slate-400 block mb-2">Saved Configurations:</span>
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {savedConfigs.map((cfg) => (
                    <div key={cfg.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                      <div>
                        <span className="font-semibold text-white block">{cfg.name}</span>
                        <span className="text-[10px] text-slate-300">{cfg.date}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            handleLoadConfig(cfg);
                            setShowSaveModal(false);
                          }}
                          className="px-2 py-1 rounded bg-cyan-500/20 text-cyan-300 text-[10px] font-mono cursor-pointer"
                        >
                          Load
                        </button>
                        <button
                          onClick={() => {
                            storageService.deleteExperimentConfig(cfg.id);
                            setSavedConfigs(storageService.getSavedExperimentConfigs());
                          }}
                          className="p-1 text-slate-400 hover:text-red-400 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
