import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { LandingPage } from './components/LandingPage';
import { CatalogueView } from './components/CatalogueView';
import { EquipmentDetailView } from './components/EquipmentDetailView';
import { RentEquipmentView } from './components/RentEquipmentView';
import { VirtualLabView } from './components/VirtualLabView';
import { LearnView } from './components/LearnView';
import { ProjectsView } from './components/ProjectsView';
import { BusinessModelView } from './components/BusinessModelView';
import { BusinessDashboardView } from './components/BusinessDashboardView';
import { AdminControlsView } from './components/AdminControlsView';
import { StudentDashboardView } from './components/StudentDashboardView';
import { EquipmentDetailModal } from './components/EquipmentDetailModal';
import { BookingModal } from './components/BookingModal';
import { AuthModal } from './components/AuthModal';
import { LoginPage } from './components/LoginPage';
import { AiMentorModal } from './components/AiMentorModal';
import { JudgeDemoTourModal } from './components/JudgeDemoTourModal';
import { EquipmentItem, RentalBooking } from './types';
import { storageService } from './services/storageService';
import { authService } from './services/authService';
import { Bot, Play } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedDetailItem, setSelectedDetailItem] = useState<EquipmentItem | null>(null);
  const [selectedBookingItem, setSelectedBookingItem] = useState<EquipmentItem | null>(null);
  const [dedicatedDetailItem, setDedicatedDetailItem] = useState<EquipmentItem | null>(null);
  
  const [comparedItemIds, setComparedItemIds] = useState<string[]>([]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isAiMentorOpen, setIsAiMentorOpen] = useState(false);
  const [isDemoTourOpen, setIsDemoTourOpen] = useState(false);
  const [catalogueSearchQuery, setCatalogueSearchQuery] = useState('');
  
  const [currentUser, setCurrentUser] = useState<{ 
    name: string; 
    role: 'student' | 'owner' | 'admin';
    email?: string;
    uid?: string;
  } | null>({
    name: 'Arjun Mehta',
    role: 'student',
    email: 'arjun.mehta@coep.ac.in',
    uid: 'demo-student-arjun'
  });

  // Sync Firebase authentication state
  useEffect(() => {
    const unsubscribe = authService.onAuthChange((fbUser) => {
      if (fbUser) {
        setCurrentUser({
          name: fbUser.displayName || fbUser.email || 'ENTC Innovator',
          role: fbUser.role,
          email: fbUser.email || undefined,
          uid: fbUser.uid
        });
      }
    });
    return () => unsubscribe();
  }, []);

  // Load persistent bookings
  const [bookings, setBookings] = useState<RentalBooking[]>(() => storageService.getBookings());
  const [savedCount, setSavedCount] = useState<number>(() => storageService.getSavedItemIds().length);

  const refreshAppData = () => {
    setBookings(storageService.getBookings());
    setSavedCount(storageService.getSavedItemIds().length);
  };

  const handleBookingConfirmed = (newBooking: RentalBooking) => {
    refreshAppData();
  };

  const handleSearchClick = () => {
    setActiveTab('catalogue');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenDedicatedDetail = (item: EquipmentItem) => {
    setDedicatedDetailItem(item);
    setActiveTab('equipment-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const [appToast, setAppToast] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setAppToast(msg);
    setTimeout(() => setAppToast(null), 3500);
  };

  const handleToggleCompare = (item: EquipmentItem) => {
    if (comparedItemIds.includes(item.id)) {
      setComparedItemIds(comparedItemIds.filter((id) => id !== item.id));
      triggerToast(`Removed ${item.name.split(' ')[0]} from comparison.`);
    } else {
      if (comparedItemIds.length >= 3) {
        triggerToast('You can compare a maximum of 3 items at a time.');
        return;
      }
      setComparedItemIds([...comparedItemIds, item.id]);
      triggerToast(`Added ${item.name.split(' ')[0]} to comparison.`);
    }
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-neutral-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        bookingCount={bookings.length}
        savedCount={savedCount}
        openBookingHistory={() => setActiveTab('student-dashboard')}
        openSavedItems={() => setActiveTab('student-dashboard')}
        openAuthModal={() => setIsAuthOpen(true)}
        openAiMentor={() => setIsAiMentorOpen(true)}
        openJudgeTour={() => setIsDemoTourOpen(true)}
        currentUser={currentUser}
        setCurrentUser={setCurrentUser}
        onSearchClick={handleSearchClick}
      />

      {/* Main Dynamic View Content */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <LandingPage
            onExploreEquipment={() => setActiveTab('catalogue')}
            onStartLearning={() => setActiveTab('learn')}
            onOpenVirtualLab={() => setActiveTab('virtual-lab')}
            onSelectEquipment={handleOpenDedicatedDetail}
            onBookEquipment={(item) => setSelectedBookingItem(item)}
            onOpenBusinessHub={() => setActiveTab('business-model')}
            onOpenProjects={() => {
              setActiveTab('projects');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'catalogue' && (
          <CatalogueView
            initialSearchQuery={catalogueSearchQuery}
            onSelectEquipment={handleOpenDedicatedDetail}
            onBookEquipment={(item) => setSelectedBookingItem(item)}
          />
        )}

        {activeTab === 'equipment-detail' && dedicatedDetailItem && (
          <EquipmentDetailView
            item={dedicatedDetailItem}
            onBack={() => setActiveTab('catalogue')}
            onRentNow={(item) => setSelectedBookingItem(item)}
            onAddToCompare={handleToggleCompare}
            isCompared={comparedItemIds.includes(dedicatedDetailItem.id)}
            onSelectComplementary={handleOpenDedicatedDetail}
          />
        )}

        {activeTab === 'rentals' && (
          <RentEquipmentView
            onBookNow={(item) => setSelectedBookingItem(item)}
            onExploreCatalogue={() => setActiveTab('catalogue')}
          />
        )}

        {activeTab === 'virtual-lab' && (
          <VirtualLabView 
            onRentEquipment={(item) => setSelectedBookingItem(item)}
            onViewEquipmentDetail={handleOpenDedicatedDetail}
          />
        )}

        {activeTab === 'learn' && (
          <LearnView 
            onRentEquipment={(item) => setSelectedBookingItem(item)}
            onOpenVirtualLab={() => {
              setActiveTab('virtual-lab');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'projects' && (
          <ProjectsView 
            onRentEquipment={(item) => setSelectedBookingItem(item)}
            onViewEquipmentDetail={handleOpenDedicatedDetail}
          />
        )}

        {activeTab === 'business-model' && (
          <BusinessModelView
            onExploreRentals={() => setActiveTab('catalogue')}
            onOpenOwnerPortal={() => setActiveTab('business')}
          />
        )}

        {activeTab === 'business' && (
          <BusinessDashboardView />
        )}

        {activeTab === 'admin' && (
          <AdminControlsView />
        )}

        {activeTab === 'login' && (
          <LoginPage
            currentUser={currentUser}
            onLoginSuccess={(user) => {
              setCurrentUser(user);
              triggerToast(`Authenticated as ${user.name} (${user.role.toUpperCase()})`);
              if (user.role === 'admin') setActiveTab('admin');
              else if (user.role === 'owner') setActiveTab('business');
              else setActiveTab('student-dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onLogout={async () => {
              await authService.signOut();
              setCurrentUser(null);
              triggerToast('Signed out of session.');
            }}
            onNavigateToTab={(tab) => {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'student-dashboard' && (
          <StudentDashboardView
            bookings={bookings}
            onExploreMore={() => setActiveTab('catalogue')}
            onOpenVirtualLab={() => setActiveTab('virtual-lab')}
            onViewEquipmentDetail={handleOpenDedicatedDetail}
            onNavigateToProjects={() => setActiveTab('projects')}
            onRefreshBookings={refreshAppData}
          />
        )}
      </main>

      {/* App Toast Notification */}
      {appToast && (
        <div className="fixed top-20 right-6 z-50 p-4 rounded-xl bg-neutral-950/95 border border-amber-500/40 text-amber-300 text-xs font-mono shadow-2xl shadow-black/80 animate-in fade-in slide-in-from-top-2 duration-200">
          {appToast}
        </div>
      )}

      {/* Floating Dr. Silicon AI Mentor Button */}
      <button
        onClick={() => setIsAiMentorOpen(true)}
        className="fixed bottom-6 right-6 z-40 p-3 sm:px-4 sm:py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-black font-extrabold shadow-xl shadow-amber-500/25 hover:shadow-amber-500/40 hover:scale-105 active:scale-95 border border-amber-300 transition-all flex items-center gap-2 cursor-pointer group"
        aria-label="Ask Dr. Silicon AI Mentor"
      >
        <Bot className="w-5 h-5 text-black group-hover:rotate-12 transition-transform shrink-0" />
        <span className="hidden sm:inline text-xs font-extrabold tracking-wide">Dr. Silicon AI Mentor</span>
      </button>

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} />

      {/* Modals & Overlays */}
      <EquipmentDetailModal
        item={selectedDetailItem}
        onClose={() => setSelectedDetailItem(null)}
        onBookNow={(item) => {
          setSelectedDetailItem(null);
          setSelectedBookingItem(item);
        }}
      />

      <BookingModal
        equipment={selectedBookingItem}
        onClose={() => setSelectedBookingItem(null)}
        onBookingConfirmed={handleBookingConfirmed}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onOpenFullLoginPage={() => {
          setActiveTab('login');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onLogin={(user) => {
          setCurrentUser(user);
          triggerToast(`Profile Active: ${user.name} (${user.role.toUpperCase()})`);
          if (user.role === 'admin') setActiveTab('admin');
          else if (user.role === 'owner') setActiveTab('business');
          else setActiveTab('student-dashboard');
        }}
      />

      <AiMentorModal
        isOpen={isAiMentorOpen}
        onClose={() => setIsAiMentorOpen(false)}
        onNavigateTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenEquipmentDetail={(eqId) => {
          const item = storageService.getEquipmentById(eqId);
          if (item) {
            handleOpenDedicatedDetail(item);
          } else {
            setActiveTab('catalogue');
          }
        }}
      />

      <JudgeDemoTourModal
        isOpen={isDemoTourOpen}
        onClose={() => setIsDemoTourOpen(false)}
        onNavigateTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectEquipmentId={(eqId) => {
          const item = storageService.getEquipmentById(eqId);
          if (item) {
            handleOpenDedicatedDetail(item);
          }
        }}
        onOpenBooking={(eqId) => {
          const item = storageService.getEquipmentById(eqId);
          if (item) {
            setSelectedBookingItem(item);
          }
        }}
        onOpenAiMentor={(_query) => {
          setIsAiMentorOpen(true);
        }}
        onResetApp={refreshAppData}
        onSearchEquipment={(query) => {
          setCatalogueSearchQuery(query);
          setActiveTab('catalogue');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />
    </div>
  );
}
